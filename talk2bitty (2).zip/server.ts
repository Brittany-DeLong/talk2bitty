import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import Stripe from 'stripe';
import { handleTwilioWebhook, handleTwilioStatus } from './server/twilioWebhook';

dotenv.config();

const app = express();
const PORT = 3000;

// High-limit parser specifically for photo uploads (base64 pictures)
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));

// Ensure local uploads directory exists on startup
const uploadsDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}
app.use('/uploads', express.static(uploadsDir));

// Robust CORS with instant OPTIONS preflight handler (prevents CORS blocks & redirects)
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Access-Control-Allow-Credentials', 'true');
  } else {
    res.setHeader('Access-Control-Allow-Origin', '*');
  }
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With, Accept');

  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    res.setHeader('Content-Length', '0');
    res.end();
    return;
  }
  next();
});

// Image Upload Endpoint with Google Cloud Storage and Local Disk Fallback
app.post('/api/upload', async (req, res) => {
  const { base64DataUrl, fileName } = req.body;
  if (!base64DataUrl) {
    res.status(400).json({ error: "Missing file payload." });
    return;
  }

  try {
    const timestamp = Date.now();
    const cleanName = (fileName || 'unnamed.jpg').replace(/[^a-zA-Z0-9.\-_]/g, '_');
    const filename = `${timestamp}_${cleanName}`;

    // Extract raw buffer from base64 data url
    const matches = base64DataUrl.match(/^data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+);base64,(.+)$/);
    let buffer: Buffer;
    let mimeType = 'image/jpeg';

    if (matches && matches.length === 3) {
      mimeType = matches[1];
      buffer = Buffer.from(matches[2], 'base64');
    } else {
      const dataString = base64DataUrl.includes(';base64,') 
        ? base64DataUrl.split(';base64,')[1] 
        : base64DataUrl;
      buffer = Buffer.from(dataString, 'base64');
    }

    const bucketName = process.env.STORAGE_BUCKET;
    if (bucketName) {
      console.log(`STORAGE_BUCKET is configured. Uploading to GCS bucket: ${bucketName}`);
      try {
        const { Storage } = await import('@google-cloud/storage');
        const storageClient = new Storage();
        const bucket = storageClient.bucket(bucketName);
        const gcsFile = bucket.file(`bitty_photographs/${filename}`);

        await gcsFile.save(buffer, {
          metadata: { contentType: mimeType },
          resumable: false
        });

        // Attempt makePublic, but catch in case Uniform Bucket-Level Access prevents Object ACL writes
        try {
          await gcsFile.makePublic();
        } catch (pubErr) {
          console.warn("GCS makePublic failed (likely because Uniform Bucket-Level Access or Object ACL is disabled, which is expected):", pubErr);
        }

        const publicUrl = `https://storage.googleapis.com/${bucketName}/bitty_photographs/${filename}`;
        console.log(`Successfully uploaded to GCS. Public URL: ${publicUrl}`);
        res.json({ url: publicUrl });
        return;
      } catch (gcsError: any) {
        console.error("GCS upload failed, falling back to local file storage:", gcsError);
      }
    }

    // Default Fallback: Write file to persistent local directory
    console.log(`Uploading locally. Saving file to uploads/${filename}`);
    const filePath = path.join(uploadsDir, filename);
    fs.writeFileSync(filePath, buffer);

    const localUrl = `/uploads/${filename}`;
    res.json({ url: localUrl });

  } catch (err: any) {
    console.error("Failed to process upload in API route:", err);
    res.status(500).json({ error: "Failed to process photo upload: " + err.message });
  }
});

const DB_PATH = path.join(process.cwd(), 'server_db.json');

// Initialize database with default template values on startup if missing
function initDB() {
  let needsInit = !fs.existsSync(DB_PATH);
  if (!needsInit) {
    try {
      const data = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
      if (data.accounts && data.accounts.some((a: any) => a.name === 'Sarah Jenkins')) {
        needsInit = true; // Overwrite database to purge Sarah Jenkins mock records
      }
    } catch (e) {
      needsInit = true;
    }
  }

  if (needsInit) {
    const defaultDB = {
      accounts: [
        {
          id: 'bitty_admin',
          password: 'adminpassword',
          name: 'Bitty',
          username: 'bitty',
          email: 'bitty0218@gmail.com',
          phone: '220-710-2021',
          bio: 'Mom of three, Human Development student, cockatoo guardian. Here for raw, honest perspective without the clinical fluff.',
          avatarUrl: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect width="100" height="100" fill="%2318181b"/><circle cx="50" cy="50" r="35" stroke="%23f59e0b" stroke-width="2.5" fill="%2327272a"/><text x="50" y="59" font-family="monospace" font-weight="900" font-size="34" fill="%23f59e0b" text-anchor="middle">B</text></svg>',
          isAdmin: true
        }
      ],
      posts: [
        {
          id: 'post_1',
          userId: 'bitty_admin',
          userName: 'Bitty',
          userAvatar: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect width="100" height="100" fill="%2318181b"/><circle cx="50" cy="50" r="35" stroke="%23f59e0b" stroke-width="2.5" fill="%2327272a"/><text x="50" y="59" font-family="monospace" font-weight="900" font-size="34" fill="%23f59e0b" text-anchor="middle">B</text></svg>',
          content: `Welcome to Talk2Bitty. 🤍 \n\nI built this space because genuine conversation is becoming incredibly hard to find. We live in a world of fake positivity, perfectly curated influencer feeds, and clinical scripts. Sometimes you just need to talk to a real person who isn't going to feed you textbook answers or judge you for a bad chapter in your book.\n\nWe have two cockatoos in our house who are basically feathered toddlers with megaphones, so life is chaotic, messy, and real. That's exactly how I want this platform to be. \n\nWrite a post below. Tell us what's on your mind. Ask for feedback. Or just read and lend a quiet listening ear to others. Keep it honest and kind. We don't do algorithms here.`,
          createdAt: new Date(Date.now() - 36000 * 1000).toISOString(),
          comments: [
            {
              id: 'comment_1_2',
              postId: 'post_1',
              userId: 'user_2',
              userName: 'Marcus Rivera',
              userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
              content: `Refreshing to see a space that doesn't feel like a corporate wellness retreat. Looking forward to connecting here.`,
              createdAt: new Date(Date.now() - 30000 * 1000).toISOString()
            }
          ]
        },
        {
          id: 'post_2',
          userId: 'user_3',
          userName: 'Clara Hayes',
          userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
          content: `Has anyone else struggled with setting boundaries with childhood friends? I find myself holding onto relationships that drains me physically and emotionally, just because "we've known each other for 15 years." \n\nHow do you start letting go of historical guilt? Is there a respectful way to do it?`,
          createdAt: new Date(Date.now() - 72000 * 1000).toISOString(),
          imageUrl: 'https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?w=800',
          comments: [
            {
              id: 'comment_2_1',
              postId: 'post_2',
              userId: 'bitty_admin',
              userName: 'Bitty',
              userAvatar: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect width="100" height="100" fill="%2318181b"/><circle cx="50" cy="50" r="35" stroke="%23f59e0b" stroke-width="2.5" fill="%2327272a"/><text x="50" y="59" font-family="monospace" font-weight="900" font-size="34" fill="%23f59e0b" text-anchor="middle">B</text></svg>',
              content: `Clara, this is huge. Historical guilt is such a powerful anchor. One thing counseling and life taught me is that relationships need to be nourished by who you both are *today*, not who you were at age ten. Letting a friendship naturally fade, or politely saying 'no' to engagements that feel like homework, is a kindness to you both. You aren't a bad person for outgrowing a costume that no longer fits.`,
              createdAt: new Date(Date.now() - 65000 * 1000).toISOString()
            }
          ]
        }
      ],
      requests: [],
      payments: [],
      settings: {
        isAvailable: true,
        unavailableMessage: 'Bitty is currently offline for child-wrangling, exams, or cockatoo-taming. Feel free to browse the community and check back later.'
      }
    };
    fs.writeFileSync(DB_PATH, JSON.stringify(defaultDB, null, 2), 'utf-8');
  }
}

initDB();

// Read Database helper
function readDB() {
  initDB();
  const db = JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
  let altered = false;
  if (!db.waitlist) {
    db.waitlist = [];
    altered = true;
  }
  
  // Backwards compatibility for user records without username
  if (db.accounts) {
    db.accounts.forEach((acc: any) => {
      if (!acc.username) {
        acc.username = acc.name.toLowerCase().trim().replace(/[^a-z0-9_]/g, '_') || 'user_' + acc.id;
        altered = true;
      }
      if (acc.isPhoneVerified === undefined) {
        acc.isPhoneVerified = false;
        altered = true;
      }
    });
  }

  if (!db.settings) {
    db.settings = {
      isAvailable: true,
      availabilityStatus: 'open',
      unavailableMessage: 'Bitty is currently offline for child-wrangling, exams, or cockatoo-taming. Feel free to browse the community and check back later.',
      waitlistMessage: 'Bitty is currently full and running on waitlist mode. Enter your email to be the first to know when standard conversation slots open back up!',
      contactType: 'whatsapp',
      customContactInfo: '12207102021',
      enableDrivePortal: false,
      galleryPhotos: [
        { id: 'slot_polaroid', name: 'Home Page Polaroid', url: '', caption: 'Me 🤍' },
        { id: 'slot_about_family', name: 'About Page Cockatoos Showcase', url: 'https://images.unsplash.com/photo-1548232623-24831a788647?w=800', caption: 'Meet the Feathered Toddlers' },
        { id: 'slot_about_intro', name: 'About Page Personal Story Highlight', url: '', caption: 'Creating space for genuine thoughts.' },
        { id: 'slot_community', name: 'Community Pin Board Photo', url: '', caption: 'Daily visual anchor' }
      ]
    };
    altered = true;
  } else {
    if (!db.settings.availabilityStatus) {
      db.settings.availabilityStatus = db.settings.isAvailable ? 'open' : 'closed';
      altered = true;
    }
    if (!db.settings.waitlistMessage) {
      db.settings.waitlistMessage = 'Bitty is currently full and running on waitlist mode. Enter your email to be the first to know when standard conversation slots open back up!';
      altered = true;
    }
    if (!db.settings.contactType) {
      db.settings.contactType = 'whatsapp';
      altered = true;
    }
    if (!db.settings.customContactInfo) {
      db.settings.customContactInfo = '12207102021';
      altered = true;
    }
    if (db.settings.enableDrivePortal === undefined) {
      db.settings.enableDrivePortal = false;
      altered = true;
    }
    if (!db.settings.galleryPhotos) {
      db.settings.galleryPhotos = [
        { id: 'slot_polaroid', name: 'Home Page Polaroid', url: '', caption: 'Me 🤍' },
        { id: 'slot_about_family', name: 'About Page Cockatoos Showcase', url: 'https://images.unsplash.com/photo-1548232623-24831a788647?w=800', caption: 'Meet the Feathered Toddlers' },
        { id: 'slot_about_intro', name: 'About Page Personal Story Highlight', url: '', caption: 'Creating space for genuine thoughts.' },
        { id: 'slot_community', name: 'Community Pin Board Photo', url: '', caption: 'Daily visual anchor' }
      ];
      altered = true;
    }
    if (!db.settings.uploadedPhotos) {
      db.settings.uploadedPhotos = [];
      altered = true;
    }
    if (db.settings.forceHighFraudScore === undefined) {
      db.settings.forceHighFraudScore = false;
      altered = true;
    }
  }
  if (!db.smsDefenseLogs) {
    db.smsDefenseLogs = [];
    altered = true;
  }
  if (altered) {
    fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), 'utf-8');
  }
  return db;
}

// Write Database helper
function writeDB(data: any) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf-8');
}

// Initialize Stripe if secret key is present
let stripe: Stripe | null = null;
const stripeSecret = process.env.STRIPE_SECRET_KEY;
if (stripeSecret) {
  console.log("Setting up Stripe with secret key format:", stripeSecret.substring(0, 8) + '...');
  stripe = new Stripe(stripeSecret);
} else {
  console.log("No Stripe Secret Key found. Operating in simulation mode.");
}

/* ========================================================================= */
/* API ROUTES                                                                */
/* ========================================================================= */

// Get database state for Bitty Settings
app.get('/api/public-settings', (req, res) => {
  const db = readDB();
  const bittyAdmin = db.accounts.find((acc: any) => acc.id === 'bitty_admin');
  res.json({
    settings: db.settings,
    bittyProfile: bittyAdmin ? { avatarUrl: bittyAdmin.avatarUrl, bio: bittyAdmin.bio } : { avatarUrl: '', bio: 'Mom of three, family studies student' },
    stripePublishableKey: process.env.VITE_STRIPE_PUBLISHABLE_KEY || null
  });
});

// User Account registration
app.post('/api/auth/register', (req, res) => {
  let { name, username, email, phone, password, bio, avatarUrl } = req.body;
  if (!name || !email || !password) {
    res.status(400).json({ error: "Missing required registration parameters." });
    return;
  }

  const db = readDB();
  const emailLower = email.toLowerCase().trim();
  const existingUser = db.accounts.find((acc: any) => acc.email.toLowerCase() === emailLower);
  
  if (existingUser) {
    res.status(400).json({ error: "This email address is already registered." });
    return;
  }

  // Format and validate username
  if (!username) {
    username = name.toLowerCase().trim().replace(/[^a-z0-9_]/g, '_') || 'user_' + Math.random().toString(36).substring(2, 6);
  } else {
    username = username.toLowerCase().trim().replace(/[^a-z0-9_]/g, '_');
  }

  // Ensure unique username
  const existingUsername = db.accounts.find((acc: any) => acc.username === username);
  if (existingUsername) {
    res.status(400).json({ error: "This username is already taken. Please choose another." });
    return;
  }

  const newAccount = {
    id: 'user_' + Math.random().toString(36).substring(2, 9),
    name,
    username,
    email: emailLower,
    phone: phone || '',
    password,
    bio: bio || '',
    avatarUrl: avatarUrl || `https://images.unsplash.com/photo-${['1534528741775-53994a69daeb', '1507003211169-0a1dd7228f2d', '1494790108377-be9c29b29330', '1500648767791-00dcc994a43e'][Math.floor(Math.random() * 4)]}?w=150`,
    isAdmin: false
  };

  db.accounts.push(newAccount);
  writeDB(db);

  // Return user details without password
  const { password: _, ...safeUser } = newAccount;
  res.json({ user: safeUser });
});

// Google Authentication endpoint
app.post('/api/auth/google', (req, res) => {
  const { name, email, avatarUrl, id } = req.body;
  if (!email) {
    res.status(400).json({ error: "Missing email address from Google Authenticator." });
    return;
  }

  const db = readDB();
  const emailLower = email.toLowerCase().trim();
  let user = db.accounts.find((acc: any) => acc.email.toLowerCase() === emailLower);

  if (!user) {
    // Generate username from display name or fallback
    const targetBase = name ? name.toLowerCase().trim().replace(/[^a-z0-9_]/g, '_') : 'user_' + Math.random().toString(36).substring(2, 6);
    let uniqueUsername = targetBase;
    let suffix = 1;
    while (db.accounts.some((acc: any) => acc.username === uniqueUsername)) {
      uniqueUsername = `${targetBase}_${suffix}`;
      suffix++;
    }

    // Register user seamlessly
    user = {
      id: id || 'user_' + Math.random().toString(36).substring(2, 9),
      name: name || 'Google User',
      username: uniqueUsername,
      email: emailLower,
      phone: '',
      password: '', // Passwordless account
      bio: 'Verified listening partner via Google Auth.',
      avatarUrl: avatarUrl || `https://images.unsplash.com/photo-${['1534528741775-53994a69daeb', '1507003211169-0a1dd7228f2d', '1494790108377-be9c29b29330', '1500648767791-00dcc994a43e'][Math.floor(Math.random() * 4)]}?w=150`,
      isAdmin: false
    };

    db.accounts.push(user);
    writeDB(db);
  }

  const { password: _, ...safeUser } = user;
  res.json({ user: safeUser });
});

// User login
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    res.status(400).json({ error: "Email and password are required." });
    return;
  }

  const db = readDB();
  const user = db.accounts.find((acc: any) => acc.email.toLowerCase().trim() === email.toLowerCase().trim() && acc.password === password);

  if (!user) {
    res.status(401).json({ error: "Invalid email address or incorrect password." });
    return;
  }

  const { password: _, ...safeUser } = user;
  res.json({ user: safeUser });
});

// Update profile
app.post('/api/auth/update', (req, res) => {
  let { id, name, username, email, phone, bio, avatarUrl } = req.body;
  if (!id) {
    res.status(400).json({ error: "No user id parsed." });
    return;
  }

  const db = readDB();
  const userIdx = db.accounts.findIndex((acc: any) => acc.id === id);
  if (userIdx === -1) {
    res.status(404).json({ error: "Profile not found." });
    return;
  }

  // Format and validate username
  if (username) {
    username = username.toLowerCase().trim().replace(/[^a-z0-9_]/g, '_');
    const existingUsername = db.accounts.find((acc: any) => acc.username === username && acc.id !== id);
    if (existingUsername) {
      res.status(400).json({ error: "This username is already taken. Please choose another." });
      return;
    }
  } else {
    username = db.accounts[userIdx].username || 'user_' + id;
  }

  // Preserve admin value
  const isAdmin = db.accounts[userIdx].isAdmin;
  const password = db.accounts[userIdx].password;

  const updatedAccount = {
    id,
    password,
    name,
    username,
    email: email.toLowerCase().trim(),
    phone,
    bio,
    avatarUrl,
    isAdmin
  };

  db.accounts[userIdx] = updatedAccount;

  // Propagate updated details down to posts and comments
  db.posts = db.posts.map((p: any) => {
    if (p.userId === id) {
      return { ...p, userName: name, userAvatar: avatarUrl };
    }
    if (p.comments) {
      p.comments = p.comments.map((c: any) => {
        if (c.userId === id) {
          return { ...c, userName: name, userAvatar: avatarUrl };
        }
        return c;
      });
    }
    return p;
  });

  writeDB(db);

  const { password: _, ...safeUser } = updatedAccount;
  res.json({ user: safeUser, posts: db.posts });
});

// Cron Board Posts Retrieval
app.get('/api/posts', (req, res) => {
  const db = readDB();
  res.json({ posts: db.posts });
});

// Create post with picture upload support
app.post('/api/posts', (req, res) => {
  const { userId, userName, userAvatar, content, imageUrl } = req.body;
  if (!userId || !content) {
    res.status(400).json({ error: "User identity and body content are required." });
    return;
  }

  const db = readDB();
  const newPost = {
    id: 'post_' + Date.now(),
    userId,
    userName,
    userAvatar,
    content,
    imageUrl: imageUrl || undefined,
    createdAt: new Date().toISOString(),
    comments: []
  };

  db.posts.unshift(newPost);
  writeDB(db);
  res.json({ post: newPost, posts: db.posts });
});

// Edit post
app.post('/api/posts/edit', (req, res) => {
  const { postId, userId, content, isAdmin } = req.body;
  if (!postId || !content) {
    res.status(400).json({ error: "Missing required parameters." });
    return;
  }

  const db = readDB();
  const postIdx = db.posts.findIndex((p: any) => p.id === postId);
  if (postIdx === -1) {
    res.status(404).json({ error: "Post not found." });
    return;
  }

  // Authentication check
  if (db.posts[postIdx].userId !== userId && !isAdmin) {
    res.status(403).json({ error: "Unpermitted action on others' posts." });
    return;
  }

  db.posts[postIdx].content = content;
  writeDB(db);
  res.json({ posts: db.posts });
});

// Toggle Bitty's Pick status (Admin Only)
app.post('/api/posts/toggle-pick', (req, res) => {
  const { postId, isAdmin } = req.body;
  if (!postId) {
    res.status(400).json({ error: "Missing required parameters." });
    return;
  }
  if (!isAdmin) {
    res.status(403).json({ error: "Admin access required to toggle Bitty's Pick status." });
    return;
  }

  const db = readDB();
  const postIdx = db.posts.findIndex((p: any) => p.id === postId);
  if (postIdx === -1) {
    res.status(404).json({ error: "Post not found." });
    return;
  }

  db.posts[postIdx].isBittyPick = !db.posts[postIdx].isBittyPick;
  writeDB(db);
  res.json({ posts: db.posts });
});

// Delete post (With Moderation Access)
app.delete('/api/posts/:postId', (req, res) => {
  const { postId } = req.params;
  const { userId, isAdmin } = req.body; // Authenticated request details

  const db = readDB();
  const post = db.posts.find((p: any) => p.id === postId);
  if (!post) {
    res.status(404).json({ error: "Post already missing." });
    return;
  }

  if (post.userId !== userId && !isAdmin) {
    res.status(403).json({ error: "Moderation privileges required." });
    return;
  }

  db.posts = db.posts.filter((p: any) => p.id !== postId);
  writeDB(db);
  res.json({ posts: db.posts });
});

// Add support comment
app.post('/api/posts/:postId/comments', (req, res) => {
  const { postId } = req.params;
  const { userId, userName, userAvatar, content } = req.body;

  if (!userId || !content) {
    res.status(400).json({ error: "Missing content for supporting comments." });
    return;
  }

  const db = readDB();
  const postIdx = db.posts.findIndex((p: any) => p.id === postId);
  if (postIdx === -1) {
    res.status(404).json({ error: "Post details expired." });
    return;
  }

  const newComment = {
    id: 'comment_' + Date.now(),
    postId,
    userId,
    userName,
    userAvatar,
    content,
    createdAt: new Date().toISOString()
  };

  if (!db.posts[postIdx].comments) {
    db.posts[postIdx].comments = [];
  }

  db.posts[postIdx].comments.push(newComment);
  writeDB(db);
  res.json({ posts: db.posts });
});

// Toggle Like on post
app.post('/api/twilio', handleTwilioWebhook);
app.post('/twilio/inbound', handleTwilioWebhook);
app.post('/twilio/status', handleTwilioStatus);
app.post('/api/twilio/inbound', handleTwilioWebhook);
app.post('/api/twilio/status', handleTwilioStatus);

app.post('/api/posts/:postId/like', (req, res) => {
  const { postId } = req.params;
  const { userId } = req.body;

  if (!userId) {
    res.status(400).json({ error: "Missing user ID for reaction." });
    return;
  }

  const db = readDB();
  const postIdx = db.posts.findIndex((p: any) => p.id === postId);
  if (postIdx === -1) {
    res.status(404).json({ error: "Post not found." });
    return;
  }

  const post = db.posts[postIdx];
  if (!post.likes) {
    post.likes = [];
  }

  const likeIdx = post.likes.indexOf(userId);
  if (likeIdx > -1) {
    // Already liked, so unlike
    post.likes.splice(likeIdx, 1);
  } else {
    // Add like
    post.likes.push(userId);
  }

  writeDB(db);
  res.json({ posts: db.posts });
});

// Delete comment
app.delete('/api/posts/:postId/comments/:commentId', (req, res) => {
  const { postId, commentId } = req.params;
  const { userId, isAdmin } = req.body;

  const db = readDB();
  const postIdx = db.posts.findIndex((p: any) => p.id === postId);
  if (postIdx === -1) {
    res.status(404).json({ error: "Post not found." });
    return;
  }

  const comment = db.posts[postIdx].comments?.find((c: any) => c.id === commentId);
  if (!comment) {
    res.status(404).json({ error: "Comment not found." });
    return;
  }

  if (comment.userId !== userId && !isAdmin) {
    res.status(403).json({ error: "Permission denied." });
    return;
  }

  db.posts[postIdx].comments = db.posts[postIdx].comments.filter((c: any) => c.id !== commentId);
  writeDB(db);
  res.json({ posts: db.posts });
});

// Retrieve requests and payments
app.post('/api/records', (req, res) => {
  const { userId, isAdmin } = req.body;
  const db = readDB();

  if (isAdmin) {
    res.json({ requests: db.requests, payments: db.payments });
  } else {
    const userRequests = db.requests.filter((r: any) => r.userId === userId);
    const userPayments = db.payments.filter((p: any) => p.userId === userId);
    res.json({ requests: userRequests, payments: userPayments });
  }
});

// Update global settings (Admin only)
app.post('/api/admin/settings', (req, res) => {
  const { isAvailable, availabilityStatus, unavailableMessage, waitlistMessage, contactType, customContactInfo, enableDrivePortal, galleryPhotos, uploadedPhotos } = req.body;
  const db = readDB();
  db.settings = { 
    isAvailable: isAvailable !== undefined ? Boolean(isAvailable) : db.settings.isAvailable, 
    availabilityStatus: availabilityStatus || db.settings.availabilityStatus || 'open',
    unavailableMessage: unavailableMessage !== undefined ? unavailableMessage : db.settings.unavailableMessage,
    waitlistMessage: waitlistMessage !== undefined ? waitlistMessage : db.settings.waitlistMessage,
    contactType: contactType !== undefined ? contactType : db.settings.contactType || 'whatsapp',
    customContactInfo: customContactInfo !== undefined ? customContactInfo : db.settings.customContactInfo || '12207102021',
    enableDrivePortal: enableDrivePortal !== undefined ? Boolean(enableDrivePortal) : (db.settings.enableDrivePortal || false),
    galleryPhotos: galleryPhotos !== undefined ? galleryPhotos : db.settings.galleryPhotos,
    uploadedPhotos: uploadedPhotos !== undefined ? uploadedPhotos : db.settings.uploadedPhotos || []
  };
  writeDB(db);
  res.json({ settings: db.settings });
});

// Join the notification waitlist
app.post('/api/waitlist', (req, res) => {
  const { email } = req.body;
  if (!email || !email.includes('@')) {
    res.status(400).json({ error: "Please enter a valid email address." });
    return;
  }

  const db = readDB();
  const lowerEmail = email.toLowerCase().trim();
  
  if (!db.waitlist) {
    db.waitlist = [];
  }

  const alreadyJoined = db.waitlist.some((item: any) => item.email.toLowerCase().trim() === lowerEmail);
  if (alreadyJoined) {
    res.json({ success: true, message: "You are already on the waitlist!" });
    return;
  }

  const newItem = {
    id: 'w_' + Date.now() + Math.random().toString(36).substr(2, 4),
    email: lowerEmail,
    createdAt: new Date().toISOString()
  };

  db.waitlist.push(newItem);
  writeDB(db);

  res.json({ success: true, message: "Successfully joined the waitlist! We will notify you when Slots open up." });
});

// Get the waitlist (Admin only)
app.get('/api/admin/waitlist', (req, res) => {
  const db = readDB();
  res.json({ waitlist: db.waitlist || [] });
});

// Remove email from waitlist (Admin only)
app.post('/api/admin/waitlist/remove', (req, res) => {
  const { id } = req.body;
  const db = readDB();
  if (db.waitlist) {
    db.waitlist = db.waitlist.filter((item: any) => item.id !== id);
    writeDB(db);
  }
  res.json({ success: true, waitlist: db.waitlist || [] });
});

// Update request status is approved / declined / refunded (Admin only)
app.post('/api/admin/request-status', (req, res) => {
  const { requestId, status, adminNotes } = req.body;
  const db = readDB();
  
  const reqIdx = db.requests.findIndex((r: any) => r.id === requestId);
  if (reqIdx === -1) {
    res.status(404).json({ error: "Request not found." });
    return;
  }

  db.requests[reqIdx].status = status;
  db.requests[reqIdx].adminNotes = adminNotes;
  db.requests[reqIdx].updatedAt = new Date().toISOString();

  if (status === 'refunded') {
    db.payments = db.payments.map((p: any) => p.requestId === requestId ? { ...p, status: 'refunded' } : p);
  }

  writeDB(db);
  res.json({ requests: db.requests, payments: db.payments });
});

// Delete a request entirely from the database
app.delete('/api/requests/:requestId', (req, res) => {
  const { requestId } = req.params;
  const db = readDB();
  db.requests = db.requests.filter((r: any) => r.id !== requestId);
  db.payments = db.payments.filter((p: any) => p.requestId !== requestId);
  writeDB(db);
  res.json({ success: true, requests: db.requests, payments: db.payments });
});

// Process Simulated pass purchase request (For fallback or mock checkout)
app.post('/api/requests/sandbox', (req, res) => {
  const { userId, userName, userEmail, userPhone, topic, preNotes, agreedToBoundaries, passType, price, paymentId, isAnonymous, attachedDriveFiles } = req.body;
  const db = readDB();

  const newRequest = {
    id: 'req_' + Math.random().toString(36).substring(2, 9).toUpperCase(),
    userId,
    userName,
    userEmail,
    userPhone,
    topic,
    preNotes,
    agreedToBoundaries,
    passType,
    price,
    status: 'pending' as const,
    paymentId,
    isAnonymous: !!isAnonymous,
    adminNotes: '',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    attachedDriveFiles: attachedDriveFiles || []
  };

  db.requests.unshift(newRequest);

  const newPayment = {
    id: 'pay_' + Math.random().toString(36).substring(2, 9).toUpperCase(),
    requestId: newRequest.id,
    userId,
    userName,
    amount: price,
    passType,
    paymentId,
    date: new Date().toISOString(),
    status: 'paid' as const
  };

  db.payments.unshift(newPayment);
  writeDB(db);

  res.json({ success: true, requests: db.requests, payments: db.payments });
});

/* ========================================================================= */
/* STRIPE REAL CHECKOUT SESSIONS INTEGRATION                                 */
/* ========================================================================= */

// Create a real Stripe Checkout Session
app.post('/api/create-checkout-session', async (req, res) => {
  const {
    userId,
    userName,
    userEmail,
    userPhone,
    topic,
    preNotes,
    agreedToBoundaries,
    passType,
    price,
    isAnonymous
  } = req.body;

  if (!stripe) {
    res.status(400).json({ error: "Stripe API is currently not configured or using keys." });
    return;
  }

  try {
    // Decide correct price ID from environment variables, otherwise fallback to standard values provided by user
    let priceId = '';
    if (passType === 'text-15') {
      priceId = process.env.VITE_STRIPE_PRICE_15 || 'price_1TbMOa7wX0qlzTEt6UrxcwsP'; // User's precise 15 mins price ID
    } else {
      priceId = process.env.VITE_STRIPE_PRICE_30 || 'price_1TbmJm7wX0qlzTEtihfigQy9'; // User's precise 30 mins price ID
    }

    const appUrl = process.env.APP_URL || 'http://localhost:3000';

    // Build the secure checkout session redirect
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      mode: 'payment',
      customer_email: userEmail || undefined,
      success_url: `${appUrl}/?intake_success=true&session_id={CHECKOUT_SESSION_ID}&pass_type=${passType}`,
      cancel_url: `${appUrl}/?pricing=true`,
      metadata: {
        userId,
        userName,
        userEmail,
        userPhone,
        topic,
        preNotes,
        agreedToBoundaries: String(agreedToBoundaries),
        passType,
        price: String(price),
        isAnonymous: String(!!isAnonymous)
      },
    });

    res.json({ id: session.id, url: session.url });
  } catch (err: any) {
    console.error("Stripe Session Creation failed: ", err);
    res.status(500).json({ error: err.message });
  }
});

// Retrieve a completed Stripe checkout session state
app.get('/api/retrieve-checkout-session', async (req, res) => {
  const { session_id } = req.query;

  if (!stripe) {
    res.status(400).json({ error: "Stripe is not configured." });
    return;
  }

  if (!session_id || typeof session_id !== 'string') {
    res.status(400).json({ error: "Missing Checkout session_id." });
    return;
  }

  try {
    const session = await stripe.checkout.sessions.retrieve(session_id);
    if (session.payment_status === 'paid' && session.metadata) {
      const db = readDB();
      const meta = session.metadata;

      // Ensure we don't register duplicate orders for the same checkout session
      const existingReq = db.requests.find((r: any) => r.paymentId === session_id);
      if (existingReq) {
        res.json({ success: true, requests: db.requests, payments: db.payments });
        return;
      }

      // Safe intake payload reconstitution
      const newRequest = {
        id: 'req_' + Math.random().toString(36).substring(2, 9).toUpperCase(),
        userId: meta.userId,
        userName: meta.userName,
        userEmail: meta.userEmail,
        userPhone: meta.userPhone,
        topic: meta.topic,
        preNotes: meta.preNotes || '',
        agreedToBoundaries: meta.agreedToBoundaries === 'true',
        passType: meta.passType as any,
        price: Number(meta.price),
        status: 'pending' as const,
        paymentId: session_id,
        isAnonymous: meta.isAnonymous === 'true',
        adminNotes: '',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      db.requests.unshift(newRequest);

      const newPayment = {
        id: 'pay_' + Math.random().toString(36).substring(2, 9).toUpperCase(),
        requestId: newRequest.id,
        userId: meta.userId,
        userName: meta.userName,
        amount: Number(meta.price),
        passType: meta.passType as any,
        paymentId: session_id,
        date: new Date().toISOString(),
        status: 'paid' as const
      };

      db.payments.unshift(newPayment);
      writeDB(db);

      res.json({ success: true, requests: db.requests, payments: db.payments });
    } else {
      res.status(400).json({ error: "Stripe checkout session remains unpaid." });
    }
  } catch (err: any) {
    console.error("Failed to retrieve completed Stripe details:", err);
    res.status(500).json({ error: err.message });
  }
});




// Handle Bitty Profile Picture Upload by updating Bitty account in Database
app.post('/api/admin/bitty-profile', (req, res) => {
  const { avatarUrl, bio } = req.body;
  const db = readDB();
  const index = db.accounts.findIndex((acc: any) => acc.id === 'bitty_admin');
  if (index !== -1) {
    if (avatarUrl !== undefined) {
      db.accounts[index].avatarUrl = avatarUrl;
    }
    if (bio !== undefined) {
      db.accounts[index].bio = bio;
    }
    
    const updatedAvatar = db.accounts[index].avatarUrl;
    // Propagate updated details everywhere
    const name = db.accounts[index].name;
    db.posts = db.posts.map((p: any) => {
      if (p.userId === 'bitty_admin') {
        return { ...p, userName: name, userAvatar: updatedAvatar };
      }
      if (p.comments) {
        p.comments = p.comments.map((c: any) => {
          if (c.userId === 'bitty_admin') {
            return { ...c, userName: name, userAvatar: updatedAvatar };
          }
          return c;
        });
      }
      return p;
    });

    writeDB(db);
    res.json({ success: true, accounts: db.accounts, posts: db.posts });
  } else {
    res.status(404).json({ error: "Bitty Admin profile missing." });
  }
});


/* ========================================================================= */
/* ENVIRONMENT BOARDS                                                        */
/* ========================================================================= */

async function startServer() {
  // Handle Vite middleware assets or static static distribution files in prod mode
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // Bind to host and run
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Bitty Server running dynamically on http://localhost:${PORT}`);
  });
}

startServer();
