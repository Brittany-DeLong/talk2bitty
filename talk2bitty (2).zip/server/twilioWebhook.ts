import { Request, Response } from 'express';
import fs from 'fs';
import path from 'path';
import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore, collection, addDoc } from 'firebase/firestore';

/**
 * Express handler to process incoming SMS webhooks from Twilio.
 * Parses 'Body' and 'From' parameters, stores them in Firestore 'messages' collection,
 * and replies with a valid, clean TwiML XML response.
 */
export async function handleTwilioWebhook(req: Request, res: Response): Promise<void> {
  const body = (req.body.Body || req.body.body || '').toString().trim();
  const from = (req.body.From || req.body.from || '').toString().trim();

  console.log(`[Twilio Webhook] Raw request received. From: "${from}", Body: "${body}"`);

  if (!body && !from) {
    console.warn('[Twilio Webhook] Received empty body and sender fields.');
  }

  try {
    // 1. Read Firebase config dynamically from root workspace folder
    const configPath = path.join(process.cwd(), 'firebase-applet-config.json');
    if (!fs.existsSync(configPath)) {
      throw new Error('Firebase configuration file firebase-applet-config.json was not found.');
    }
    const firebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf8'));

    // 2. Initialize the Firebase applet
    const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
    const db = getFirestore(app);

    // 3. Save the inbound message record to Firestore 'messages' collection
    const createdAt = new Date().toISOString();
    const docRef = await addDoc(collection(db, 'messages'), {
      from: from || 'Unknown Sender',
      body: body || 'No content',
      createdAt
    });

    console.log(`[Twilio Webhook] Saved incoming message successfully. Ref ID: ${docRef.id}`);

    // 4. Return correct TwiML content-type and body xml
    res.setHeader('Content-Type', 'text/xml');
    res.status(200).send(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Message>Hello from Talk2Bitty!</Message>
</Response>`);

  } catch (err: any) {
    console.error('[Twilio Webhook] System error in Firestore storage operation:', err);
    
    // Always fall back to a valid Twilio XML response to avoid showing connection error logs in Twilio Console
    res.setHeader('Content-Type', 'text/xml');
    res.status(200).send(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Message>Bitty received your SMS, but had a brief storage hiccup. We are looking into it! Thanks for reaching out.</Message>
</Response>`);
  }
}

/**
 * Express handler to process status callback webhooks from Twilio.
 * Standard callback fields: SmsStatus/MessageStatus, SmsSid/MessageSid, To, MessageStatus, ErrorCode etc.
 * Responds with 200 OK and an empty TwiML <Response/> to signify successful processing.
 */
export async function handleTwilioStatus(req: Request, res: Response): Promise<void> {
  const messageSid = (req.body.MessageSid || req.body.SmsSid || '').toString();
  const messageStatus = (req.body.MessageStatus || req.body.SmsStatus || '').toString();
  const to = (req.body.To || '').toString();
  const errorCode = (req.body.ErrorCode || '').toString();

  console.log(`[Twilio Status Callback] MessageSid: "${messageSid}", Status: "${messageStatus}", To: "${to}"${errorCode ? `, ErrorCode: "${errorCode}"` : ''}`);

  res.setHeader('Content-Type', 'text/xml');
  res.status(200).send(`<?xml version="1.0" encoding="UTF-8"?>
<Response/>`);
}
