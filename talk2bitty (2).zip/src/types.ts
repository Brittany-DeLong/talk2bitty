export interface UserProfile {
  id: string;
  name: string;
  username: string;
  email: string;
  phone: string;
  bio: string;
  avatarUrl: string;
  isAdmin: boolean;
}

export interface Post {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  content: string;
  imageUrl?: string;
  createdAt: string;
  comments: Comment[];
  isBittyPick?: boolean;
  likes?: string[];
}

export interface Comment {
  id: string;
  postId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  content: string;
  createdAt: string;
}

export type PassType = 'text-15' | 'text-30';

export interface ConversationRequest {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  userPhone: string;
  topic: string;
  preNotes: string;
  agreedToBoundaries: boolean;
  passType: PassType;
  price: number;
  status: 'pending' | 'approved' | 'active' | 'completed' | 'declined' | 'refunded';
  paymentId: string;
  isAnonymous?: boolean;
  adminNotes: string;
  createdAt: string;
  updatedAt: string;
  attachedDriveFiles?: Array<{ id: string; name: string; mimeType: string; url?: string }>;
}

export interface PaymentRecord {
  id: string;
  requestId: string;
  userId: string;
  userName: string;
  amount: number;
  passType: PassType;
  paymentId: string;
  date: string;
  status: 'paid' | 'refunded';
}

export interface GlobalSettings {
  isAvailable: boolean;
  unavailableMessage: string;
  availabilityStatus?: 'open' | 'waitlist' | 'closed';
  waitlistMessage?: string;
  contactType?: 'phone' | 'email' | 'chat_link' | 'whatsapp';
  customContactInfo?: string;
  enableDrivePortal?: boolean;
  galleryPhotos?: Array<{ id: string; name: string; url: string; caption?: string }>;
  uploadedPhotos?: Array<{ id: string; name: string; url: string; uploadedAt: string }>;
}

export interface WaitlistItem {
  id: string;
  email: string;
  createdAt: string;
}
