import React, { useState, useEffect } from 'react';
import { 
  Home, 
  User, 
  ShieldAlert, 
  DollarSign, 
  Users, 
  Sparkles, 
  CheckCircle, 
  Lock, 
  Settings, 
  HelpCircle,
  Menu,
  X,
  MessageSquare,
  Upload,
  Camera,
  RefreshCw,
  Check,
  Download
} from 'lucide-react';

import { uploadBase64ToFirebaseStorage } from './services/googleAuth';
import { compressImage } from './services/imageCompressor';

// Models & Data
import { 
  UserProfile, 
  Post, 
  ConversationRequest, 
  PaymentRecord, 
  GlobalSettings, 
  PassType 
} from './types';

import { 
  INITIAL_USER, 
  INITIAL_BITTY, 
  INITIAL_POSTS, 
  INITIAL_REQUESTS, 
  INITIAL_PAYMENTS, 
  INITIAL_SETTINGS 
} from './data/mockData';

// Modular Child Components
import AboutPage from './components/AboutPage';
import BoundariesPage from './components/BoundariesPage';
import PricingPage from './components/PricingPage';
import IntakeModal from './components/IntakeModal';
import CommunityWall from './components/CommunityWall';
import Dashboard from './components/Dashboard';
import AdminPanel from './components/AdminPanel';
import LegalModal from './components/LegalModal';
import AuthPortal from './components/AuthPortal';
import WhatsAppWidget from './components/WhatsAppWidget';
import Talk2BittyLogo from './components/Talk2BittyLogo';

export default function App() {
  // Navigation
  const [activeTab, setActiveTab ] = useState<'home' | 'about' | 'boundaries' | 'pricing' | 'community' | 'dashboard' | 'admin'>('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  // Global Multi-User State from Server DB with session retention
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('talk2bitty_logged_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [posts, setPosts] = useState<Post[]>([]);
  const [requests, setRequests] = useState<ConversationRequest[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  
  const [bittyProfile, setBittyProfile] = useState<{ avatarUrl: string; bio: string }>({
    avatarUrl: '',
    bio: 'Mom of three, Human Development student, cockatoo guardian. Here for raw, honest perspective without the clinical fluff.'
  });

  const [globalSettings, setGlobalSettings] = useState<GlobalSettings>(INITIAL_SETTINGS);
  const [stripePublishableKey, setStripePublishableKey] = useState<string | null>(null);

  // Purchase modal triggering states
  const [activeIntakeType, setActiveIntakeType] = useState<PassType | null>(null);
  const [activeIntakePrice, setActiveIntakePrice] = useState<number>(0);

  // Legal Modal triggering states
  const [activeLegalTab, setActiveLegalTab] = useState<'privacy' | 'terms' | 'disclaimer' | 'refunds' | null>(null);

  // Home Page direct Polaroid Mock Frame upload states & handlers
  const [isUploadingPolaroid, setIsUploadingPolaroid] = useState(false);
  const [polaroidUploadError, setPolaroidUploadError] = useState<string | null>(null);
  const [polaroidUploadSuccess, setPolaroidUploadSuccess] = useState<boolean>(false);

  // States for Polaroid inline caption editing
  const [isEditingPolaroidCaption, setIsEditingPolaroidCaption] = useState(false);
  const [polaroidCaptionInput, setPolaroidCaptionInput] = useState('');

  const handlePolaroidDirectUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setPolaroidUploadError("Only image files are allowed.");
      e.target.value = '';
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setPolaroidUploadError("Image is too large. Max 5MB recommended.");
      e.target.value = '';
      return;
    }

    setPolaroidUploadError(null);
    setPolaroidUploadSuccess(false);
    setIsUploadingPolaroid(true);

    const reader = new FileReader();
    reader.onloadend = async () => {
      try {
        let base64Url = reader.result as string;
        
        try {
          // Compress the front polaroid image to max 1200x1200px at 75% quality for fast loads
          base64Url = await compressImage(base64Url, { maxWidth: 1200, maxHeight: 1200, quality: 0.75 });
        } catch (compErr) {
          console.warn("Polaroid compression failed, using original size:", compErr);
        }

        const storageUrl = await uploadBase64ToFirebaseStorage(base64Url, 'slot_polaroid.jpg');
        
        // Update local settings and auto-save settings to the database
        const nextPhotos = globalSettings?.galleryPhotos ? [...globalSettings.galleryPhotos] : [];
        const polaroidIdx = nextPhotos.findIndex(p => p.id === 'slot_polaroid');
        if (polaroidIdx >= 0) {
          nextPhotos[polaroidIdx].url = storageUrl;
        } else {
          nextPhotos.push({ id: 'slot_polaroid', name: 'Home Page Polaroid', url: storageUrl, caption: 'Me 🤍' });
        }
        
        const updatedSettings = {
          ...(globalSettings || {}),
          galleryPhotos: nextPhotos
        };
        
        // Persist settings modification directly to server database
        fetch('/api/admin/settings', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(updatedSettings)
        })
          .then(async (r) => {
            if (!r.ok) {
              const text = await r.text();
              throw new Error(`Server returned error: ${r.status} ${text || ''}`);
            }
            return r.json();
          })
          .then(data => {
            if (data.settings) setGlobalSettings(data.settings);
            setPolaroidUploadSuccess(true);
            setTimeout(() => setPolaroidUploadSuccess(false), 3000);
          })
          .catch(err => {
            console.error("Save system settings failed:", err);
            setPolaroidUploadError(err.message || "Failed to save setting to database.");
          })
          .finally(() => {
            setIsUploadingPolaroid(false);
            e.target.value = '';
          });
      } catch (err: any) {
        console.error("Firebase Storage direct upload failed:", err);
        setPolaroidUploadError(err.message || "Failed to upload to Firebase Storage.");
        setIsUploadingPolaroid(false);
        e.target.value = '';
      }
    };
    reader.onerror = () => {
      setPolaroidUploadError("Failed to read image file.");
      setIsUploadingPolaroid(false);
      e.target.value = '';
    };
    reader.readAsDataURL(file);
  };

  // Compute if active user has purchased an active conversation pass
  const hasPurchasedPass = !!currentUser && requests.some(r => r.userId === currentUser.id);

  // Compute proper URL for wa.me redirect
  const contactDetail = globalSettings?.customContactInfo || '12207102021';
  const cleanedPhone = contactDetail.replace(/[^0-9]/g, '');
  const waUrl = contactDetail.startsWith('http') 
    ? contactDetail 
    : `https://wa.me/${cleanedPhone}?text=Hi%20Bitty%2C%20my%20Conversation%2520Pass%2520is%2520active!%2520I'd%2520love%2520to%2520chat.`;

  // Helper to load all dynamic records from our server database
  const fetchAllData = (user: UserProfile | null) => {
    // 1. Fetch public settings
    fetch('/api/public-settings')
      .then(r => r.json())
      .then(data => {
        if (data.settings) setGlobalSettings(data.settings);
        if (data.stripePublishableKey) setStripePublishableKey(data.stripePublishableKey);
        if (data.bittyProfile) setBittyProfile(data.bittyProfile);
      })
      .catch(err => console.error("Failed to load settings:", err));

    // 2. Fetch Board Posts
    fetch('/api/posts')
      .then(r => r.json())
      .then(data => {
        if (data.posts) setPosts(data.posts);
      })
      .catch(err => console.error("Failed to load posts:", err));

    // 3. Fetch User or Admin Intakes & Payment Records
    if (user && user.id) {
      fetch('/api/records', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, isAdmin: user.isAdmin })
      })
        .then(r => r.json())
        .then(data => {
          if (data.requests) setRequests(data.requests);
          if (data.payments) setPayments(data.payments);
        })
        .catch(err => console.error("Failed to load personal logs:", err));
    }
  };

  // Trigger sync on startup and user switching
  useEffect(() => {
    fetchAllData(currentUser);
  }, [currentUser]);

  // Parse success callback from real Stripe billing checkout redirects
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const success = urlParams.get('intake_success');
    const sessionId = urlParams.get('session_id');

    if (success && sessionId) {
      // Validate payment state with Stripe API on Express Server
      fetch(`/api/retrieve-checkout-session?session_id=${sessionId}`)
        .then(r => r.json())
        .then(data => {
          if (data.success) {
            setRequests(data.requests);
            setPayments(data.payments);
            
            // Re-route views cleanly & wipe url queries
            setActiveTab('dashboard');
            window.history.replaceState({}, document.title, window.location.pathname);
          }
        })
        .catch(err => {
          console.error("Failed to consolidate Stripe checkout:", err);
        });
    }
  }, []);

  // Securely logs out the active member session
  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('talk2bitty_logged_user');
    setActiveTab('home');
  };

  // Update client Profile
  const handleUpdateProfile = async (updatedProfile: UserProfile) => {
    try {
      const response = await fetch('/api/auth/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedProfile)
      });
      const data = await response.json();
      if (!response.ok) {
        return { success: false, error: data.error || "Profile update failed." };
      }
      if (data.user) {
        setCurrentUser(data.user);
        localStorage.setItem('talk2bitty_logged_user', JSON.stringify(data.user));
        if (data.posts) setPosts(data.posts);
      }
      return { success: true };
    } catch (err: any) {
      console.error("Profile update failed:", err);
      return { success: false, error: err.message || "Connection failure." };
    }
  };

  // --- Post Operations ---
  const handleAddPost = (content: string, imageUrl?: string) => {
    fetch('/api/posts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: currentUser.id,
        userName: currentUser.name,
        userAvatar: currentUser.avatarUrl,
        content,
        imageUrl
      })
    })
      .then(r => r.json())
      .then(data => {
        if (data.posts) setPosts(data.posts);
      })
      .catch(err => console.error("Create post failed:", err));
  };

  const handleEditPost = (postId: string, newContent: string) => {
    fetch('/api/posts/edit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        postId,
        userId: currentUser.id,
        content: newContent,
        isAdmin: currentUser.isAdmin
      })
    })
      .then(r => r.json())
      .then(data => {
        if (data.posts) setPosts(data.posts);
      })
      .catch(err => console.error("Edit post failed:", err));
  };

  const handleDeletePost = (postId: string) => {
    fetch(`/api/posts/${postId}`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: currentUser.id,
        isAdmin: currentUser.isAdmin
      })
    })
      .then(r => r.json())
      .then(data => {
        if (data.posts) setPosts(data.posts);
      })
      .catch(err => console.error("Delete post failed:", err));
  };

  const handleToggleBittyPick = (postId: string) => {
    if (!currentUser) return;
    fetch('/api/posts/toggle-pick', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        postId,
        isAdmin: currentUser.isAdmin
      })
    })
      .then(r => r.json())
      .then(data => {
        if (data.posts) setPosts(data.posts);
      })
      .catch(err => console.error("Toggle bitty pick failed:", err));
  };

  // --- Comment Operations ---
  const handleAddComment = (postId: string, content: string) => {
    fetch(`/api/posts/${postId}/comments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: currentUser.id,
        userName: currentUser.name,
        userAvatar: currentUser.avatarUrl,
        content
      })
    })
      .then(r => r.json())
      .then(data => {
        if (data.posts) setPosts(data.posts);
      })
      .catch(err => console.error("Add comment failed:", err));
  };

  const handleDeleteComment = (postId: string, commentId: string) => {
    fetch(`/api/posts/${postId}/comments/${commentId}`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: currentUser.id,
        isAdmin: currentUser.isAdmin
      })
    })
      .then(r => r.json())
      .then(data => {
        if (data.posts) setPosts(data.posts);
      })
      .catch(err => console.error("Delete comment failed:", err));
  };

  const handleToggleLike = (postId: string) => {
    if (!currentUser) return;
    fetch(`/api/posts/${postId}/like`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: currentUser.id
      })
    })
      .then(r => r.json())
      .then(data => {
        if (data.posts) setPosts(data.posts);
      })
      .catch(err => console.error("Toggle like failed:", err));
  };

  // --- Purchase Flow Handlers ---
  const handleInitiatePurchase = (passType: PassType, price: number) => {
    setActiveIntakeType(passType);
    setActiveIntakePrice(price);
  };

  // Standard or sandbox purchase flow completion
  const handleCompleteRequestAndPayment = (formData: {
    userName: string;
    userEmail: string;
    userPhone: string;
    topic: string;
    preNotes: string;
    agreedToBoundaries: boolean;
    paymentId: string;
    isAnonymous: boolean;
    attachedDriveFiles?: Array<{ id: string; name: string; mimeType: string; url?: string }>;
  }) => {
    if (!activeIntakeType) return;

    fetch('/api/requests/sandbox', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...formData,
        userId: currentUser.id,
        passType: activeIntakeType,
        price: activeIntakePrice
      })
    })
      .then(r => r.json())
      .then(data => {
        if (data.success) {
          setRequests(data.requests);
          setPayments(data.payments);
          setActiveIntakeType(null);
          setActiveIntakePrice(0);
          setActiveTab('dashboard');
        }
      })
      .catch(err => console.error("Create mockup request failed:", err));
  };

  // --- Admin operations ---
  const handleUpdateSettings = (settings: GlobalSettings) => {
    fetch('/api/admin/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings)
    })
      .then(r => r.json())
      .then(data => {
        if (data.settings) setGlobalSettings(data.settings);
      })
      .catch(err => console.error("Save system settings failed:", err));
  };

  const handleSavePolaroidCaption = (forcedVal?: string) => {
    setIsEditingPolaroidCaption(false);
    const targetVal = (typeof forcedVal === 'string' ? forcedVal : polaroidCaptionInput).trim();
    
    const nextPhotos = globalSettings.galleryPhotos ? [...globalSettings.galleryPhotos] : [];
    const polaroidIdx = nextPhotos.findIndex(p => p.id === 'slot_polaroid');
    
    if (polaroidIdx >= 0) {
      nextPhotos[polaroidIdx].caption = targetVal || 'Bitty 🤍';
    } else {
      nextPhotos.push({
        id: 'slot_polaroid',
        name: 'Home Page Polaroid',
        url: '',
        caption: targetVal || 'Bitty 🤍'
      });
    }
    
    const updatedSettings = {
      ...globalSettings,
      galleryPhotos: nextPhotos
    };
    
    handleUpdateSettings(updatedSettings);
  };

  const handleUpdateRequestStatus = (
    requestId: string,
    newStatus: ConversationRequest['status'],
    adminNotes: string
  ) => {
    fetch('/api/admin/request-status', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ requestId, status: newStatus, adminNotes })
    })
      .then(r => r.json())
      .then(data => {
        if (data.requests) setRequests(data.requests);
        if (data.payments) setPayments(data.payments);
      })
      .catch(err => console.error("Update request status failed:", err));
  };

  const handleDeleteRequest = (requestId: string) => {
    fetch(`/api/requests/${requestId}`, {
      method: 'DELETE'
    })
      .then(r => r.json())
      .then(data => {
        if (data.requests) setRequests(data.requests);
        if (data.payments) setPayments(data.payments);
      })
      .catch(err => console.error("Failed to delete request:", err));
  };

  const handleUpdateBittyProfile = (avatarUrl: string, bio: string) => {
    fetch('/api/admin/bitty-profile', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ avatarUrl, bio })
    })
      .then(r => r.json())
      .then(data => {
        if (data.success) {
          setBittyProfile({ avatarUrl, bio });
          if (data.posts) setPosts(data.posts);
          fetchAllData(currentUser);
        }
      })
      .catch(err => console.error("Bitty profile propagation failed:", err));
  };

  // Render Page Content Layouts
  const renderContent = () => {
    if (!currentUser) {
      return (
        <AuthPortal 
          onLoginSuccess={(user) => {
            setCurrentUser(user);
            localStorage.setItem('talk2bitty_logged_user', JSON.stringify(user));
          }} 
        />
      );
    }

    switch (activeTab) {
      case 'home':
        return (
          <div className="space-y-12 max-w-4xl mx-auto py-4 animate-fadeIn">
            
            {/* Direct Conversational Intro */}
            <div className="space-y-4 max-w-3xl mx-auto bg-zinc-900/40 border border-zinc-850 p-6 md:p-8 rounded-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full filter blur-2xl pointer-events-none"></div>
              <h1 className="text-3xl md:text-4xl font-extrabold text-zinc-100 tracking-tight leading-tight">
                Hey. Life gets weird.
              </h1>
              <p className="text-zinc-300 text-base md:text-lg leading-relaxed font-sans font-medium">
                If you need another perspective, need to vent, need advice, or just want somebody to bullshit with for a bit, that’s basically what this is.
              </p>
            </div>

            {/* Main Grid: Info Cards and Polaroid */}
            <div className="bg-zinc-900 border border-zinc-850 p-6 md:p-10 rounded-2xl relative overflow-hidden">
              <div className="absolute bottom-0 right-0 w-80 h-80 bg-amber-500/[0.012] rounded-full filter blur-3xl pointer-events-none"></div>
              
              <div className="flex flex-col lg:flex-row gap-8 justify-between items-stretch animate-fadeIn">
                
                {/* Left side: Direct Answers to Core Questions */}
                <div className="flex-1 space-y-8 text-zinc-350 text-sm md:text-base leading-relaxed font-sans">
                  
                  {/* Who is Bitty? */}
                  <div className="space-y-1">
                    <h3 className="text-xs font-bold font-mono uppercase tracking-widest text-amber-500">Who is Bitty?</h3>
                    <p className="text-zinc-300">
                      I'm a real person, a mom of three, and a Human Development student. I don’t have clinical counseling certificates or motivational-speaker energy. But I’ve lived through divorce, grief, unhealthy relationships, depression, trust issues, and general chaos. You’re paying for my perspective and my time, not textbook credentials.
                    </p>
                  </div>

                  {/* What is Talk2Bitty? */}
                  <div className="space-y-1">
                    <h3 className="text-xs font-bold font-mono uppercase tracking-widest text-amber-500">What is Talk2Bitty?</h3>
                    <p className="text-zinc-300">
                      A way to hire my time and get a direct, unfiltered viewpoint on whatever situation you’re in. No corporate scripts, no clinical filters, and definitely not an AI bot. Just raw, honest conversation.
                    </p>
                  </div>

                  {/* Why would someone use it? */}
                  <div className="space-y-1">
                    <h3 className="text-xs font-bold font-mono uppercase tracking-widest text-amber-500">Why would someone use it?</h3>
                    <p className="text-zinc-300">
                      Sometimes you can't talk to friends or family because they're biased or you don't want the drama. If you need someone who won't just nod and agree with everything you say, but will tell you the absolute truth from an outside viewpoint, that’s why.
                    </p>
                  </div>

                  {/* What happens next? */}
                  <div className="space-y-1">
                    <h3 className="text-xs font-bold font-mono uppercase tracking-widest text-amber-500">What happens next?</h3>
                    <p className="text-zinc-300">
                      Book an open chat slot, write down what's happening, and send it over. Once I look at it and we connect, we’ll start talking directly over text or secure message threads. Simple as that.
                    </p>
                  </div>

                </div>

                {/* Right side: Photo Frame */}
                <div id="polaroid-sec" className="shrink-0 w-full lg:max-w-[270px] flex flex-col items-center justify-center gap-4 bg-zinc-950/40 p-5 border border-zinc-850 rounded-2xl">
                  <div className="text-center space-y-1">
                    <span className="text-[10px] font-mono font-black uppercase tracking-widest text-zinc-400 bg-zinc-900 px-2.5 py-1 rounded-full">
                      Me (not a stock photo)
                    </span>
                  </div>
                  
                  {/* Polaroid tactile picture frame */}
                  <div 
                    id="polaroid-mock-frame" 
                    onClick={() => {
                      if (currentUser?.isAdmin && !isUploadingPolaroid) {
                        document.getElementById('polaroid-direct-file-input')?.click();
                      }
                    }}
                    className={`relative bg-[#faf7f2] text-zinc-900 p-4 pb-6 rounded-xs w-[80%] sm:w-[85%] md:w-[90%] lg:w-full max-w-[165px] sm:max-w-[195px] md:max-w-[210px] lg:max-w-[185px] border border-zinc-200/90 rotate-[-1.5deg] select-none transition-all duration-300 ease-out hover:rotate-[1.5deg] hover:scale-[1.05] hover:-translate-y-1.5 shadow-[0_15px_30px_rgba(0,0,0,0.35)] hover:shadow-[0_25px_55px_rgba(0,0,0,0.55)] shrink-0 min-w-0 ${currentUser?.isAdmin && !isUploadingPolaroid ? 'cursor-pointer group' : 'cursor-default'}`}
                  >
                    
                    {/* Authentic Shadow filter overlay on Polaroid paper */}
                    <div className="absolute inset-0 bg-gradient-to-tr from-black/[0.02] to-transparent pointer-events-none rounded-xs"></div>
                    
                    {/* Polaroid Square Photo Slot */}
                    <div className="aspect-square w-full bg-zinc-950 relative overflow-hidden rounded-xs border border-zinc-300/40 shadow-inner flex flex-col items-center justify-center">
                      
                      {(() => {
                        const polaroidSlot = globalSettings?.galleryPhotos?.find(p => p.id === 'slot_polaroid');
                        const imgUrl = polaroidSlot?.url || bittyProfile.avatarUrl;
                        
                        if (imgUrl && !imgUrl.startsWith('data:image/svg+xml')) {
                          return (
                            <>
                              <img 
                                src={imgUrl} 
                                alt="Bitty's Photograph" 
                                referrerPolicy="no-referrer"
                                className="w-full h-full object-cover select-none transition-all duration-500 ease-in-out animate-fadeIn hover:scale-[1.02] filter sepia-[0.22] brightness-[0.95] contrast-[1.03] saturate-[0.90]"
                              />
                              {/* Soft warm vignette & sepia color-cast layering */}
                              <div className="absolute inset-0 bg-amber-950/[0.04] mix-blend-color-burn pointer-events-none z-10"></div>
                              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_45%,rgba(60,35,10,0.15)_100%)] mix-blend-multiply pointer-events-none z-10"></div>
                              
                              {/* Fine analog film grain overlay */}
                              <div className="absolute inset-0 opacity-[0.16] mix-blend-overlay pointer-events-none z-10 bg-[radial-gradient(#ffffff_0.8px,transparent_0.8px)] [background-size:6px_6px]"></div>

                              {/* Unobtrusive Download button within the image frame */}
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  const link = document.createElement('a');
                                  link.href = imgUrl;
                                  link.target = '_blank';
                                  link.setAttribute('download', 'bitty_homepage_polaroid.jpg');
                                  document.body.appendChild(link);
                                  link.click();
                                  document.body.removeChild(link);
                                }}
                                className="absolute bottom-2.5 right-2.5 bg-black/75 hover:bg-amber-500 text-zinc-100 hover:text-black p-1.5 rounded-full transition-all duration-200 z-30 shadow-[0_2px_8px_rgba(0,0,0,0.5)] border border-white/20 hover:border-amber-600 hover:scale-110 cursor-pointer flex items-center justify-center"
                                title="Download Photograph"
                              >
                                <Download className="w-3.5 h-3.5" />
                              </button>
                            </>
                          );
                         } else {
                           return (
                             /* Default Placeholder Frame View */
                             <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center bg-zinc-900 text-zinc-500 space-y-2">
                               {currentUser?.isAdmin ? (
                                 <>
                                   <div className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center text-amber-500 border border-zinc-700 shadow-sm animate-pulse">
                                     <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                                       <path strokeLinecap="round" strokeLinejoin="round" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                                       <path strokeLinecap="round" strokeLinejoin="round" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                                     </svg>
                                   </div>
                                   <div className="space-y-1 select-none">
                                     <h4 className="text-[10px] font-mono font-bold text-zinc-300 uppercase tracking-widest leading-none">Photo Slot</h4>
                                     <p className="text-[8px] text-zinc-500 leading-normal font-sans">
                                       Click to upload your polaroid photo
                                     </p>
                                   </div>
                                 </>
                               ) : (
                                 <>
                                   <div className="w-10 h-10 flex items-center justify-center text-amber-600 drop-shadow-[0_0_8px_rgba(245,158,11,0.2)]">
                                     <svg viewBox="0 0 100 100" className="w-9 h-9" fill="none" stroke="currentColor" strokeWidth="3">
                                       <path d="M35,25 C35,25 45,15 60,15 C65,15 70,18 70,23 C70,28 65,32 55,35 M35,25 L35,75 M35,45 C35,45 50,45 65,45 C72,45 78,48 78,55 C78,62 70,68 50,68 L35,68" strokeLinecap="round" strokeLinejoin="round" />
                                     </svg>
                                   </div>
                                   <div className="space-y-0.5 select-none">
                                     <h4 className="text-[10px] font-mono font-bold text-amber-500/85 uppercase tracking-widest leading-none">Feather & Soul</h4>
                                     <span className="text-[8px] text-zinc-450 leading-normal font-sans block uppercase font-bold tracking-wider">
                                       Bitty's Space
                                     </span>
                                   </div>
                                 </>
                               )}
                             </div>
                           );
                         }
                      })()}

                      {/* Interactive hover overlay button strictly for admin users */}
                      {currentUser?.isAdmin && (
                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-center p-3 z-10 rounded-xs select-none pointer-events-none text-white font-mono gap-1">
                          <Upload className="w-5 h-5 text-amber-500 animate-bounce" />
                          <span className="text-[10px] uppercase font-extrabold tracking-wider text-amber-400">Click to Upload</span>
                          <span className="text-[8px] text-zinc-300 leading-tight">Autosaves directly</span>
                        </div>
                      )}

                      {/* Upload Spinner overlay */}
                      {isUploadingPolaroid && (
                        <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center text-center p-3 z-20 rounded-xs text-white font-mono gap-1.5 pointer-events-none">
                          <RefreshCw className="w-6 h-6 text-amber-500 animate-spin" />
                          <span className="text-[9px] uppercase font-bold text-amber-400 tracking-widest animate-pulse">Uploading...</span>
                        </div>
                      )}

                      {/* Success Check overlay */}
                      {polaroidUploadSuccess && (
                        <div className="absolute inset-0 bg-emerald-950/90 flex flex-col items-center justify-center text-center p-3 z-20 rounded-xs text-emerald-400 font-mono gap-1 pointer-events-none">
                          <Check className="w-6 h-6 text-emerald-400 animate-pulse" />
                          <span className="text-[10px] uppercase font-black tracking-widest">Saved!</span>
                        </div>
                      )}

                      {/* Warning Error overlay */}
                      {polaroidUploadError && (
                        <div className="absolute inset-0 bg-red-955/95 flex flex-col items-center justify-center text-center p-3 z-20 rounded-xs text-red-400 font-mono gap-1">
                          <span className="text-[10px] font-bold uppercase tracking-tight">Upload Fail</span>
                          <span className="text-[8px] leading-tight text-red-300">{polaroidUploadError}</span>
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              setPolaroidUploadError(null);
                            }}
                            className="mt-1 text-[8px] bg-red-900/45 border border-red-800 px-2 py-0.5 rounded text-white font-bold cursor-pointer"
                          >
                            Dismiss
                          </button>
                        </div>
                      )}
                      
                    </div>
                    
                    {currentUser?.isAdmin && (
                      <input 
                        type="file" 
                        id="polaroid-direct-file-input" 
                        name="polaroidDirectFile"
                        accept="image/*" 
                        onChange={handlePolaroidDirectUpload} 
                        className="hidden" 
                      />
                    )}

                    {/* Polaroid Bottom Margin Handwritten Label */}
                    {currentUser?.isAdmin ? (
                      isEditingPolaroidCaption ? (
                        <div className="mt-4 text-center cursor-default" onClick={(e) => e.stopPropagation()}>
                          <input
                            type="text"
                            id="polaroid-caption-edit-input"
                            name="polaroidCaption"
                            value={polaroidCaptionInput}
                            onChange={(e) => setPolaroidCaptionInput(e.target.value)}
                            onBlur={() => handleSavePolaroidCaption()}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                handleSavePolaroidCaption();
                              } else if (e.key === 'Escape') {
                                setIsEditingPolaroidCaption(false);
                              }
                            }}
                            autoFocus
                            className="w-full text-center font-serif italic text-zinc-900 bg-amber-500/10 border-b border-amber-500/50 rounded-xs py-0.5 text-base focus:outline-none focus:border-amber-500 focus:bg-amber-100 font-bold"
                            style={{ fontStyle: 'italic' }}
                            maxLength={40}
                          />
                          <div className="text-[8px] text-zinc-500 mt-1 font-mono uppercase tracking-wider select-none animate-pulse">
                            Enter to save • Blur to apply
                          </div>
                        </div>
                      ) : (
                        <div 
                          onClick={(e) => {
                            e.stopPropagation();
                            const currentCap = globalSettings?.galleryPhotos?.find(p => p.id === 'slot_polaroid')?.caption || 'Bitty 🤍';
                            setPolaroidCaptionInput(currentCap);
                            setIsEditingPolaroidCaption(true);
                          }}
                          className="mt-4 text-center font-serif italic text-zinc-800 text-base font-bold tracking-tight select-none cursor-pointer hover:text-amber-600 transition-colors group/caption relative border border-dashed border-transparent hover:border-amber-200 hover:bg-amber-50/40 rounded py-0.5 px-2"
                          title="Click to inline-edit caption"
                        >
                          <span>{globalSettings?.galleryPhotos?.find(p => p.id === 'slot_polaroid')?.caption || 'Bitty 🤍'}</span>
                          <span className="absolute -top-3 right-1 opacity-0 group-hover/caption:opacity-100 transition-all text-[8px] font-mono bg-zinc-900 text-amber-400 py-0.5 px-1 rounded uppercase tracking-wider font-bold shadow">
                            Edit Caption
                          </span>
                        </div>
                      )
                    ) : (
                      <div className="mt-4 text-center font-serif italic text-zinc-800 text-base font-bold tracking-tight select-none">
                        {globalSettings?.galleryPhotos?.find(p => p.id === 'slot_polaroid')?.caption || 'Bitty 🤍'}
                      </div>
                    )}
                  </div>
                  
                  {/* Explanatory captions */}
                  <p className="text-zinc-500 text-[10px] font-medium text-center leading-relaxed font-mono">
                    Directly from my camera.
                  </p>
                </div>

              </div>

            </div>

            {/* My Perspective and Rules */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Perspective Card */}
              <div className="bg-zinc-900/80 border border-zinc-850 p-6 rounded-2xl space-y-4">
                <h3 className="text-sm font-bold text-amber-500 font-mono uppercase tracking-widest">My Perspective 💬</h3>
                <p className="text-zinc-350 text-xs md:text-sm leading-relaxed">
                  I’m not a yes-person. If you want someone to just nod and agree with everything you say, you’re in the wrong place.
                </p>
                <p className="text-zinc-350 text-xs md:text-sm leading-relaxed font-semibold">
                  If I think you’re right, I’ll tell you. If I think you’re wrong, I’ll tell you that too. I give people the benefit of the doubt, but I value boundaries and absolute honesty.
                </p>
              </div>

              {/* Where We Draw The Lines */}
              <div className="bg-zinc-900/80 border border-zinc-850 p-6 rounded-2xl flex flex-col justify-between gap-4">
                <div>
                  <h3 className="text-sm font-bold text-zinc-350 font-mono uppercase tracking-widest border-b border-zinc-800 pb-2">Where to draw lines 🚫</h3>
                  <ul className="space-y-2.5 mt-3 text-zinc-350 text-xs md:text-sm">
                    <li className="flex items-start gap-2">
                      <span className="text-red-500 mr-1">✕</span>
                      <span><strong>Not medical counseling.</strong> No diagnostics or clinical treatments here.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-red-500 mr-1">✕</span>
                      <span><strong>Not a crisis line.</strong> If you’re in immediate danger, go get professional help.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-red-500 mr-1">✕</span>
                      <span><strong>No disrespect.</strong> Romantics, pushy people, or boundary stompers get banned instantly.</span>
                    </li>
                  </ul>
                </div>
              </div>

            </div>

            {/* How chat slots work */}
            <div className="bg-zinc-900 border border-zinc-850 p-8 rounded-2xl space-y-6">
              <h3 className="text-xl font-bold text-zinc-150 uppercase tracking-tight text-center md:text-left font-sans">How this works</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center md:text-left">
                
                <div className="space-y-2">
                  <div className="w-8 h-8 rounded-full bg-zinc-800 text-amber-400 flex items-center justify-center font-bold font-mono text-sm mx-auto md:mx-0">1</div>
                  <h4 className="text-xs font-bold text-zinc-200 uppercase font-mono">Write down your situation</h4>
                  <p className="text-zinc-500 text-[11px] leading-relaxed">Book an open chat slot and write down a quick summary of what you want to talk about.</p>
                </div>

                <div className="space-y-2">
                  <div className="w-8 h-8 rounded-full bg-zinc-800 text-amber-400 flex items-center justify-center font-bold font-mono text-sm mx-auto md:mx-0">2</div>
                  <h4 className="text-xs font-bold text-zinc-200 uppercase font-mono">Submit securely</h4>
                  <p className="text-zinc-500 text-[11px] leading-relaxed font-sans">Checkout via Stripe Sandbox. Nothing is finalized on your card until I personally review and approve your slot request.</p>
                </div>

                <div className="space-y-2">
                  <div className="w-8 h-8 rounded-full bg-zinc-800 text-amber-400 flex items-center justify-center font-bold font-mono text-sm mx-auto md:mx-0">3</div>
                  <h4 className="text-xs font-bold text-zinc-200 uppercase font-mono font-bold">Start chatting</h4>
                  <p className="text-zinc-500 text-[11px] leading-relaxed font-sans">Once approved, our dedicated WhatsApp or offline text line triggers. We'll start talking directly.</p>
                </div>

              </div>
            </div>

            {/* Call to action card */}
            <div className="bg-gradient-to-br from-zinc-900 to-zinc-950 border border-zinc-800 p-8 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="space-y-2">
                <h3 className="text-xl font-bold text-zinc-150 uppercase tracking-tight font-sans">Need direct perspective?</h3>
                <p className="text-zinc-400 text-xs md:text-sm max-w-lg font-sans">
                  Submit an intake pass and let's work on co-parenting paths, relationship chapters, or setting hard boundaries.
                </p>
              </div>
              <button
                onClick={() => setActiveTab('pricing')}
                className="bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black uppercase tracking-wider text-xs px-6 py-3.5 rounded-xl shrink-0 cursor-pointer transition-colors shadow-md shadow-amber-500/10"
              >
                Browse Pass Options
              </button>
            </div>

            {/* Common Questions FAQ section */}
            <div id="common-questions-faq" className="bg-zinc-900 border border-zinc-850 p-8 rounded-2xl space-y-6">
              <div className="flex items-center gap-2 border-b border-zinc-800 pb-4">
                <HelpCircle className="w-5 h-5 text-amber-500" />
                <h3 className="text-xs sm:text-sm font-black font-mono uppercase tracking-widest text-zinc-300">
                  Common Questions
                </h3>
              </div>

              <div className="space-y-4">
                {[
                  {
                    q: "How do I start a conversation?",
                    a: "Pick a pass option, fill out the form, and tell me what is actually on your mind. No sugarcoating, no dressing it up. Once you pay with the sandbox credit card, it logs in my system. I read and respond to every single approved message myself—no bots, no shortcuts."
                  },
                  {
                    q: "What if I need to cancel?",
                    a: "If you buy a pass but change your mind before I start reading or reviewing your topic, you can click cancel on your member dashboard. Your payment stays uncharged or gets released immediately. But once I sit down, read through your background details, and write direct unfiltered perspective back to your inbox, the time is spent. No refunds after that. Simple."
                  },
                  {
                    q: "Is this really Bitty?",
                    a: "Yes. I don't hire assistants to pretend to be me, and I don't use AI tools to generate fake advice. If you ask a question, I'm the person reading it and typing the reply. This means if I'm studying for human development exams, keeping toddlers fed, or managing my cockatoos, it might take a few hours to write back. But when I do reply, it'll be 100% me."
                  }
                ].map((item, index) => {
                  const isOpen = openFaq === index;
                  return (
                    <div 
                      key={index}
                      id={`faq-item-${index}`} 
                      className="border border-zinc-800 bg-zinc-950/40 rounded-xl overflow-hidden transition-all duration-200"
                    >
                      <button
                        type="button"
                        onClick={() => setOpenFaq(isOpen ? null : index)}
                        className="w-full px-5 py-4 text-left flex items-center justify-between gap-4 hover:bg-zinc-850/60 transition-colors cursor-pointer group"
                      >
                        <span className="text-xs sm:text-sm font-black text-zinc-200 group-hover:text-amber-400 transition-colors">
                          {item.q}
                        </span>
                        <span className={`text-[10px] text-zinc-500 group-hover:text-amber-500 transition-transform duration-200 font-mono ${isOpen ? 'rotate-180 text-amber-500' : ''}`}>
                          ▼
                        </span>
                      </button>
                      
                      {isOpen && (
                        <div className="px-5 pb-5 pt-1 text-xs md:text-sm text-zinc-400 leading-relaxed border-t border-zinc-850/60 bg-zinc-950/20 animate-fadeIn">
                          {item.a}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Community Standards Mini Banner */}
            <div className="p-6 bg-zinc-900 border border-zinc-850 rounded-2xl space-y-3 text-xs text-zinc-400">
              <h4 className="font-bold text-zinc-100 uppercase tracking-wider">Community Guidelines</h4>
              <p className="leading-relaxed">
                To keep this space peaceful, support is conversational and empathetic. We do not tolerate advertising, solicitation, flame wars, romantic pressure, or clinical diagnosis. If anyone breaches guidelines on the Community Wall, Bitty maintains full moderation rights to delete posts immediately.
              </p>
            </div>
            
          </div>
        );
      case 'about':
        return <AboutPage globalSettings={globalSettings} />;
      case 'boundaries':
        return <BoundariesPage />;
      case 'pricing':
        return (
          <PricingPage 
            globalSettings={globalSettings}
            onInitiatePurchase={handleInitiatePurchase}
          />
        );
      case 'community':
        return (
          <CommunityWall 
            currentUser={currentUser}
            posts={posts}
            onAddPost={handleAddPost}
            onEditPost={handleEditPost}
            onDeletePost={handleDeletePost}
            onAddComment={handleAddComment}
            onDeleteComment={handleDeleteComment}
            onToggleBittyPick={handleToggleBittyPick}
            onToggleLike={handleToggleLike}
            globalSettings={globalSettings}
          />
        );
      case 'dashboard':
        return (
          <Dashboard 
            currentUser={currentUser}
            requests={requests}
            payments={payments}
            globalSettings={globalSettings}
            onUpdateProfile={handleUpdateProfile}
            onDeleteRequest={handleDeleteRequest}
          />
        );
      case 'admin':
        if (!currentUser.isAdmin) {
          return (
            <div className="max-w-md mx-auto text-center py-16 bg-zinc-900 border border-zinc-850 rounded-2xl space-y-4">
              <ShieldAlert className="w-12 h-12 text-amber-500 mx-auto" />
              <h3 className="text-lg font-bold text-zinc-200 uppercase">Simulated Admin Access Required</h3>
              <p className="text-zinc-500 text-xs px-6 leading-relaxed">
                To view Bitty’s admin settings and process intake applications, toggle the <strong className="text-amber-500">"Demo Mode Switch"</strong> at the top of the header!
              </p>
            </div>
          );
        }
        return (
          <AdminPanel 
            requests={requests}
            payments={payments}
            globalSettings={globalSettings}
            onUpdateSettings={handleUpdateSettings}
            onUpdateRequestStatus={handleUpdateRequestStatus}
            bittyProfile={bittyProfile}
            onUpdateBittyProfile={handleUpdateBittyProfile}
            onDeleteRequest={handleDeleteRequest}
          />
        );
      default:
        return <p className="text-zinc-400">Tab not found.</p>;
    }
  };

  return (
    <div id="talk2bitty-root-theme" className="min-h-screen bg-[#040308] text-zinc-100 font-sans flex flex-col justify-between selection:bg-amber-500 selection:text-zinc-100 relative overflow-x-hidden">
      
      {/* Decorative Cosmic Orb Canvas / Background Ambient Glows */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        {/* Neon Coral Sunset Orb */}
        <div className="absolute -top-40 -left-10 w-[500px] h-[500px] rounded-full bg-gradient-to-br from-amber-500/12 via-purple-600/5 to-transparent filter blur-[100px] animate-aurora opacity-75"></div>
        {/* Royal Lavender Orb */}
        <div className="absolute top-[30%] -right-20 w-[600px] h-[600px] rounded-full bg-gradient-to-tr from-indigo-500/8 via-amber-500/12 to-transparent filter blur-[120px] animate-pulse-slow"></div>
        {/* Cyber Fuchsia Splash */}
        <div className="absolute top-[70%] left-[10%] w-[550px] h-[550px] rounded-full bg-gradient-to-tr from-amber-500/12 via-indigo-600/5 to-transparent filter blur-[110px] animate-aurora opacity-80"></div>
      </div>

      {/* ================= PRIMARY MASTER HEADER ================= */}
      <header className="bg-zinc-900/60 backdrop-blur-md border-b border-zinc-850/80 sticky top-0 z-40 transition-all">
        <div className="max-w-7xl mx-auto px-4 md:px-6 h-16 flex items-center justify-between gap-4">
          
          {/* Logo Brand */}
          <button 
            onClick={() => { setActiveTab('home'); setMobileMenuOpen(false); }}
            className="flex items-center text-left cursor-pointer outline-none bg-transparent"
          >
            <Talk2BittyLogo size="md" />
          </button>

          {/* Desktop Links Navigation */}
          <nav className="hidden md:flex items-center gap-1 text-xs font-mono font-bold">
            <button 
              onClick={() => setActiveTab('home')}
              className={`px-3 py-2 rounded-lg transition-colors uppercase tracking-wider cursor-pointer ${activeTab === 'home' ? 'text-amber-400 bg-zinc-850' : 'text-zinc-400 hover:text-zinc-200'}`}
            >
              Home
            </button>
            <button 
              onClick={() => setActiveTab('about')}
              className={`px-3 py-2 rounded-lg transition-colors uppercase tracking-wider cursor-pointer ${activeTab === 'about' ? 'text-amber-400 bg-zinc-850' : 'text-zinc-400 hover:text-zinc-200'}`}
            >
              About
            </button>
            <button 
              onClick={() => setActiveTab('boundaries')}
              className={`px-3 py-2 rounded-lg transition-colors uppercase tracking-wider cursor-pointer ${activeTab === 'boundaries' ? 'text-amber-400 bg-zinc-850' : 'text-zinc-400 hover:text-zinc-200'}`}
            >
              Boundaries
            </button>
            <button 
              onClick={() => setActiveTab('pricing')}
              className={`px-3 py-2 rounded-lg transition-colors uppercase tracking-wider cursor-pointer ${activeTab === 'pricing' ? 'text-amber-400 bg-zinc-850' : 'text-zinc-400 hover:text-zinc-200'}`}
            >
              Book a Chat
            </button>
            <button 
              onClick={() => setActiveTab('community')}
              className={`px-3 py-2 rounded-lg transition-colors uppercase tracking-wider cursor-pointer ${activeTab === 'community' ? 'text-amber-400 bg-zinc-850' : 'text-zinc-400 hover:text-zinc-200'}`}
            >
              Community
            </button>
            <button 
              onClick={() => setActiveTab('dashboard')}
              className={`px-3 py-2 rounded-lg transition-colors uppercase tracking-wider cursor-pointer ${activeTab === 'dashboard' ? 'text-amber-400 bg-zinc-850' : 'text-zinc-400 hover:text-zinc-200'}`}
            >
              Dashboard
            </button>
            
            <span className="w-px h-4 bg-zinc-800 mx-2"></span>

            <button 
              onClick={() => setActiveTab('admin')}
              className={`px-3 py-2 rounded-lg border uppercase tracking-wider cursor-pointer transition-all flex items-center gap-1.5 ${
                activeTab === 'admin' 
                  ? 'bg-amber-500 border-amber-500 text-zinc-950 font-black' 
                  : currentUser?.isAdmin
                  ? 'border-amber-500/40 text-amber-500 hover:bg-amber-500/10'
                  : 'border-zinc-800 text-zinc-550 hover:text-zinc-350'
              }`}
            >
              <span>Admin Desk</span>
            </button>

            {hasPurchasedPass && (
              <a 
                href={waUrl}
                target="_blank"
                rel="noreferrer"
                id="header-whatsapp-chat-link"
                className="ml-2 px-3 py-2 bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-400 hover:text-emerald-355 rounded-lg transition-all text-xs font-bold uppercase flex items-center gap-1.5 cursor-pointer animate-fadeIn"
              >
                <svg className="w-3.5 h-3.5 fill-emerald-400" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.662c1.746.953 3.71 1.456 5.707 1.456h.001c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
                <span>WhatsApp Live Chat</span>
              </a>
            )}

            {currentUser && (
              <button 
                onClick={handleLogout}
                className="ml-2 px-3 py-2 bg-red-950/20 hover:bg-red-900/10 border border-red-900/20 text-red-500 hover:text-red-400 rounded-lg transition-all text-xs cursor-pointer uppercase font-bold"
              >
                Log Out
              </button>
            )}
          </nav>

          {/* Mobile hamburger */}
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)} 
            className="md:hidden text-zinc-400 hover:text-white cursor-pointer p-1"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>

        </div>
      </header>

      {/* Mobile Nav Overlay Dropdown */}
      {mobileMenuOpen && (
        <div id="mobile-navigation-pane" className="md:hidden bg-zinc-950 border-b border-zinc-900 py-3 px-4 font-mono select-none text-xs flex flex-col gap-2 uppercase tracking-wider text-zinc-300 font-bold animate-fadeIn">
          <button 
            onClick={() => { setActiveTab('home'); setMobileMenuOpen(false); }}
            className={`py-2 text-left px-3 rounded-lg ${activeTab === 'home' ? 'text-amber-400 bg-zinc-900' : ''}`}
          >
            Home / Rules
          </button>
          <button 
            onClick={() => { setActiveTab('about'); setMobileMenuOpen(false); }}
            className={`py-2 text-left px-3 rounded-lg ${activeTab === 'about' ? 'text-amber-400 bg-zinc-900' : ''}`}
          >
            About Bitty
          </button>
          <button 
            onClick={() => { setActiveTab('boundaries'); setMobileMenuOpen(false); }}
            className={`py-2 text-left px-3 rounded-lg ${activeTab === 'boundaries' ? 'text-amber-400 bg-zinc-900' : ''}`}
          >
            Boundaries
          </button>
          <button 
            onClick={() => { setActiveTab('pricing'); setMobileMenuOpen(false); }}
            className={`py-2 text-left px-3 rounded-lg ${activeTab === 'pricing' ? 'text-amber-400 bg-zinc-900' : ''}`}
          >
            Book a Chat
          </button>
          <button 
            onClick={() => { setActiveTab('community'); setMobileMenuOpen(false); }}
            className={`py-2 text-left px-3 rounded-lg ${activeTab === 'community' ? 'text-amber-400 bg-zinc-900' : ''}`}
          >
            Community Wall
          </button>
          <button 
            onClick={() => { setActiveTab('dashboard'); setMobileMenuOpen(false); }}
            className={`py-2 text-left px-3 rounded-lg ${activeTab === 'dashboard' ? 'text-amber-400 bg-zinc-900' : ''}`}
          >
            Member Dashboard
          </button>
          <button 
            onClick={() => { setActiveTab('admin'); setMobileMenuOpen(false); }}
            className={`py-2 text-left px-3 rounded-lg border ${
              activeTab === 'admin' 
                ? 'bg-amber-500 text-zinc-950 border-amber-500 font-black' 
                : 'text-amber-400 border-amber-500/30 bg-amber-500/5'
            }`}
          >
            Admin Desk
          </button>
          {hasPurchasedPass && (
            <a 
              href={waUrl}
              target="_blank"
              rel="noreferrer"
              onClick={() => setMobileMenuOpen(false)}
              id="mobile-whatsapp-chat-link"
              className="py-2.5 text-left px-3 rounded-lg text-emerald-400 hover:bg-emerald-500/5 transition-colors font-bold font-mono flex items-center gap-2 border border-emerald-500/25 bg-emerald-500/5 animate-fadeIn"
            >
              <svg className="w-4 h-4 fill-emerald-400" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.662c1.746.953 3.71 1.456 5.707 1.456h.001c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
              <span>Chat Bitty on WhatsApp</span>
            </a>
          )}
          {currentUser && (
            <button 
              onClick={() => { handleLogout(); setMobileMenuOpen(false); }}
              className="py-2 text-left px-3 rounded-lg text-red-500 hover:bg-red-500/5 transition-colors font-bold font-mono"
            >
              Log Out Session
            </button>
          )}
        </div>
      )}

      {/* ================= MASTER VIEWS AREA ================= */}
      <main className="flex-grow max-w-7xl mx-auto px-4 md:px-6 py-10 w-full relative z-10">
        {renderContent()}
      </main>

      {/* ================= INTAKE & PAYMENTS MODAL DRAWER ================= */}
      {activeIntakeType !== null && currentUser !== null && (
        <IntakeModal 
          passType={activeIntakeType}
          price={activeIntakePrice}
          userId={currentUser.id}
          currentUser={currentUser}
          stripePublishableKey={stripePublishableKey}
          onClose={() => { setActiveIntakeType(null); setActiveIntakePrice(0); }}
          onSubmitRequest={handleCompleteRequestAndPayment}
          enableDrivePortal={globalSettings?.enableDrivePortal}
        />
      )}

      {/* ================= DYNAMIC LEGAL POLICIES DIALOG ================= */}
      {activeLegalTab !== null && (
        <LegalModal 
          initialTab={activeLegalTab} 
          onClose={() => setActiveLegalTab(null)} 
        />
      )}

      {/* ================= STATIC SITE COOPERATIVE FOOTER ================= */}
      <footer id="talk2bitty-footer-pane" className="bg-zinc-950 border-t border-zinc-900 py-10 text-center relative z-10">
        <div className="max-w-4xl mx-auto px-4 space-y-4">
          <div className="flex justify-center items-center gap-1 text-xs text-zinc-500 font-mono">
            <span>Talk2Bitty • Real Human Direct Connection</span>
          </div>
          
          <p className="text-[11px] text-zinc-600 max-w-xl mx-auto leading-relaxed">
            I am a mom of three and a Human Development student. This platform is built purely for empathetic venting and personal perspective. It is not counseling, therapy, medical treatment, or emergency suicide support. If you are in crisis, reach out locally immediately.
          </p>

          {hasPurchasedPass && (
            <div id="footer-whatsapp-container" className="pt-2 pb-4 animate-fadeIn">
              <a 
                href={waUrl}
                target="_blank"
                rel="noreferrer"
                id="footer-whatsapp-chat-link"
                className="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs tracking-wider uppercase transition-all shadow-[0_10px_30px_rgba(16,185,129,0.2)] hover:shadow-[0_10px_30px_rgba(16,185,129,0.4)] active:scale-95 cursor-pointer"
              >
                <svg className="w-4.5 h-4.5 fill-white" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.662c1.746.953 3.71 1.456 5.707 1.456h.001c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
                <span>Connect via WhatsApp Business</span>
              </a>
            </div>
          )}

          <div className="flex flex-wrap justify-center items-center gap-x-4 gap-y-2 text-[10px] font-mono text-zinc-500 font-bold uppercase tracking-wider">
            <button 
              onClick={() => setActiveLegalTab('privacy')} 
              className="hover:text-amber-400 hover:underline cursor-pointer"
            >
              Privacy Policy
            </button>
            <span className="text-zinc-800">•</span>
            <button 
              onClick={() => setActiveLegalTab('terms')} 
              className="hover:text-amber-400 hover:underline cursor-pointer"
            >
              Terms of Service
            </button>
            <span className="text-zinc-800">•</span>
            <button 
              onClick={() => setActiveLegalTab('disclaimer')} 
              className="hover:text-amber-400 hover:underline cursor-pointer"
            >
              Medical Disclaimers
            </button>
            <span className="text-zinc-800">•</span>
            <button 
              onClick={() => setActiveLegalTab('refunds')} 
              className="hover:text-amber-400 hover:underline cursor-pointer"
            >
              Pass Refund Policy
            </button>
          </div>

          <footer className="text-[10px] text-zinc-700 font-mono">
            <span>© 2026 Talk2Bitty Platform. Created for honest, supportive listening loops.</span>
          </footer>
        </div>
      </footer>

      {/* Global Interactive Floating WhatsApp Support Widget */}
      <WhatsAppWidget 
        globalSettings={globalSettings} 
        bittyProfile={bittyProfile} 
      />

    </div>
  );
}
