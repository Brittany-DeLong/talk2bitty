import { UserProfile, Post, ConversationRequest, PaymentRecord, GlobalSettings } from '../types';

export const INITIAL_USER: UserProfile = {
  id: 'user_active_1',
  name: 'Guest Client',
  username: 'guest_client',
  email: 'guest@example.com',
  phone: '555-5555',
  bio: 'Welcome to your safe space.',
  avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
  isAdmin: false,
};

export const INITIAL_BITTY: UserProfile = {
  id: 'bitty_admin',
  name: 'Bitty',
  username: 'bitty',
  email: 'bitty0218@gmail.com',
  phone: '220-710-2021',
  bio: 'Mom of three, Human Development student, cockatoo guardian. Here for raw, honest perspective without the clinical fluff.',
  avatarUrl: '',
  isAdmin: true,
};

export const INITIAL_POSTS: Post[] = [
  {
    id: 'post_1',
    userId: 'bitty_admin',
    userName: 'Bitty',
    userAvatar: '',
    content: `Welcome to Talk2Bitty. 🤍 

I built this space because genuine conversation is becoming incredibly hard to find. We live in a world of fake positivity, perfectly curated influencer feeds, and clinical scripts. Sometimes you just need to talk to a real person who isn't going to feed you textbook answers or judge you for a bad chapter in your book.

We have two cockatoos in our house who are basically feathered toddlers with megaphones, so life is chaotic, messy, and real. That's exactly how I want this platform to be. 

Write a post below. Tell us what's on your mind. Ask for feedback. Or just read and lend a quiet listening ear to others. Keep it honest and kind. We don't do algorithms here.`,
    createdAt: '2026-06-03T10:00:00Z',
    comments: [
      {
        id: 'comment_1_2',
        postId: 'post_1',
        userId: 'user_2',
        userName: 'Marcus Rivera',
        userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
        content: `Refreshing to see a space that doesn't feel like a corporate wellness retreat. Looking forward to connecting here.`,
        createdAt: '2026-06-03T11:42:00Z',
      }
    ]
  },
  {
    id: 'post_2',
    userId: 'user_3',
    userName: 'Clara Hayes',
    userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    content: `Has anyone else struggled with setting boundaries with childhood friends? I find myself holding onto relationships that drains me physically and emotionally, just because "we've known each other for 15 years." 

How do you start letting go of historical guilt? Is there a respectful way to do it?`,
    createdAt: '2026-06-02T16:30:00Z',
    imageUrl: 'https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?w=800',
    comments: [
      {
        id: 'comment_2_1',
        postId: 'post_2',
        userId: 'bitty_admin',
        userName: 'Bitty',
        userAvatar: '',
        content: `Clara, this is huge. Historical guilt is such a powerful anchor. One thing counseling and life taught me is that relationships need to be nourished by who you both are *today*, not who you were at age ten. Letting a friendship naturally fade, or politely saying 'no' to engagements that feel like homework, is a kindness to you both. You aren't a bad person for outgrowing a costume that no longer fits.`,
        createdAt: '2026-06-02T18:10:00Z',
      },
      {
        id: 'comment_2_2',
        postId: 'post_2',
        userId: 'user_4',
        userName: 'Derrick Powell',
        userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
        content: `I had to do this last year. Best decision of my life, even though the dynamic was tense for a few months. It's about self-preservation.`,
        createdAt: '2026-06-02T19:05:00Z',
      }
    ]
  }
];

export const INITIAL_REQUESTS: ConversationRequest[] = [
  {
    id: 'req_2',
    userId: 'user_5',
    userName: 'James K.',
    userEmail: 'jamesk@gmail.com',
    userPhone: '555-8822',
    topic: 'Struggling with trust and intimacy after discovering partner’s infidelity five months ago.',
    preNotes: 'We decided to stay together, but I find myself checking her phone, doubting every delay, and living in constant anxiety. I don’t know if trusting again is actually possible or if I’m stalling the inevitable.',
    agreedToBoundaries: true,
    passType: 'text-15',
    price: 15,
    status: 'pending',
    paymentId: 'ch_sim_881kas9921',
    adminNotes: '',
    createdAt: '2026-06-03T11:05:00Z',
    updatedAt: '2026-06-03T11:05:00Z',
  },
  {
    id: 'req_3',
    userId: 'user_6',
    userName: 'Emma Vance',
    userEmail: 'emmavance1@example.com',
    userPhone: '555-9011',
    topic: 'Career transition and fear of failure at 38.',
    preNotes: 'Laid off after 12 years in corporate data analysis. Thinking of starting my own organizing business, but my family thinks it is highly risky and reckless. I feel suffocated by their "well-meaning" fear.',
    agreedToBoundaries: true,
    passType: 'text-30',
    price: 25,
    status: 'completed',
    paymentId: 'ch_sim_5529kks2f2',
    adminNotes: 'Completed beautiful 30 min session today. Encouraged Emma to map out a 3-month survival runway and run a lightweight pilot before declaring war on family expectations. She felt very relieved.',
    createdAt: '2026-05-28T09:12:00Z',
    updatedAt: '2026-05-28T10:45:00Z',
  }
];

export const INITIAL_PAYMENTS: PaymentRecord[] = [
  {
    id: 'pay_2',
    requestId: 'req_2',
    userId: 'user_5',
    userName: 'James K.',
    amount: 15,
    passType: 'text-15',
    paymentId: 'ch_sim_881kas9921',
    date: '2026-06-03T11:05:00Z',
    status: 'paid',
  },
  {
    id: 'pay_3',
    requestId: 'req_3',
    userId: 'user_6',
    userName: 'Emma Vance',
    amount: 25,
    passType: 'text-30',
    paymentId: 'ch_sim_5529kks2f2',
    date: '2026-05-28T09:12:00Z',
    status: 'paid',
  }
];

export const INITIAL_SETTINGS: GlobalSettings = {
  isAvailable: true,
  availabilityStatus: 'open',
  unavailableMessage: 'Bitty is currently offline for child-wrangling, exams, or cockatoo-taming. Feel free to browse the community and check back later.',
  waitlistMessage: 'Bitty is currently full and running on waitlist mode. Enter your email to be the first to know when standard conversation slots open back up!',
  contactType: 'whatsapp',
  customContactInfo: '220-710-2021',
  enableDrivePortal: false,
};
