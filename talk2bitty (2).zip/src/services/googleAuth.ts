import { initializeApp } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider, onAuthStateChanged, User } from 'firebase/auth';
import { getStorage, ref, uploadString, getDownloadURL, deleteObject } from 'firebase/storage';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase using the provisioned applet configuration
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const storage = getStorage(app);

// Default provider for normal authentication (secure, no sensitive OAuth scopes requested)
const defaultProvider = new GoogleAuthProvider();

// Drive-specific provider created when the user explicitly interacts with the Drive browser
const driveProvider = new GoogleAuthProvider();
driveProvider.addScope('https://www.googleapis.com/auth/drive');

let isSigningIn = false;
let cachedAccessToken: string | null = null;

// Initialize auth state listener. Call this on app load.
export const initGoogleAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      if (cachedAccessToken) {
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
      } else if (!isSigningIn) {
        cachedAccessToken = null;
        if (onAuthFailure) onAuthFailure();
      }
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

// Must be called from a button click or user interaction
// requestDriveAccess defaults to false so standard user logins are fast, secure and don't trigger "Unverified App" warnings
export const googleSignIn = async (requestDriveAccess: boolean = false): Promise<{ user: User; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const activeProvider = requestDriveAccess ? driveProvider : defaultProvider;
    const result = await signInWithPopup(auth, activeProvider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Failed to retrieve access token from Google Sign-In.');
    }

    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    const isClosedByUser = error?.code === 'auth/popup-closed-by-user' || 
                           error?.message?.includes('popup-closed-by-user');
    if (!isClosedByUser) {
      console.error('Google Sign-In Error:', error);
    } else {
      console.log('Google Sign-In cancelled/closed by user.');
    }
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const getCachedAccessToken = (): string | null => {
  return cachedAccessToken;
};

export const setCachedAccessToken = (token: string | null) => {
  cachedAccessToken = token;
};

export const googleLogout = async () => {
  await auth.signOut();
  cachedAccessToken = null;
};

// Google Drive API Helpers

export interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
  iconLink?: string;
  thumbnailLink?: string;
  webViewLink?: string;
  size?: string;
  modifiedTime?: string;
}

/**
 * Fetch files from the authorized user's Google Drive
 */
export const listGoogleDriveFiles = async (token: string, searchTheme?: string): Promise<DriveFile[]> => {
  try {
    let url = 'https://www.googleapis.com/drive/v3/files?fields=files(id,name,mimeType,iconLink,thumbnailLink,webViewLink,size,modifiedTime)&pageSize=30';
    if (searchTheme) {
      // Filter by searches
      const query = encodeURIComponent(`name contains '${searchTheme.replace(/'/g, "\\'")}'`);
      url += `&q=${query}`;
    }
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      if (response.status === 401) {
        // Token has expired or is invalid
        setCachedAccessToken(null);
        throw new Error('Google session expired. Please sign in again.');
      }
      const errData = await response.json().catch(() => ({}));
      throw new Error(errData.error?.message || 'Failed to list Google Drive files.');
    }

    const data = await response.json();
    return data.files || [];
  } catch (error: any) {
    console.error('List Drive files error:', error);
    throw error;
  }
};

/**
 * Upload a local file directly into Google Drive
 */
export const uploadFileToGoogleDrive = async (token: string, file: File): Promise<DriveFile> => {
  try {
    // We do a multipart upload or simple upload
    // For general uploads, a simple upload is fine, or metadata + media
    const metadata = {
      name: file.name,
      mimeType: file.type || 'application/octet-stream',
    };

    const formData = new FormData();
    formData.append(
      'metadata',
      new Blob([JSON.stringify(metadata)], { type: 'application/json' })
    );
    formData.append('file', file);

    const response = await fetch(
      'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,webViewLink',
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      }
    );

    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      throw new Error(errData.error?.message || 'Failed to upload file to Google Drive.');
    }

    return await response.json();
  } catch (error: any) {
    console.error('Upload Drive file error:', error);
    throw error;
  }
};

/**
 * Delete a file in Google Drive
 */
export const deleteGoogleDriveFile = async (token: string, fileId: string): Promise<boolean> => {
  try {
    const response = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}`, {
      method: 'DELETE',
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      throw new Error(errData.error?.message || 'Failed to delete file from Google Drive.');
    }

    return true;
  } catch (error: any) {
    console.error('Delete Drive file error:', error);
    throw error;
  }
};

/**
 * Upload a Base64 data URL string directly into Google / Firebase Storage bucket
 */
export const uploadBase64ToFirebaseStorage = async (base64DataUrl: string, customFileName: string): Promise<string> => {
  // 1. Try server-side upload proxy, which supports custom GCP GCS buckets (via STORAGE_BUCKET) & local static file fallback
  try {
    const response = await fetch('/api/upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ base64DataUrl, fileName: customFileName })
    });
    if (response.ok) {
      const data = await response.json();
      if (data.url) {
        console.log("Successfully processed upload via server-side API:", data.url);
        return data.url;
      }
    }
  } catch (err) {
    console.warn("Server upload API failed, falling back to direct Firebase Storage client:", err);
  }

  // 2. Direct client-side upload to Firebase Storage (with fast retry-limit bounds and a 3.5s timeout)
  try {
    // Avoid default 120s retry intervals on hanging connections
    storage.maxUploadRetryTime = 2500;
    storage.maxOperationRetryTime = 2500;
  } catch (e) {
    console.warn("Could not set storage retry settings:", e);
  }

  const uploadPromise = (async () => {
    const filename = `${Date.now()}_${customFileName.replace(/[^a-zA-Z0-9.\-_]/g, '_')}`;
    const storageRef = ref(storage, `bitty_photographs/${filename}`);
    await uploadString(storageRef, base64DataUrl, 'data_url');
    const downloadURL = await getDownloadURL(storageRef);
    return downloadURL;
  })();

  const timeoutPromise = new Promise<never>((_, reject) => {
    setTimeout(() => reject(new Error('Firebase Storage direct upload timed out.')), 3500);
  });

  try {
    return await Promise.race([uploadPromise, timeoutPromise]);
  } catch (error: any) {
    console.warn('Direct Firebase Storage upload failed or timed out. Falling back to inline base64 string:', error);
    // Return the base64 URL directly so that the application remains fully functional even without Storage bucket activation!
    return base64DataUrl;
  }
};

/**
 * Delete a file directly from Firebase Storage bucket by its URL
 */
export const deleteFileFromFirebaseStorageByUrl = async (fileUrl: string): Promise<boolean> => {
  try {
    const decodedUrl = decodeURIComponent(fileUrl);
    const pathMatch = decodedUrl.match(/\/o\/(.*?)(?:\?|$)/);
    if (!pathMatch || !pathMatch[1]) {
      console.warn('Could not extract path from storage URL, removing reference only.', fileUrl);
      return false;
    }
    const pathInBucket = pathMatch[1];
    const fileRef = ref(storage, pathInBucket);
    await deleteObject(fileRef);
    return true;
  } catch (error: any) {
    console.error('Firebase Storage delete failure:', error);
    return true;
  }
};
