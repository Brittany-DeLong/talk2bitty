import { PassType } from '../types';

export interface StripeCheckoutResponse {
  success: boolean;
  paymentId: string;
  amount: number;
  passType: PassType;
  brand: string;
  last4: string;
  receiptUrl: string;
  clientSecret: string;
  created: string;
}

export interface StripeCardDetails {
  cardNumber: string;
  cardExpiry: string;
  cardCvc: string;
  cardZip: string;
}

/**
 * Service to simulate Stripe Checkout & Charges APIs.
 * Includes card structure validations, status outputs, and receipt link builders.
 */
export const stripeCheckoutService = {
  /**
   * Processes a simulated Stripe payment charge.
   * Throws detailed Stripe-like errors if details fail validation.
   */
  processCheckout: async (
    card: StripeCardDetails,
    price: number,
    passType: PassType
  ): Promise<StripeCheckoutResponse> => {
    return new Promise((resolve, reject) => {
      // Simulate real network delay for high-fidelity experience
      setTimeout(() => {
        const { cardNumber, cardExpiry, cardCvc, cardZip } = card;

        // Clean values
        const cleanCard = cardNumber.replace(/\s+/g, '');
        const cleanExpiry = cardExpiry.replace(/\s+/g, '');
        const cleanCvc = cardCvc.replace(/\s+/g, '');
        const cleanZip = cardZip.trim();

        // 1. Basic empty check
        if (!cleanCard || !cleanExpiry || !cleanCvc || !cleanZip) {
          reject(new Error("Your card details are incomplete. Please review and fill every field."));
          return;
        }

        // 2. Validate Card Number (16 digits)
        if (cleanCard.length < 16 || !/^\d+$/.test(cleanCard)) {
          reject(new Error("Your card number is invalid. It should consist of exactly 16 digits."));
          return;
        }

        // 3. Expiration Date Validation (MM/YY)
        if (!/^\d{2}\/\d{2}$/.test(cleanExpiry)) {
          reject(new Error("Your card's expiration date is invalid. Please use the MM/YY format."));
          return;
        }

        const [monthStr, yearStr] = cleanExpiry.split('/');
        const month = parseInt(monthStr, 10);
        const year = parseInt(yearStr, 10);

        if (month < 1 || month > 12) {
          reject(new Error("Your card's expiration month is invalid. Must be between 01 and 12."));
          return;
        }

        // Check if card is expired (simulated current year is 2026 as per local time)
        const currentYearShort = 26; // 2026
        const currentMonth = 6;     // June 2026
        if (year < currentYearShort || (year === currentYearShort && month < currentMonth)) {
          reject(new Error("Your card has expired. Please try again with a valid, active card."));
          return;
        }

        // 4. CVC Check (3 digits)
        if (cleanCvc.length < 3 || !/^\d+$/.test(cleanCvc)) {
          reject(new Error("Your card's security code is invalid. CVC must contain exactly 3 digits."));
          return;
        }

        // 5. ZIP Check
        if (cleanZip.length < 3) {
          reject(new Error("The zip or postal code provided is invalid."));
          return;
        }

        // Success! Generate custom Stripe payment details
        const randId = Math.random().toString(36).substring(2, 11).toUpperCase();
        const paymentId = `ch_stripe_${randId}`;
        const last4 = cleanCard.slice(-4);
        const clientSecret = `src_client_secret_${Math.random().toString(36).substring(2, 22)}`;
        
        resolve({
          success: true,
          paymentId,
          amount: price,
          passType,
          brand: cleanCard.startsWith('4') ? 'Visa' : 'Mastercard',
          last4,
          receiptUrl: `https://stripe-mock-receipts.s3.amazonaws.com/receipts/${paymentId}.html`,
          clientSecret,
          created: new Date().toISOString()
        });
      }, 1800);
    });
  }
};
