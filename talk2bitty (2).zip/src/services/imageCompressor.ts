/**
 * Image compressor and resizer utility for client-side execution.
 * Reduces dimension limits and adjusts quality to keep network payload performant.
 */

interface CompressOptions {
  maxWidth?: number;
  maxHeight?: number;
  quality?: number;
  fallbackMimeType?: string;
}

const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((res) => {
    const reader = new FileReader();
    reader.onloadend = () => res(reader.result as string);
    reader.onerror = () => res('');
    reader.readAsDataURL(file);
  });
};

/**
 * Compresses an image (either a File object or a Base64 string data URL)
 * and returns a promise resolving with a compressed Base64 data URL.
 * Includes multiple layers of safety:
 * 1. Only sets crossOrigin for external URLs to prevent canvas taint issues on local data URLs.
 * 2. Catches any canvas or browser render exceptions and falls back gracefully to the original image.
 * 3. Incorporates a fast-timeout fallback so it NEVER blocks user actions if image rendering hangs.
 */
export const compressImage = (
  input: File | string,
  options: CompressOptions = {}
): Promise<string> => {
  const {
    maxWidth = 1200,
    maxHeight = 1200,
    quality = 0.75,
    fallbackMimeType = 'image/jpeg'
  } = options;

  return new Promise(async (resolve) => {
    let resolved = false;

    // A helper function to safely resolve with fallback base64
    const resolveWithFallback = async () => {
      if (resolved) return;
      resolved = true;
      try {
        if (input instanceof File) {
          const base64 = await fileToBase64(input);
          resolve(base64);
        } else {
          resolve(input);
        }
      } catch (err) {
        // Ultimate fallback
        resolve(typeof input === 'string' ? input : '');
      }
    };

    // Safety timeout: if compression takes more than 1500ms, fall back to the original image
    const timeoutId = setTimeout(() => {
      console.warn('Image compression timed out. Falling back to the original image.');
      resolveWithFallback();
    }, 1500);

    try {
      let src: string;

      if (input instanceof File) {
        src = URL.createObjectURL(input);
      } else {
        src = input;
      }

      const img = new Image();
      
      // Only set crossOrigin if we are loading an external domain image (http/https scheme)
      if (typeof src === 'string' && src.startsWith('http')) {
        img.crossOrigin = 'anonymous';
      }

      img.onload = () => {
        if (resolved) {
          if (input instanceof File) URL.revokeObjectURL(src);
          return;
        }

        try {
          let width = img.width;
          let height = img.height;

          // Double check for invalid/0/NaN dimensions
          if (!width || !height) {
            if (input instanceof File) URL.revokeObjectURL(src);
            clearTimeout(timeoutId);
            resolveWithFallback();
            return;
          }

          // Calculate scale-down dimensions preserving ratio
          if (width > maxWidth || height > maxHeight) {
            const widthRatio = maxWidth / width;
            const heightRatio = maxHeight / height;
            const bestRatio = Math.min(widthRatio, heightRatio);

            width = Math.round(width * bestRatio);
            height = Math.round(height * bestRatio);
          }

          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;

          const ctx = canvas.getContext('2d');
          if (!ctx) {
            throw new Error('Failed to obtain canvas 2D render context.');
          }

          // Draw onto canvas
          ctx.drawImage(img, 0, 0, width, height);

          // Determine the output mime type
          let mimeType = fallbackMimeType;
          if (input instanceof File && input.type) {
            mimeType = input.type;
          } else if (typeof input === 'string' && input.startsWith('data:')) {
            const match = input.match(/data:([^;]+);/);
            if (match && match[1]) {
              mimeType = match[1];
            }
          }

          // Convert PNG to JPEG for massive speed/payload performance benefits
          let finalMime = mimeType;
          if (mimeType === 'image/png') {
            finalMime = 'image/jpeg';
          }

          let dataUrl = '';
          try {
            dataUrl = canvas.toDataURL(finalMime, quality);
          } catch (err) {
            // Fallback to basic JPEG if toDataURL fails on premium mimes
            dataUrl = canvas.toDataURL('image/jpeg', quality);
          }

          if (input instanceof File) {
            URL.revokeObjectURL(src);
          }

          clearTimeout(timeoutId);
          resolved = true;
          resolve(dataUrl);

        } catch (onloadErr) {
          console.error('Error processing loaded image canvas:', onloadErr);
          if (input instanceof File) {
            URL.revokeObjectURL(src);
          }
          clearTimeout(timeoutId);
          resolveWithFallback();
        }
      };

      img.onerror = (err) => {
        console.error('Failed to load image element for compression:', err);
        if (input instanceof File) {
          URL.revokeObjectURL(src);
        }
        clearTimeout(timeoutId);
        resolveWithFallback();
      };

      img.src = src;

    } catch (generalErr) {
      console.error('General failure in compressImage initialization:', generalErr);
      clearTimeout(timeoutId);
      resolveWithFallback();
    }
  });
};
