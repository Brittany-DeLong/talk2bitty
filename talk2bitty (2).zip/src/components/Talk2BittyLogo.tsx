import React from 'react';

interface Talk2BittyLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  theme?: 'light' | 'dark' | 'glass';
}

export default function Talk2BittyLogo({ 
  className = "", 
  size = 'md', 
  theme = 'glass' 
}: Talk2BittyLogoProps) {
  
  // Size-specific dimensions
  const bubbleSizeClass = 
    size === 'sm' ? "w-7 h-7 text-sm" : 
    size === 'md' ? "w-8.5 h-8.5 text-base" : 
    "w-11 h-11 text-xl";
    
  const textClass = 
    size === 'sm' ? "text-xs tracking-wider" : 
    size === 'md' ? "text-sm tracking-widest" : 
    "text-lg tracking-widest";

  const subTextClass = 
    size === 'sm' ? "text-[7.5px]" : 
    size === 'md' ? "text-[9.5px]" : 
    "text-[10px]";

  return (
    <div id="talk2bitty-main-logo" className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* Speech Bubble Icon with '2' */}
      <div className={`relative ${bubbleSizeClass} flex items-center justify-center bg-gradient-to-tr from-[#7c3aed] to-[#06b6d4] rounded-[11px] font-black text-white shadow-[0_4px_15px_rgba(124,58,237,0.35)] shrink-0 select-none transition-transform duration-300 hover:scale-[1.04]`}>
        2
        {/* Chat bubble tail */}
        <div className="absolute -bottom-1 left-2 w-2.5 h-2.5 bg-[#7c3aed] rotate-45 rounded-[2px] origin-top"></div>
      </div>
      
      {/* Brand Text */}
      <div className="flex flex-col">
        <span className={`font-black uppercase text-zinc-100 ${textClass}`}>
          Talk<span className="bg-gradient-to-r from-amber-400 to-amber-500 bg-clip-text text-transparent font-extrabold">2</span>Bitty
        </span>
        <span className={`text-zinc-500 font-mono font-extrabold uppercase tracking-widest leading-none ${subTextClass}`}>
          Human Connection
        </span>
      </div>
    </div>
  );
}
