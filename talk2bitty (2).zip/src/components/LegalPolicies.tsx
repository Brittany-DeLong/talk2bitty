import React from 'react';
import { Shield } from 'lucide-react';

interface LegalPoliciesProps {
  className?: string;
  showTitle?: boolean;
}

export default function LegalPolicies({ className = '', showTitle = true }: LegalPoliciesProps) {
  return (
    <div id="legal-policies-panel" className={`space-y-4 select-text text-left text-xs text-zinc-400 ${className}`}>
      {showTitle && (
        <div className="space-y-1 select-none text-left">
          <div className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-zinc-950 border border-zinc-850 rounded text-[10px] uppercase font-mono text-zinc-400">
            <Shield className="w-3 h-3 text-amber-500" />
            <span>Essential Boundaries</span>
          </div>
          <p className="text-[11px] leading-relaxed text-zinc-500 italic mt-1 pl-1">
            "We draw a clear line between raw human empathy and clinical medicine." — Bitty
          </p>
        </div>
      )}

      <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-xl space-y-3 text-xs">
        <p className="leading-relaxed text-zinc-350">
          <strong>I am not a professional:</strong> I am a student of Human Development, a mother of three, and a peer listener. I am NOT a licensed psychologist, clinical counselor, psychiatrist, social worker, healthcare doctor, or legal therapist. No diagnoses, medical prescriptions, treatment plans, or clinical entries are made here.
        </p>
        
        <p className="leading-relaxed text-zinc-350">
          <strong>No medical or legal counsel:</strong> Our written messages are for daily coping, vent sharing, and general real-world perspectives. If you are dealing with custody disputes, legal battles, divorce litigation, or formal mental health diagnoses, please consult credentialed specialists.
        </p>

        <p className="leading-relaxed border-t border-zinc-900 pt-3 text-red-400/90 font-medium">
          <strong>Emergency / Crisis Disclaimer:</strong> We are strictly an asynchronous peer-to-peer venting space. If you feel you may harm yourself or others, please exit this tab and IMMEDIATELY call or text the Suicide & Crisis Lifeline at <strong className="text-zinc-100 font-extrabold select-all select-all">988</strong>, or text <strong className="text-zinc-100 font-extrabold select-all select-all">HOME to 741741</strong> for free, confidential, 24/7 professional assistance.
        </p>
      </div>
    </div>
  );
}
