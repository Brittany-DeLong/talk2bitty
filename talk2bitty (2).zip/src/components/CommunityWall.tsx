import React, { useState } from 'react';
import { Post, Comment, UserProfile, GlobalSettings } from '../types';
import { Trash2, Edit2, MessageSquare, Send, ShieldAlert, Image, X, Clock, Upload, Sparkles, Crop, Camera, Heart } from 'lucide-react';
import ImageCropperModal from './ImageCropperModal';
import { uploadBase64ToFirebaseStorage } from '../services/googleAuth';
import { compressImage } from '../services/imageCompressor';

interface CommunityWallProps {
  currentUser: UserProfile;
  posts: Post[];
  onAddPost: (content: string, imageUrl?: string) => void;
  onEditPost: (postId: string, newContent: string) => void;
  onDeletePost: (postId: string) => void;
  onAddComment: (postId: string, content: string) => void;
  onDeleteComment: (postId: string, commentId: string) => void;
  onToggleBittyPick?: (postId: string) => void;
  onToggleLike?: (postId: string) => void;
  globalSettings?: GlobalSettings;
}

// Beautiful static images people can attach to simulated posts
const PREMADE_IMAGES = [
  { id: 'img-1', url: 'https://images.unsplash.com/photo-1501854140801-50d01698950b?w=600', label: 'Forest' },
  { id: 'img-2', url: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=600', label: 'Meadow' },
  { id: 'img-3', url: 'https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?w=600', label: 'River' },
  { id: 'img-4', url: 'https://images.unsplash.com/photo-1472214222541-d510753a49fa?w=600', label: 'Sunset' },
];

export default function CommunityWall({
  currentUser,
  posts,
  onAddPost,
  onEditPost,
  onDeletePost,
  onAddComment,
  onDeleteComment,
  onToggleBittyPick,
  onToggleLike,
  globalSettings,
}: CommunityWallProps) {
  // Post Creation States
  const [newPostText, setNewPostText] = useState('');
  const [selectedImageUrl, setSelectedImageUrl] = useState<string | undefined>(undefined);
  const [showImageSelector, setShowImageSelector] = useState(false);
  const [customImageUrl, setCustomImageUrl] = useState('');
  const [rawImageSrc, setRawImageSrc] = useState<string | null>(null);
  const [isPosting, setIsPosting] = useState(false);

  // Comment Creation States (Mapped by postId)
  const [commentInputs, setCommentInputs] = useState<{ [postId: string]: string }>({});

  // Editing States
  const [editingPostId, setEditingPostId] = useState<string | null>(null);
  const [editingPostText, setEditingPostText] = useState('');

  const [uploadError, setUploadError] = useState<string | null>(null);

  const handleLocalFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setUploadError("Only image files (JPEG, PNG, etc.) are allowed.");
      return;
    }

    // Limit size to roughly 2MB to preserve capacity comfortably
    if (file.size > 2 * 1024 * 1024) {
      setUploadError("Image too large (Max 2MB to ensure cloud/local sync holds).");
      return;
    }

    setUploadError(null);
    const reader = new FileReader();
    reader.onloadend = () => {
      setRawImageSrc(reader.result as string);
    };
    reader.onerror = () => {
      setUploadError("Failed to parse local image file.");
    };
    reader.readAsDataURL(file);
  };

  const handlePostSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostText.trim() || isPosting) return;

    setIsPosting(true);
    setUploadError(null);

    try {
      let finalImageUrl = selectedImageUrl;

      if (customImageUrl && customImageUrl.startsWith('data:')) {
        // It's a base64 image, let's compress it to enhance performance (Max 1200x1200px, 75% quality)
        let compressedBase64 = customImageUrl;
        try {
          compressedBase64 = await compressImage(customImageUrl, { maxWidth: 1200, maxHeight: 1200, quality: 0.75 });
        } catch (compressErr) {
          console.warn("Client-side image compression failed before upload, using cropped original:", compressErr);
        }

        // Upload the compressed Base64 image to Firebase Storage!
        const uploadedUrl = await uploadBase64ToFirebaseStorage(compressedBase64, 'user_post.jpg');
        finalImageUrl = uploadedUrl;
      } else if (customImageUrl) {
        finalImageUrl = customImageUrl;
      }

      onAddPost(newPostText, finalImageUrl || undefined);
      setNewPostText('');
      setSelectedImageUrl(undefined);
      setCustomImageUrl('');
      setShowImageSelector(false);
    } catch (err: any) {
      console.error("Upload error during post submission:", err);
      setUploadError(err.message || "Failed to upload post image to storage.");
    } finally {
      setIsPosting(false);
    }
  };

  const handleStartEdit = (post: Post) => {
    setEditingPostId(post.id);
    setEditingPostText(post.content);
  };

  const handleSaveEdit = (postId: string) => {
    if (!editingPostText.trim()) return;
    onEditPost(postId, editingPostText);
    setEditingPostId(null);
  };

  const CommentList = ({ post }: { post: Post }) => {
    const activeCommentText = commentInputs[post.id] || '';
    const likesCount = post.likes ? post.likes.length : 0;
    const hasLiked = post.likes ? post.likes.includes(currentUser.id) : false;

    const handleCommentSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (!activeCommentText.trim()) return;
      onAddComment(post.id, activeCommentText);
      setCommentInputs((prev) => ({ ...prev, [post.id]: '' }));
    };

    return (
      <div className="space-y-4 pt-4 border-t border-zinc-850 mt-4">
        {/* Engagement toolbar containing Reactions (likes) and comment count */}
        <div className="flex items-center justify-between border-b border-zinc-850/60 pb-3 mb-1 flex-wrap gap-2">
          {/* Reaction Button */}
          <button
            type="button"
            onClick={() => onToggleLike && onToggleLike(post.id)}
            className={`flex items-center gap-2 group cursor-pointer transition-all duration-350 text-xs font-mono py-1.5 px-3 rounded-lg border ${
              hasLiked
                ? 'bg-rose-500/10 border-rose-500/25 text-rose-400 font-black'
                : 'border-zinc-850 bg-zinc-950/40 text-zinc-500 hover:text-rose-450 hover:border-rose-500/20'
            }`}
            title={hasLiked ? "Unlike this post" : "Like this post"}
          >
            <Heart 
              className={`w-3.5 h-3.5 transition-transform duration-300 ${
                hasLiked 
                  ? 'fill-rose-500 text-rose-500 scale-110 active:scale-90' 
                  : 'group-hover:scale-115 group-hover:text-rose-400 group-active:scale-95'
              }`}
            />
            <span className="font-bold tracking-wider uppercase text-[10px]">
              {hasLiked ? 'Liked' : 'Like'} ({likesCount})
            </span>
          </button>

          {/* Comment count header */}
          <div className="text-zinc-550 font-mono text-[10px] uppercase tracking-wider flex items-center gap-1.5 select-none">
            <MessageSquare className="w-3.5 h-3.5 text-zinc-650" />
            <span>Comments ({post.comments?.length || 0})</span>
          </div>
        </div>

        {/* Chronological list of comments */}
        {post.comments && post.comments.length > 0 && (
          <div className="space-y-3 pl-3 md:pl-4 border-l border-zinc-800">
            {post.comments.map((comment: Comment) => {
              const isAdminComment = comment.userId === 'bitty_admin';
              const canDeleteComment = comment.userId === currentUser.id || currentUser.isAdmin;
              
              return (
                <div key={comment.id} className="text-xs space-y-1 group">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      {comment.userAvatar ? (
                        <img 
                          src={comment.userAvatar} 
                          alt={comment.userName} 
                          referrerPolicy="no-referrer"
                          className={`w-5.5 h-5.5 rounded-full object-cover ${isAdminComment ? 'border border-amber-500/50' : 'border border-zinc-700'}`}
                        />
                      ) : (
                        <div className={`w-5.5 h-5.5 rounded-full flex items-center justify-center font-black text-[9px] text-zinc-950 uppercase shrink-0 select-none ${isAdminComment ? 'bg-gradient-to-br from-amber-400 to-amber-650' : 'bg-zinc-800 text-zinc-300 border border-zinc-700'}`}>
                          {comment.userName.charAt(0)}
                        </div>
                      )}
                      <span className={`font-mono font-bold ${isAdminComment ? 'text-amber-400' : 'text-zinc-300'}`}>
                        {comment.userName}
                      </span>
                      {isAdminComment && (
                        <span className="text-[9px] bg-amber-500/10 text-amber-500 px-1 py-0.2 border border-amber-500/20 rounded">
                          ADMIN
                        </span>
                      )}
                      <span className="text-[10px] text-zinc-550 font-mono">
                        {new Date(comment.createdAt).toLocaleDateString()}
                      </span>
                    </div>

                    {canDeleteComment && (
                      <button 
                        onClick={() => onDeleteComment(post.id, comment.id)}
                        className="text-zinc-650 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer p-0.5"
                        title={currentUser.isAdmin && comment.userId !== currentUser.id ? "Moderate Comment" : "Delete Comment"}
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                  <p className="text-zinc-350 leading-relaxed pl-7 break-words font-medium">{comment.content}</p>
                </div>
              );
            })}
          </div>
        )}

        {/* Write a comment input form */}
        <form onSubmit={handleCommentSubmit} className="flex gap-2 items-center pl-7">
          <input 
            type="text" 
            id={`comment-input-${post.id}`}
            name="comment"
            placeholder="Write a supportive reply..."
            value={activeCommentText}
            onChange={(e) => setCommentInputs((prev) => ({ ...prev, [post.id]: e.target.value }))}
            className="flex-1 bg-zinc-950 border border-zinc-850 text-zinc-250 text-xs rounded-lg px-3 py-2 focus:outline-none focus:border-zinc-750"
          />
          <button 
            type="submit"
            className="p-2 rounded-lg bg-zinc-800 text-zinc-300 hover:bg-zinc-700 hover:text-white transition-colors cursor-pointer"
          >
            <Send className="w-3 h-3" />
          </button>
        </form>
      </div>
    );
  };

  const communityPhoto = globalSettings?.galleryPhotos?.find(p => p.id === 'slot_community');

  return (
    <div className="max-w-3xl mx-auto space-y-8 py-4 animate-fadeIn">
      {/* Intro block */}
      <div className="space-y-4 text-center">
        <div className="space-y-1">
          <h2 className="text-2xl font-black text-zinc-100 uppercase tracking-tight">The Community Wall</h2>
          <p className="text-zinc-450 text-xs md:text-sm">
            A raw, chronological board for connection. Share your story, lend perspective, react to insights, or read silently. No complex algorithms or followers.
          </p>
        </div>

        {communityPhoto?.url && (
          <div className="max-w-[280px] sm:max-w-[320px] mx-auto bg-[#faf7f2] p-3 pb-5 rounded-xs shadow-md border border-zinc-250 text-zinc-900 duration-500 transition-all hover:rotate-2 hover:scale-[1.02] rotate-[-1deg] select-none shrink-0">
            <div className="aspect-[4/3] overflow-hidden bg-zinc-950 rounded-xs border border-zinc-300/40 shadow-inner">
              <img 
                src={communityPhoto.url} 
                alt={communityPhoto.caption || "Community anchor"} 
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover select-none"
              />
            </div>
            <p className="font-serif italic text-xs mt-3 text-zinc-850 font-bold tracking-tight">
              {communityPhoto.caption || "Community Bulletin board snapshot 📸"}
            </p>
          </div>
        )}
      </div>

      {/* New Post Creator Form */}
      <form onSubmit={handlePostSubmit} className="bg-zinc-900 border border-zinc-800 p-5 rounded-2xl space-y-4">
        <div className="flex gap-3">
          <img 
            src={currentUser.avatarUrl} 
            alt={currentUser.name} 
            referrerPolicy="no-referrer"
            className="w-10 h-10 rounded-xl object-cover border border-zinc-700"
          />
          <textarea 
            rows={3}
            id="community-new-post-content"
            name="postContent"
            placeholder="Let’s be honest. What is weighing on you today?"
            value={newPostText}
            onChange={(e) => setNewPostText(e.target.value)}
            className="flex-1 bg-transparent text-zinc-100 text-xs md:text-sm placeholder-zinc-500 focus:outline-none resize-none pt-2"
          />
        </div>

        {/* Image Attachment Indicator */}
        {(selectedImageUrl || customImageUrl) && (
          <div className="relative inline-block ml-13">
            <img 
              src={selectedImageUrl || customImageUrl} 
              alt="Post attachment" 
              referrerPolicy="no-referrer"
              className="w-24 h-24 object-cover rounded-xl border border-zinc-800"
            />
            <div className="absolute -top-1.5 -right-1.5 flex gap-1.5">
              {customImageUrl && (
                <button
                  type="button"
                  onClick={() => setRawImageSrc(customImageUrl)}
                  className="bg-amber-500 text-zinc-950 rounded-full p-0.5 shadow-md hover:bg-amber-400 cursor-pointer flex items-center justify-center"
                  title="Crop Photo"
                >
                  <Crop className="w-3 h-3 stroke-[2.5]" />
                </button>
              )}
              <button
                type="button"
                onClick={() => {
                  setSelectedImageUrl(undefined);
                  setCustomImageUrl('');
                }}
                className="bg-red-500 text-white rounded-full p-0.5 shadow-md hover:bg-red-400 cursor-pointer flex items-center justify-center"
                title="Remove Photo"
              >
                <X className="w-3 h-3 stroke-[2.5]" />
              </button>
            </div>
          </div>
        )}

        <div className="pt-3 border-t border-zinc-850 flex items-center justify-between gap-4 flex-wrap">
          {/* Attach Controls */}
          <div className="flex items-center gap-2">
            {/* Direct Uploader (The "Regular Way") */}
            <label className="flex items-center gap-1.5 text-[11px] font-mono px-3 py-1.5 rounded-lg border border-dashed border-zinc-800 bg-zinc-950 text-zinc-400 hover:text-amber-400 hover:border-amber-500/30 transition-all uppercase tracking-wider cursor-pointer font-black select-none">
              <Upload className="w-3.5 h-3.5 text-zinc-500 group-hover:text-amber-400" />
              <span>{customImageUrl ? 'Photo Attached ✓' : 'Upload Photo'}</span>
              <input 
                type="file" 
                id="community-photo-upload-direct"
                name="directPhotoFile"
                accept="image/*"
                onChange={handleLocalFileChange}
                className="hidden" 
              />
            </label>

            <span className="text-zinc-800 text-xs font-mono font-bold select-none">or</span>

            <button 
              type="button"
              onClick={() => setShowImageSelector(!showImageSelector)}
              className={`flex items-center gap-1.5 text-[11px] font-mono px-3 py-1.5 rounded-lg border uppercase tracking-wider transition-colors cursor-pointer ${
                showImageSelector || selectedImageUrl
                  ? 'border-amber-500/30 bg-amber-500/5 text-amber-400'
                  : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Image className="w-3.5 h-3.5" />
              <span>Premade / Link</span>
            </button>
          </div>

          <button 
            type="submit"
            disabled={!newPostText.trim() || isPosting}
            className={`px-5 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-colors flex items-center gap-1.5 ${
              newPostText.trim() && !isPosting
                ? 'bg-amber-500 hover:bg-amber-400 text-zinc-950 cursor-pointer'
                : 'bg-zinc-805 text-zinc-500 cursor-not-allowed'
            }`}
          >
            {isPosting ? 'Uploading...' : 'Post to Wall'}
          </button>
        </div>

        {/* Collapsible Image Selection Panel */}
        {showImageSelector && (
          <div className="p-4 bg-zinc-950 border border-zinc-850 rounded-xl space-y-3 animate-fadeIn">
            <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-black">Choose illustrative photo or insert link</p>
            
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {PREMADE_IMAGES.map((img) => (
                <button
                  key={img.id}
                  type="button"
                  onClick={() => {
                    setSelectedImageUrl(img.url);
                    setCustomImageUrl('');
                  }}
                  className={`relative h-16 rounded-lg overflow-hidden border-2 transition-all cursor-pointer ${
                    selectedImageUrl === img.url ? 'border-amber-500' : 'border-zinc-800 hover:border-zinc-700'
                  }`}
                >
                  <img src={img.url} alt={img.label} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/45 flex items-center justify-center">
                    <span className="text-[10px] text-zinc-300 font-mono font-medium">{img.label}</span>
                  </div>
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-2 font-mono">
              <div className="relative">
                <input 
                  type="url" 
                  id="community-photo-url-input"
                  name="customPhotoUrl"
                  placeholder="Paste image address (HTTPS)..."
                  value={customImageUrl.startsWith('data:') ? '' : customImageUrl}
                  onChange={(e) => {
                    setCustomImageUrl(e.target.value);
                    setSelectedImageUrl(undefined);
                    setUploadError(null);
                  }}
                  className="w-full bg-zinc-900 border border-zinc-800 text-zinc-200 text-xs rounded-xl px-3.5 py-3 pr-16 focus:outline-none focus:border-amber-500/40"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[9px] font-mono text-zinc-500 pointer-events-none">URL</span>
              </div>

              <div>
                <label className="flex items-center justify-center gap-2 bg-zinc-900 hover:bg-zinc-850 border border-dashed border-zinc-800 hover:border-amber-500/30 text-zinc-400 hover:text-amber-400 px-3 py-3.5 rounded-xl cursor-pointer transition-colors text-xs font-mono uppercase font-black text-center h-full select-none">
                  <Upload className="w-3.5 h-3.5" />
                  <span>{customImageUrl ? 'Image Attached ✓' : 'Upload & Crop Photo'}</span>
                  <input 
                    type="file" 
                    id="community-photo-upload-crop"
                    name="cropPhotoFile"
                    accept="image/*"
                    onChange={handleLocalFileChange}
                    className="hidden" 
                  />
                </label>
              </div>
            </div>

            {uploadError && (
              <p className="text-[10px] font-mono text-red-400 font-bold tracking-wider uppercase bg-red-500/5 px-2.5 py-1.5 rounded-lg border border-red-500/10">
                {uploadError}
              </p>
            )}
          </div>
        )}

        {rawImageSrc && (
          <ImageCropperModal
            imageSrc={rawImageSrc}
            onCrop={(cropped) => {
              setCustomImageUrl(cropped);
              setSelectedImageUrl(undefined);
              setRawImageSrc(null);
            }}
            onClose={() => setRawImageSrc(null)}
          />
        )}
      </form>

      {/* List of Posts */}
      <div className="space-y-6">
        {posts && posts.length > 0 ? (
          posts.map((post: Post) => {
            const isMyPost = post.userId === currentUser.id;
            const canModerate = currentUser.isAdmin;
            const isEditing = editingPostId === post.id;
            const isBittyPost = post.userId === 'bitty_admin';

            const wordCount = post.content.trim().split(/\s+/).filter(Boolean).length;
            const minutesToRead = Math.ceil(wordCount / 200);
            const isLongForm = wordCount >= 30;

            return (
              <div 
                key={post.id} 
                className={`border bg-zinc-90 w-full p-6 bg-zinc-900 rounded-2xl flex flex-col gap-4 relative overflow-hidden transition-all duration-300 ${
                  post.isBittyPick 
                    ? 'border-amber-500/70 shadow-[0px_0px_22px_0px_rgba(245,158,11,0.08)] ring-1 ring-amber-500/25 bg-zinc-900/95'
                    : isBittyPost 
                    ? 'border-amber-500/30 shadow-[0px_0px_15px_0px_rgba(245,158,11,0.03)]' 
                    : 'border-zinc-850'
                }`}
              >
                {/* Header info */}
                <div className="flex justify-between items-start gap-4">
                  <div className="flex items-center gap-3">
                    {post.userAvatar ? (
                      <img 
                        src={post.userAvatar} 
                        alt={post.userName} 
                        referrerPolicy="no-referrer"
                        className={`w-10 h-10 rounded-xl object-cover ${
                          post.isBittyPick 
                            ? 'border-2 border-amber-500' 
                            : isBittyPost 
                            ? 'border-2 border-amber-500/40' 
                            : 'border border-zinc-850'
                        }`}
                      />
                    ) : (
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm text-zinc-950 uppercase shrink-0 select-none ${
                        isBittyPost 
                          ? 'bg-gradient-to-br from-amber-400 to-amber-650' 
                          : 'bg-zinc-800 text-zinc-300 border border-zinc-750'
                      }`}>
                        {post.userName.charAt(0)}
                      </div>
                    )}
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className={`text-sm font-black ${isBittyPost ? 'text-amber-400' : 'text-zinc-200'}`}>
                          {post.userName}
                        </span>
                        {isBittyPost && (
                          <span className="text-[10px] font-mono font-black border border-amber-500/30 bg-amber-500/10 text-amber-500 px-1.5 py-0.2 rounded-md">
                            ADMIN • BITTY
                          </span>
                        )}
                        {post.isBittyPick && (
                          <span className="inline-flex items-center gap-1 text-[9px] font-mono font-black border border-amber-500/40 bg-amber-500/10 text-amber-500 px-1.5 py-0.2 rounded-md tracking-wider animate-fadeIn">
                            <Sparkles className="w-3 h-3 text-amber-400 fill-amber-400/25" />
                            <span>BITTY'S PICK</span>
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5 text-[10px] text-zinc-500 font-mono flex-wrap">
                        <span>
                          {new Date(post.createdAt).toLocaleDateString()} at {new Date(post.createdAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                        </span>
                        {isLongForm && (
                          <>
                            <span className="text-zinc-700">•</span>
                            <span className="flex items-center gap-0.8 text-amber-500/80 font-bold text-[9px] uppercase tracking-wider">
                              <Clock className="w-3 h-3" />
                              <span>{minutesToRead} {minutesToRead === 1 ? 'min' : 'mins'} read</span>
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Actions (Only own posts OR admin moderation) */}
                  <div className="flex items-center gap-1.5 flex-wrap justify-end">
                    {currentUser.isAdmin && onToggleBittyPick && (
                      <button 
                        onClick={() => onToggleBittyPick(post.id)}
                        className={`p-1.5 rounded-lg border text-[10px] font-mono uppercase font-black tracking-wider transition-all duration-200 cursor-pointer flex items-center gap-1 ${
                          post.isBittyPick
                            ? 'bg-amber-500/15 border-amber-500/40 text-amber-400 hover:bg-amber-500/25 shadow-sm shadow-amber-500/15'
                            : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:text-amber-400 hover:border-amber-500/30'
                        }`}
                        title={post.isBittyPick ? "Remove Bitty's Pick" : "Tag as Bitty's Pick"}
                      >
                        <Sparkles className={`w-3.5 h-3.5 ${post.isBittyPick ? 'text-amber-400 fill-amber-400/40 animate-pulse' : 'text-zinc-500'}`} />
                        <span className="hidden xs:inline">{post.isBittyPick ? "Picked" : "Pick"}</span>
                      </button>
                    )}

                    {currentUser.isAdmin && !isMyPost && (
                      <div className="flex items-center gap-1.5 bg-red-955/20 border border-red-900/30 py-1 px-2.5 rounded-lg text-red-400 text-[10px] font-mono uppercase tracking-wider select-none shrink-0">
                        <ShieldAlert className="w-3.5 h-3.5" />
                        <span>MOD MODE</span>
                      </div>
                    )}
                    
                    {isMyPost && !isEditing && (
                      <button 
                        onClick={() => handleStartEdit(post)}
                        className="text-zinc-500 hover:text-amber-500 p-1.5 hover:bg-zinc-950 rounded-lg cursor-pointer transition-colors"
                        title="Edit post"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                    )}

                    {(isMyPost || canModerate) && (
                      <button 
                        onClick={() => onDeletePost(post.id)}
                        className="text-zinc-500 hover:text-red-400 p-1.5 hover:bg-zinc-950 rounded-lg cursor-pointer transition-colors"
                        title={currentUser.isAdmin && !isMyPost ? "Moderate: Delete Post" : "Delete post"}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Body Content */}
                {isEditing ? (
                  <div className="space-y-2">
                    <textarea 
                      rows={3}
                      value={editingPostText}
                      onChange={(e) => setEditingPostText(e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3.5 text-zinc-100 text-xs focus:ring-0 focus:outline-none"
                    />
                    <div className="flex gap-2 justify-end">
                      <button 
                        onClick={() => setEditingPostId(null)}
                        className="text-xs bg-zinc-800 text-zinc-300 px-4 py-2 rounded-lg hover:bg-zinc-700 cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button 
                        onClick={() => handleSaveEdit(post.id)}
                        className="text-xs bg-amber-500 text-zinc-905 font-bold px-4 py-2 rounded-lg hover:bg-amber-400 cursor-pointer"
                      >
                        Save
                      </button>
                    </div>
                  </div>
                ) : (
                  <p className="text-zinc-200 text-xs md:text-sm leading-relaxed whitespace-pre-wrap font-medium break-words">
                    {post.content}
                  </p>
                )}

                {/* Attachment photo */}
                {post.imageUrl && (
                  <div className="rounded-xl overflow-hidden border border-zinc-800 max-h-80 select-none">
                    <img 
                      src={post.imageUrl} 
                      alt="Attached imagery" 
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}

                {/* Comment Section Tree */}
                <CommentList post={post} />

              </div>
            );
          })
        ) : (
          <div className="text-center py-12 bg-zinc-900 rounded-2xl border border-zinc-850 text-zinc-500">
            <p className="text-sm font-mono uppercase">The wall is currently silent...</p>
            <p className="text-xs text-zinc-600 mt-1">Be the very first one to drop your thoughts.</p>
          </div>
        )}
      </div>
    </div>
  );
}
