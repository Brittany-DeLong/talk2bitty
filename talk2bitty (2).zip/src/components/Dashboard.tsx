import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, ConversationRequest, PaymentRecord, GlobalSettings } from '../types';
import { 
  Edit2, Shield, Calendar, Clock, CreditCard, CheckCircle2, User, 
  Phone, Mail, FileText, Check, Crop, Upload, HardDrive, ExternalLink,
  Trash2, ShieldAlert, Volume2, Mic, MicOff, PhoneOff, Play, Pause,
  RotateCcw, Sparkles, Activity, Send, MessageSquare
} from 'lucide-react';
import ImageCropperModal from './ImageCropperModal';
import DriveBrowser from './DriveBrowser';

interface DashboardProps {
  currentUser: UserProfile;
  requests: ConversationRequest[];
  payments: PaymentRecord[];
  globalSettings: GlobalSettings;
  onUpdateProfile: (updatedProfile: UserProfile) => Promise<any> | void;
  onDeleteRequest?: (requestId: string) => void;
}

export default function Dashboard({ 
  currentUser, 
  requests, 
  payments, 
  globalSettings, 
  onUpdateProfile,
  onDeleteRequest 
}: DashboardProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(currentUser.name);
  const [editUsername, setEditUsername] = useState(currentUser.username || '');
  const [editPhone, setEditPhone] = useState(currentUser.phone);
  const [editEmail, setEditEmail] = useState(currentUser.email);
  const [editBio, setEditBio] = useState(currentUser.bio || '');
  const [editAvatar, setEditAvatar] = useState(currentUser.avatarUrl);
  const [rawImageSrc, setRawImageSrc] = useState<string | null>(null);
  const [avatarError, setAvatarError] = useState('');
  const [submitError, setSubmitError] = useState('');

  // Interactive Voice Lobby/Room states for clients
  const [activeClientCallId, setActiveClientCallId] = useState<string | null>(null);
  const [clientTimerSeconds, setClientTimerSeconds] = useState<number>(15 * 60);
  const [clientTimerIsActive, setClientTimerIsActive] = useState<boolean>(false);
  const [clientMuteState, setClientMuteState] = useState<boolean>(false);
  const [clientSpeakerState, setClientSpeakerState] = useState<boolean>(false);

  // Interactive Live Chat sandbox states
  const [chatMessages, setChatMessages] = useState<{ sender: 'user' | 'bitty'; text: string; timestamp: Date }[]>([]);
  const [typedMessage, setTypedMessage] = useState('');
  const [isBittyTyping, setIsBittyTyping] = useState(false);

  // Auto initialize chat when slot is active
  useEffect(() => {
    if (activeClientCallId) {
      const matchingReq = requests.find(r => r.id === activeClientCallId);
      if (matchingReq) {
        setChatMessages([
          {
            sender: 'bitty',
            text: `Hey! I saw your request on "${matchingReq.topic}". Thank you for sharing that with me. I'm sitting down with some hot tea right now. What's the heaviest part of it for you currently?`,
            timestamp: new Date()
          }
        ]);
      }
    } else {
      setChatMessages([]);
    }
  }, [activeClientCallId]);

  const handleSendChatMessage = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanMsg = typedMessage.trim();
    if (!cleanMsg) return;

    // Append user message
    const userMsg = { sender: 'user' as const, text: cleanMsg, timestamp: new Date() };
    setChatMessages((prev) => [...prev, userMsg]);
    setTypedMessage('');
    setIsBittyTyping(true);

    // List of response options
    const bittyAnswers = [
      "I hear you. Human stuff is always so messy. Don't beat yourself up too much over it - we're all just stumbling through this. What do you think your gut reaction is telling you to do?",
      "Honestly? That sounds incredibly exhausting. If I were in your shoes, I'd probably be screaming into a pillow too. Do you feel like you've been carrying this all on your own?",
      "That's a tough spot. Sometimes the hardest part of these situations is admitting we don't have a single bit of control over how other people act. You can't fix them, but you can protect your own peace.",
      "My cockatoos are screaming in the background right now, but I'm reading every word. It's okay to feel completely lost sometimes. Seriously. Nobody has their life completely sorted out, even if they pretend they do.",
      "You're giving yourself a really hard time here. Give yourself some grace. Tell me: what would you advise a best friend to do if they came to you with this exact story?",
      "I get that. Sometimes we just need to vent we aren't looking for a perfect strategy or blueprint, we just need to release the pressure valve. Keep writing it out, I'm here."
    ];

    const randomResponse = bittyAnswers[Math.floor(Math.random() * bittyAnswers.length)];

    setTimeout(() => {
      setIsBittyTyping(false);
      setChatMessages((prev) => [
        ...prev,
        {
          sender: 'bitty' as const,
          text: randomResponse,
          timestamp: new Date()
        }
      ]);
    }, 2500);
  };

  // WhatsApp Setup States
  const [whatsappStatus, setWhatsappStatus] = useState<'has_app' | 'need_app'>('has_app');
  const [whatsappCheckApp, setWhatsappCheckApp] = useState<boolean>(false);
  const [whatsappCheckMessage, setWhatsappCheckMessage] = useState<boolean>(false);

  // Status Change Pulse Alerts
  const [statusUpdateAlerts, setStatusUpdateAlerts] = useState<Record<string, boolean>>({});
  const prevStatuses = useRef<Record<string, string>>({});

  useEffect(() => {
    let triggeredAny = false;
    const nextAlerts = { ...statusUpdateAlerts };

    userRequests.forEach(req => {
      const prev = prevStatuses.current[req.id];
      if (prev && prev !== req.status) {
        nextAlerts[req.id] = true;
        triggeredAny = true;

        // Visual pulses fade out and clear after 8 seconds
        setTimeout(() => {
          setStatusUpdateAlerts(prev => ({
            ...prev,
            [req.id]: false
          }));
        }, 8000);
      }
      prevStatuses.current[req.id] = req.status;
    });

    if (triggeredAny) {
      setStatusUpdateAlerts(nextAlerts);
    }
  }, [requests, currentUser.id]);

  // Client timer ticking countdown
  useEffect(() => {
    let ticker: any = null;
    if (clientTimerIsActive && clientTimerSeconds > 0) {
      ticker = setInterval(() => {
        setClientTimerSeconds((prev) => prev - 1);
      }, 1000);
    } else if (clientTimerSeconds === 0 && clientTimerIsActive) {
      setClientTimerIsActive(false);
    }
    return () => clearInterval(ticker);
  }, [clientTimerIsActive, clientTimerSeconds]);

  const handleUserPhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setAvatarError("Only image files are permitted.");
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      setAvatarError("Image is too large (must be under 2MB).");
      return;
    }

    setAvatarError('');
    const reader = new FileReader();
    reader.onloadend = () => {
      setRawImageSrc(reader.result as string);
    };
    reader.onerror = () => {
      setAvatarError("Failed to import selected file.");
    };
    reader.readAsDataURL(file);
  };

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError('');

    if (!editUsername.trim()) {
      setSubmitError('Username handle is required.');
      return;
    }

    try {
      const res: any = await onUpdateProfile({
        ...currentUser,
        name: editName,
        username: editUsername.toLowerCase().trim().replace(/[^a-z0-9_]/g, '_'),
        phone: editPhone,
        email: editEmail,
        bio: editBio,
        avatarUrl: editAvatar,
      });

      if (res && res.success === false) {
        setSubmitError(res.error || 'Failed to update profile.');
      } else {
        setIsEditing(false);
      }
    } catch (err: any) {
      setSubmitError(err.message || 'An unexpected editing error occurred.');
    }
  };

  // Filter requests that belong to this user
  const userRequests = requests.filter(r => r.userId === currentUser.id);
  const userPayments = payments.filter(p => p.userId === currentUser.id);

  // Status badge style compiler
  const getStatusBadge = (status: ConversationRequest['status']) => {
    switch (status) {
      case 'pending': 
        return <span className="bg-amber-500/10 text-amber-505 px-2.5 py-1 rounded-lg border border-amber-500/20 text-[10px] font-mono uppercase font-black">Pending Approval</span>;
      case 'approved': 
        return <span className="bg-indigo-500/10 text-indigo-400 px-2.5 py-1 rounded-lg border border-indigo-500/20 text-[10px] font-mono uppercase font-black">Approved • Scheduling</span>;
      case 'active': 
        return <span className="bg-emerald-500/10 text-emerald-400 px-2.5 py-1 rounded-lg border border-emerald-500/20 text-[10px] font-mono uppercase font-black animate-pulse">Session Active</span>;
      case 'completed': 
        return <span className="bg-zinc-800 text-zinc-400 px-2.5 py-1 rounded-lg border border-zinc-700 text-[10px] font-mono uppercase font-black">Completed</span>;
      case 'declined': 
        return <span className="bg-red-500/10 text-red-400 px-2.5 py-1 rounded-lg border border-red-500/20 text-[10px] font-mono uppercase font-black">Declined</span>;
      case 'refunded': 
        return <span className="bg-zinc-950 text-zinc-550 px-2.5 py-1 rounded-lg border border-zinc-850 text-[10px] font-mono uppercase font-black">Refunded</span>;
    }
  };

  const getStatusDescription = (status: ConversationRequest['status']) => {
    switch (status) {
      case 'pending': 
        return 'Bitty is currently reading over your situation details and checking her schedules. She will get back to you and approve or decline this within 24 hours.';
      case 'approved': 
        return 'Awesome! Bitty approved your chat request. Check below for your hotline details and how to kick things off on WhatsApp.';
      case 'active': 
        return 'Our chat window is in progress right now! Send a WhatsApp message to get the conversation moving.';
      case 'completed': 
        return 'This 1-on-1 chat slot has finished up. Read Bitty\'s take below, or check out the Community Wall to see what others are saying.';
      case 'declined': 
        return 'Bitty reviewed your message and felt this situation is best discussed with a licensed professional therapist. No charge was submitted, or your funds have been completely released.';
      case 'refunded': 
        return 'Transaction has been released. The full purchase amount was sent back to your credit card.';
    }
  };

  // Helper to format MM:SS Clock
  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-6xl mx-auto space-y-10 py-4">
      {/* Short Text Header */}
      <div className="space-y-1 select-none">
        <h2 className="text-2xl font-black text-zinc-100 uppercase tracking-tight">Your Member Station</h2>
        <p className="text-zinc-450 text-xs text-left">
          Manage your personal details, verify text-session approval, and view transaction records.
        </p>
      </div>      {/* SECURE CALLER INTERACTIVE ROOM PORTAL */}
      {activeClientCallId && (() => {
        const matchingReq = userRequests.find(r => r.id === activeClientCallId);
        if (!matchingReq) return null;
        
        return (
          <div className="bg-gradient-to-b from-purple-950/25 to-zinc-950 border-2 border-purple-500/25 rounded-3xl p-6 space-y-6 animate-fadeIn relative overflow-hidden text-left">
            <div className="absolute top-0 right-0 w-80 h-80 bg-purple-500/[0.02] rounded-full filter blur-3xl pointer-events-none"></div>
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-850 pb-4">
              <div className="space-y-1">
                <span className="text-[9px] font-mono bg-purple-500/25 text-purple-300 font-bold uppercase py-0.5 px-2 rounded">
                  Private Written Dialogue Room
                </span>
                <h3 className="text-base font-black text-zinc-100 uppercase font-mono tracking-wider flex items-center gap-2 mt-1">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse"></span>
                  💬 1-on-1 Conversation Stage
                </h3>
              </div>
              <button
                onClick={() => {
                  setClientTimerIsActive(false);
                  setActiveClientCallId(null);
                }}
                className="text-[10px] font-mono font-bold text-zinc-400 hover:text-white uppercase bg-zinc-900 border border-zinc-800 px-3 py-1.5 rounded-xl transition-all outline-none cursor-pointer"
              >
                Close Chat Console
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-stretch">
              
              {/* Message Box Side */}
              <div className="md:col-span-8 bg-zinc-950/80 border border-zinc-850 rounded-2xl p-4 flex flex-col justify-between min-h-[420px] max-h-[480px]">
                
                {/* Scrollable messages container */}
                <div className="flex-1 overflow-y-auto space-y-4 pr-1 mb-4 select-text max-h-[380px]">
                  {chatMessages.map((msg, i) => {
                    const isBitty = msg.sender === 'bitty';
                    return (
                      <div 
                        key={i} 
                        className={`flex gap-3 max-w-[85%] ${isBitty ? 'self-start mr-auto' : 'self-end ml-auto flex-row-reverse text-right'}`}
                      >
                        {isBitty && (
                          <div className="w-8 h-8 rounded-full bg-purple-500/20 text-purple-300 flex items-center justify-center font-bold text-xs shrink-0 select-none">
                            B
                          </div>
                        )}
                        <div className="space-y-1">
                          <div className={`p-3 rounded-2xl text-xs md:text-sm leading-relaxed ${
                            isBitty 
                              ? 'bg-zinc-900 text-zinc-200 rounded-tl-none border border-zinc-800' 
                              : 'bg-purple-900/60 text-zinc-100 rounded-tr-none border border-purple-800/40'
                          }`}>
                            {msg.text}
                          </div>
                          <span className="text-[8.5px] font-mono text-zinc-500 block px-1">
                            {msg.timestamp.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}
                          </span>
                        </div>
                      </div>
                    );
                  })}

                  {isBittyTyping && (
                    <div className="flex gap-3 max-w-[85%] self-start mr-auto items-center">
                      <div className="w-8 h-8 rounded-full bg-purple-500/20 text-purple-300 flex items-center justify-center font-bold text-xs shrink-0">
                        B
                      </div>
                      <div className="bg-zinc-900 text-zinc-400 p-3 rounded-2xl rounded-tl-none border border-zinc-800 text-xs flex items-center gap-1.5 font-mono">
                        <span className="w-1.5 h-1.5 bg-zinc-500 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></span>
                        <span className="w-1.5 h-1.5 bg-zinc-500 rounded-full animate-bounce" style={{ animationDelay: '0.15s' }}></span>
                        <span className="w-1.5 h-1.5 bg-zinc-500 rounded-full animate-bounce" style={{ animationDelay: '0.3s' }}></span>
                        <span className="text-[10px] ml-1">Bitty is writing down reflections...</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Submit text input */}
                <form onSubmit={handleSendChatMessage} className="flex gap-2 pt-2 border-t border-zinc-900">
                  <input 
                    type="text" 
                    id="dashboard-chat-message-input"
                    name="chatMessage"
                    value={typedMessage} 
                    onChange={(e) => setTypedMessage(e.target.value)}
                    placeholder={clientTimerIsActive ? "Type your written thoughts to Bitty..." : "Start the clock to type a response..."}
                    disabled={!clientTimerIsActive || isBittyTyping}
                    className="flex-grow bg-zinc-900 border border-zinc-800 text-zinc-200 text-xs sm:text-sm rounded-xl px-4 py-3 focus:outline-none focus:border-purple-500 disabled:opacity-50 disabled:cursor-not-allowed"
                  />
                  <button 
                    type="submit" 
                    disabled={!clientTimerIsActive || !typedMessage.trim() || isBittyTyping}
                    className="bg-purple-600 hover:bg-purple-500 text-zinc-100 p-3 rounded-xl disabled:opacity-40 disabled:cursor-not-allowed transition-colors shrink-0 flex items-center justify-center"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>

              </div>

              {/* Status and Clock Sidebar Side */}
              <div className="md:col-span-4 bg-zinc-900/40 p-5 border border-zinc-850 rounded-2xl flex flex-col justify-between space-y-6">
                
                <div className="space-y-4">
                  <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider font-extrabold block">Synchronous Timer Clock</span>
                  
                  {/* Countdown Clock Display */}
                  <div className="bg-zinc-950 border border-zinc-850 rounded-2xl py-6 px-4 text-center space-y-1 relative overflow-hidden shadow-inner font-mono">
                    <span className="absolute top-1.5 right-2 text-[8px] text-purple-400 bg-purple-500/10 px-1.5 py-0.5 rounded uppercase font-bold tracking-wider">
                      Live Space
                    </span>
                    <div className="text-4xl text-purple-400 font-black tracking-widest tabular-nums drop-shadow-[0_0_8px_rgba(168,85,247,0.15)]">
                      {formatTimer(clientTimerSeconds)}
                    </div>
                    <span className="text-[9px] text-zinc-550 uppercase font-mono tracking-wider">Remaining Attention</span>
                  </div>
                </div>

                <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-xl space-y-1">
                  <span className="text-[10px] font-mono text-amber-500 font-bold block uppercase tracking-wide">Secure written dialogue</span>
                  <p className="text-[10.5px] text-zinc-400 leading-relaxed">
                    This sandbox terminal lets you sketch thoughts and gather your words at your own pace. Bitty respects your rhythm – take all the time you need.
                  </p>
                </div>

                {/* Trigger Button */}
                <div className="space-y-2">
                  {!clientTimerIsActive ? (
                    <button 
                      onClick={() => {
                        setClientTimerSeconds(matchingReq.passType === 'text-30' ? 30 * 60 : 15 * 60);
                        setClientTimerIsActive(true);
                      }}
                      className="w-full bg-purple-600 hover:bg-purple-500 text-zinc-100 font-black text-xs py-3 rounded-xl uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-purple-500/5 transition-all text-center"
                    >
                      <Clock className="w-4 h-4 text-zinc-100" />
                      <span>Start Attention Clock</span>
                    </button>
                  ) : (
                    <button 
                      onClick={() => setClientTimerIsActive(false)}
                      className="w-full bg-zinc-800 hover:bg-zinc-750 text-zinc-200 font-black text-xs py-3 rounded-xl uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer transition-all text-center"
                    >
                      <Pause className="w-4 h-4" />
                      <span>Pause Attention Clock</span>
                    </button>
                  )}
                </div>

              </div>

            </div>

          </div>
        );
      })()}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        
        {/* Left Column: Profile Card + Editor */}
        <div className="space-y-6 lg:sticky lg:top-4 text-left">
          <div className="bg-zinc-900 border border-zinc-850 rounded-2xl p-6 space-y-6">
            
            <div className="flex items-center justify-between border-b border-zinc-850 pb-4">
              <h3 className="text-sm font-black text-zinc-300 uppercase font-mono tracking-wider">Account Profile</h3>
              {!isEditing && (
                <button 
                  onClick={() => setIsEditing(true)}
                  className="text-zinc-405 hover:text-amber-500 flex items-center gap-1.5 text-xs font-mono font-bold uppercase transition-colors cursor-pointer"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  <span>Edit</span>
                </button>
              )}
            </div>

            {isEditing ? (
              <form onSubmit={handleProfileSubmit} className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-mono text-zinc-550 uppercase font-black">Avatar Photo</label>
                  </div>
                  
                  <div className="bg-zinc-955 p-4 rounded-2xl border border-zinc-850 space-y-3.5">
                    {/* Input field + Preview group */}
                    <div className="flex items-center gap-3">
                      {editAvatar ? (
                        <img 
                          src={editAvatar} 
                          alt="Avatar Preview" 
                          className="w-12 h-12 rounded-xl object-cover border border-zinc-800 shrink-0"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="w-12 h-12 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-500 font-mono text-xs shrink-0">
                          N/A
                        </div>
                      )}

                      <div className="flex-1 space-y-1">
                        <label className="text-[9px] font-mono text-zinc-550 uppercase tracking-wider block">Avatar Link / URL Address</label>
                        <input 
                          type="url" 
                          id="dashboard-user-avatar-url-input"
                          name="userAvatarUrl"
                          value={editAvatar}
                          onChange={(e) => setEditAvatar(e.target.value)}
                          placeholder="https://example.com/avatar.jpg"
                          className="w-full bg-zinc-900 border border-zinc-800 text-zinc-100 text-[11px] rounded-lg px-3 py-1.5 focus:outline-none focus:border-amber-500/40"
                        />
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <label className="flex-1 bg-zinc-800 hover:bg-zinc-750 border border-zinc-700 text-zinc-205 text-[10px] font-mono uppercase font-black py-2.5 rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition-colors" title="Select a photo from your device">
                        <Upload className="w-3.5 h-3.5 text-zinc-400" />
                        <span>Upload Photo</span>
                        <input 
                          type="file" 
                          id="dashboard-user-photo-upload"
                          name="userPhotoFile"
                          accept="image/*"
                          onChange={handleUserPhotoUpload}
                          className="hidden"
                        />
                      </label>
                      
                      {editAvatar && !editAvatar.startsWith('data:image/svg+xml') && (
                        <button
                          type="button"
                          onClick={() => {
                            setRawImageSrc(editAvatar);
                          }}
                          className="px-3.5 bg-zinc-800 hover:bg-zinc-750 border border-zinc-700 text-zinc-355 hover:text-white rounded-xl cursor-pointer flex items-center justify-center transition-colors"
                          title="Crop & Align Photo"
                        >
                          <Crop className="w-4 h-4 text-amber-500" />
                          <span className="text-[10px] font-mono uppercase font-black ml-1.5">Crop</span>
                        </button>
                      )}
                    </div>

                    {/* Beautiful Avatar Preset Selection Grid */}
                    <div className="space-y-2 border-t border-zinc-850/60 pt-3 text-left">
                      <label className="text-[9px] font-mono text-zinc-550 uppercase tracking-wider block">Or choose a preset style</label>
                      <div className="grid grid-cols-6 gap-1.5">
                        {[
                          { url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', label: 'Preset1' },
                          { url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', label: 'Preset2' },
                          { url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150', label: 'Preset3' },
                          { url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150', label: 'Preset4' },
                          { url: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150', label: 'Preset5' },
                          { url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150', label: 'Preset6' }
                        ].map((preset, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => setEditAvatar(preset.url)}
                            className={`relative rounded-lg overflow-hidden border-2 transition-all aspect-square cursor-pointer hover:scale-105 active:scale-95 ${
                              editAvatar === preset.url ? 'border-amber-500 ring-2 ring-amber-500/20' : 'border-zinc-805 hover:border-zinc-700'
                            }`}
                          >
                            <img src={preset.url} alt={`Preset ${idx + 1}`} className="w-full h-full object-cover animate-fadeIn" referrerPolicy="no-referrer" />
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                  {avatarError && <p className="text-red-400 text-[9px] leading-tight font-medium font-mono">{avatarError}</p>}
                </div>

                {rawImageSrc && (
                  <ImageCropperModal
                    imageSrc={rawImageSrc}
                    onCrop={(cropped) => {
                      setEditAvatar(cropped);
                      setRawImageSrc(null);
                    }}
                    onClose={() => setRawImageSrc(null)}
                  />
                )}

                {submitError && (
                  <div className="bg-red-500/5 border border-red-500/20 text-red-400 p-3 rounded-xl text-xs flex items-center gap-2 select-none animate-fadeIn">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse shrink-0"></span>
                    <p className="font-mono text-[10px] font-bold tracking-tight">{submitError}</p>
                  </div>
                )}

                {/* Username handle field */}
                <div className="space-y-1.5 text-left">
                  <div className="flex justify-between items-center">
                    <label className="text-[10px] font-mono text-zinc-550 uppercase font-black">Username Handle</label>
                    <span className="text-[9px] text-zinc-500 font-mono">Unique @ handle</span>
                  </div>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-amber-550 font-bold font-mono text-xs select-none">
                      @
                    </span>
                    <input 
                      type="text" 
                      required
                      id="dashboard-edit-username"
                      name="editUsername"
                      value={editUsername}
                      onChange={(e) => setEditUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '_'))}
                      className="w-full bg-zinc-950 border border-zinc-850 text-zinc-100 text-xs rounded-xl py-2.5 pl-8 pr-4 font-mono focus:outline-none focus:border-amber-500/40 focus:ring-0"
                    />
                  </div>
                </div>

                <div className="space-y-1.5 text-left">
                  <label className="text-[10px] font-mono text-zinc-555 uppercase font-black">Full Name</label>
                  <input 
                    type="text" 
                    required
                    id="dashboard-edit-fullname"
                    name="editFullName"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 text-zinc-100 text-xs rounded-xl px-3 py-2.5"
                  />
                </div>

                <div className="space-y-1.5 text-left">
                  <label className="text-[10px] font-mono text-zinc-555 uppercase font-black">Email Address</label>
                  <input 
                    type="email" 
                    required
                    id="dashboard-edit-email"
                    name="editEmail"
                    value={editEmail}
                    onChange={(e) => setEditEmail(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 text-zinc-100 text-xs rounded-xl px-3 py-2.5"
                  />
                </div>

                <div className="space-y-1.5 text-left">
                  <label className="text-[10px] font-mono text-zinc-555 uppercase font-black">Phone Number (Optional)</label>
                  <input 
                    type="text" 
                    id="dashboard-edit-phone"
                    name="editPhone"
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 text-zinc-100 text-xs rounded-xl px-3 py-2.5"
                  />
                </div>

                <div className="space-y-1.5 text-left">
                  <label className="text-[10px] font-mono text-zinc-555 uppercase font-black">About You (Bio)</label>
                  <textarea 
                    rows={2}
                    value={editBio}
                    onChange={(e) => setEditBio(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 text-zinc-100 text-xs rounded-xl px-3 py-2.5 resize-none font-medium"
                  />
                </div>

                <div className="flex gap-2 justify-end pt-2">
                  <button 
                    type="button"
                    onClick={() => setIsEditing(false)}
                    className="text-xs bg-zinc-800 text-zinc-300 px-4 py-2 rounded-lg hover:bg-zinc-700 cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    className="text-xs bg-amber-500 text-zinc-950 font-bold px-4 py-2 rounded-lg hover:bg-amber-400 cursor-pointer shadow-md shadow-amber-500/10"
                  >
                    Save Changes
                  </button>
                </div>
              </form>
            ) : (
              <div className="space-y-5 animate-fadeIn text-left">
                <div className="flex flex-col items-center text-center space-y-3">
                  <img 
                    src={currentUser.avatarUrl} 
                    alt={currentUser.name} 
                    referrerPolicy="no-referrer"
                    className="w-20 h-20 rounded-2xl object-cover border-2 border-zinc-800"
                  />
                  <div>
                    <h4 className="text-zinc-100 font-bold text-base uppercase tracking-wider">{currentUser.name}</h4>
                    <p className="text-amber-500 font-mono text-xs font-semibold mt-0.5">@{currentUser.username}</p>
                    <span className="text-[10px] font-mono bg-zinc-955 text-zinc-500 border border-zinc-800 px-3 py-0.5 rounded-full uppercase mt-1.5 inline-block">Verified Member</span>
                  </div>
                </div>

                <div className="space-y-3 text-xs border-t border-zinc-850 pt-4 leading-normal">
                  <div className="flex items-center gap-2 text-zinc-300">
                    <User className="w-4 h-4 text-zinc-500 shrink-0" />
                    <span>{currentUser.name}</span>
                  </div>
                  <div className="flex items-center gap-2 text-zinc-300">
                    <Mail className="w-4 h-4 text-zinc-500 shrink-0" />
                    <span>{currentUser.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-zinc-300">
                    <Phone className="w-4 h-4 text-zinc-500 shrink-0" />
                    <span>{currentUser.phone || "Not specified"}</span>
                  </div>
                  {currentUser.bio && (
                    <div className="bg-zinc-950 p-3 rounded-lg text-zinc-400 border border-zinc-855 text-[11px] leading-relaxed select-none">
                      <p className="font-bold text-zinc-500 uppercase font-mono text-[9px] mb-1">Personal Note</p>
                      {currentUser.bio}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Actives Tracker and Receipts */}
        <div className="lg:col-span-2 space-y-8 text-left">
          
          {/* Active Pass Helpline Disclosure */}
          {userRequests.some(r => r.status === 'approved' || r.status === 'active' || r.status === 'pending') && (() => {
            const contactDetail = globalSettings?.customContactInfo || '12207102021';

            const cleanedPhone = contactDetail.replace(/[^0-9]/g, '');
            const latestRequest = userRequests[0]; // get their pass request details
            const invoiceCode = latestRequest ? latestRequest.id : 'CHAT-NEW';
            const passName = latestRequest && latestRequest.passType === 'text-15' ? 'Quick Check-In Chat' : 'Real-Talk Deep Dive';
            const passPrice = latestRequest ? latestRequest.price : 'Paid';
            const isPending = latestRequest?.status === 'pending';
            
            const messageText = `Hi Bitty! My name is ${currentUser.name} (ID: ${invoiceCode}). I just booked a ${passName} ($${passPrice}). Topic is: "${latestRequest?.topic || 'Let\'s bullshit'}". I have WhatsApp configured and am ready to connect! 🤍`;
            const encodedMessage = encodeURIComponent(messageText);

            const isUrl = contactDetail.startsWith('http') || contactDetail.includes('wa.me');
            const waUrl = isUrl 
              ? contactDetail 
              : `https://wa.me/${cleanedPhone}?text=${encodedMessage}`;

            return (
              <div id="whatsapp-activator-panel" className="bg-gradient-to-b from-emerald-950/20 to-zinc-950/90 border border-emerald-900/60 p-6 rounded-3xl space-y-5 shadow-xl shadow-emerald-500/5 animate-fadeIn">
                
                {/* Status Badges */}
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-[9.5px] font-mono bg-emerald-500/15 text-emerald-400 border border-emerald-800/40 font-black uppercase py-0.5 px-2 rounded-lg tracking-wider flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    Direct WhatsApp Connection
                  </span>
                  {isPending ? (
                    <span className="text-[9px] font-mono bg-amber-500/10 text-amber-505 border border-amber-500/20 font-black uppercase py-0.5 px-2 rounded-lg">
                      Booking Pending Review
                    </span>
                  ) : (
                    <span className="text-[9px] font-mono bg-indigo-500/15 text-indigo-400 border border-indigo-505/20 font-black uppercase py-0.5 px-2 rounded-lg">
                      Booking Approved & Active
                    </span>
                  )}
                </div>

                <div className="space-y-1">
                  <h4 className="text-zinc-100 font-black text-lg uppercase tracking-tight flex items-center gap-2">
                    <span>💬 Bitty WhatsApp Connector</span>
                  </h4>
                  <p className="text-zinc-400 text-[11px] sm:text-xs leading-relaxed">
                    Your chat slot is secured and active! Because we operate directly over secure, real-time message loops, follow this quick guide to start our private chat.
                  </p>
                </div>

                {/* Interactive Status Selector */}
                <div className="bg-zinc-950 p-1.5 rounded-xl border border-zinc-900 flex gap-2">
                  <button
                    type="button"
                    onClick={() => setWhatsappStatus('has_app')}
                    className={`flex-1 text-center py-2 rounded-lg text-[10.5px] font-bold uppercase tracking-wider transition-all cursor-pointer ${
                      whatsappStatus === 'has_app' 
                        ? 'bg-emerald-505 text-zinc-950' 
                        : 'bg-transparent text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    I have WhatsApp
                  </button>
                  <button
                    type="button"
                    onClick={() => setWhatsappStatus('need_app')}
                    className={`flex-1 text-center py-2 rounded-lg text-[10.5px] font-bold uppercase tracking-wider transition-all cursor-pointer ${
                      whatsappStatus === 'need_app' 
                        ? 'bg-emerald-505 text-zinc-950' 
                        : 'bg-transparent text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    How do I get it?
                  </button>
                </div>

                {/* Tab Contents */}
                {whatsappStatus === 'need_app' ? (
                  <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-900 space-y-3.5 text-xs animate-fadeIn">
                    <div className="space-y-1">
                      <span className="text-[9px] font-mono text-amber-500 uppercase font-black block tracking-widest">Install Messenger</span>
                      <p className="text-zinc-350 leading-relaxed text-[11px]">
                        WhatsApp is the standard secure messaging loop used worldwide. If you don't have it on your device, download it for free below:
                      </p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1 font-mono">
                      <a 
                        href="https://apps.apple.com/app/whatsapp-messenger/id310633997"
                        target="_blank"
                        rel="noreferrer"
                        className="bg-zinc-900 border border-zinc-800 hover:border-emerald-800 p-2.5 rounded-xl text-center space-y-1.5 text-zinc-300 hover:text-white transition-all hover:bg-zinc-850/30 flex flex-col items-center justify-center shrink-0"
                      >
                        <span className="text-[14px]">🍎</span>
                        <span className="text-[9px] font-bold uppercase tracking-wide">For iPhone</span>
                      </a>
                      <a 
                        href="https://play.google.com/store/apps/details?id=com.whatsapp"
                        target="_blank"
                        rel="noreferrer"
                        className="bg-zinc-900 border border-zinc-800 hover:border-emerald-800 p-2.5 rounded-xl text-center space-y-1.5 text-zinc-300 hover:text-white transition-all hover:bg-zinc-850/30 flex flex-col items-center justify-center shrink-0"
                      >
                        <span className="text-[14px]">🤖</span>
                        <span className="text-[9px] font-bold uppercase tracking-wide">For Android</span>
                      </a>
                      <a 
                        href="https://web.whatsapp.com/"
                        target="_blank"
                        rel="noreferrer"
                        className="bg-zinc-900 border border-zinc-800 hover:border-emerald-800 p-2.5 rounded-xl text-center space-y-1.5 text-zinc-300 hover:text-white transition-all hover:bg-zinc-850/30 flex flex-col items-center justify-center shrink-0"
                      >
                        <span className="text-[14px]">💻</span>
                        <span className="text-[9px] font-bold uppercase tracking-wide">Desktop / Web</span>
                      </a>
                    </div>

                    <p className="text-[10px] text-zinc-500 leading-relaxed italic pt-1 text-center">
                      Tip: After installation, open WhatsApp, register your account, and then switch back here and select "I have WhatsApp" to click the connection launcher!
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4 animate-fadeIn">
                    
                    {/* Connection Checklist */}
                    <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-900 space-y-3">
                      <span className="text-[9px] font-mono text-emerald-400 uppercase font-bold tracking-widest block">Connection Checklist</span>
                      
                      <div className="space-y-2 text-xs">
                        <label className="flex items-start gap-2.5 text-zinc-350 hover:text-zinc-200 cursor-pointer select-none">
                          <input 
                            type="checkbox" 
                            id="check-whatsapp-installed"
                            name="whatsappCheckApp"
                            checked={whatsappCheckApp} 
                            onChange={(e) => setWhatsappCheckApp(e.target.checked)}
                            className="w-4 h-4 text-emerald-500 border-zinc-700 bg-zinc-900 rounded focus:ring-0 cursor-pointer accent-emerald-500 shrink-0 mt-0.5"
                          />
                          <span className={whatsappCheckApp ? 'line-through text-zinc-550' : ''}>
                            Standard WhatsApp application is installed or opened
                          </span>
                        </label>

                        <label className="flex items-start gap-2.5 text-zinc-350 hover:text-zinc-200 cursor-pointer select-none">
                          <input 
                            type="checkbox" 
                            id="check-whatsapp-ready"
                            name="whatsappCheckMessage"
                            checked={whatsappCheckMessage} 
                            onChange={(e) => setWhatsappCheckMessage(e.target.checked)}
                            className="w-4 h-4 text-emerald-500 border-zinc-700 bg-zinc-900 rounded focus:ring-0 cursor-pointer accent-emerald-500 shrink-0 mt-0.5"
                          />
                          <span className={whatsappCheckMessage ? 'line-through text-zinc-550' : ''}>
                            I am ready to submit my verification token to Bitty
                          </span>
                        </label>
                      </div>
                    </div>

                    {/* Message Preview */}
                    <div className="bg-zinc-950 border border-zinc-905 p-3.5 rounded-xl space-y-1.5 text-left relative overflow-hidden">
                      <span className="text-[8.5px] font-mono text-zinc-550 uppercase tracking-widest block font-black">Pre-written Verification Thread Token:</span>
                      
                      <div className="relative bg-[#0b2921]/40 border border-[#00b4fe]/10 rounded-xl p-3 text-xs leading-relaxed text-zinc-300 font-sans shadow-inner selection:bg-emerald-800">
                        <div className="absolute top-1.5 right-2 font-mono text-[8px] uppercase tracking-wide px-1 rounded bg-[#00b4fe]/10 text-[#00b4fe]">
                          Direct Copy Token
                        </div>
                        "{messageText}"
                      </div>
                      <span className="text-[9px] text-zinc-500 block leading-normal">
                        This code binds your intake form automatically in Bitty's console when the chat initiates.
                      </span>
                    </div>

                    {/* Launcher Emerald Call Button */}
                    <div className="pt-1.5 text-center">
                      <a 
                        href={waUrl} 
                        target="_blank" 
                        rel="noreferrer" 
                        onClick={() => {
                          setWhatsappCheckApp(true);
                          setWhatsappCheckMessage(true);
                        }}
                        className="bg-[#10b981] hover:bg-emerald-400 text-zinc-950 font-black text-xs px-6 py-4 rounded-xl inline-flex items-center justify-center gap-2.5 transition-all shadow-xl shadow-emerald-500/10 active:scale-95 cursor-pointer text-center w-full animate-pulse"
                      >
                        <svg className="w-5 h-5 fill-zinc-950" viewBox="0 0 24 24">
                          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.662c1.746.953 3.71 1.456 5.707 1.456h.001c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                        </svg>
                        <span className="uppercase tracking-widest font-black">Launch Connection Hub Now</span>
                      </a>
                    </div>

                  </div>
                )}

                {/* Disclosure */}
                <div className="bg-zinc-950 p-3.5 rounded-2xl text-zinc-400 text-[10.5px] leading-relaxed border border-zinc-900">
                  <span className="font-extrabold text-emerald-400 font-mono uppercase block text-[8px] tracking-widest mb-1">P2P Routing Information:</span>
                  When you click the connection hub, WhatsApp initializes an encrypted dialogue directly with Bitty. Bitty reads administrative details according to your homeschooling preferences. If you registered an <strong className="text-zinc-200">Anonymous</strong> pass, Bitty keeps your private profile identity completely separate.
                </div>
              </div>
            );
          })()}

          {/* Active Passes Requests list */}
          <div className="space-y-4">
            <h3 className="text-sm font-black text-zinc-400 uppercase font-mono tracking-wider">Conversation Request Tracker</h3>
            
            {userRequests && userRequests.length > 0 ? (
              userRequests.map((req) => (
                <div key={req.id} className="bg-zinc-900 border border-zinc-855 rounded-2xl p-6 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-zinc-850">
                    <div>
                      <span className="text-[10px] font-mono text-zinc-500 uppercase font-bold tracking-widest">{req.id}</span>
                      <h4 className="text-base font-extrabold text-zinc-150 uppercase tracking-tight mt-0.5">
                        {req.passType === 'text-15' ? 'Text Talk Pass — 15 Min' : 'Real Talk Pass — 30 Min'}
                      </h4>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {getStatusBadge(req.status)}
                      
                      {/* CLIENT-SIDE PURGE/DELETE SESSION REQUEST OPTION */}
                      {onDeleteRequest && (req.status === 'pending' || req.status === 'approved' || req.status === 'declined') && (
                        <button
                          onClick={() => {
                            if (confirm(`Are you sure you wish to completely withdraw and cancel your conversation request "${req.id}"? This will purge the record entirely.`)) {
                              onDeleteRequest(req.id);
                            }
                          }}
                          className="text-zinc-650 hover:text-red-400 hover:bg-red-950/20 hover:border-red-900/30 border border-transparent p-1.5 rounded-lg transition-all outline-none"
                          title="Purge / Cancel this session request"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Horizontal Progress Flow Indicator */}
                  {(() => {
                    const getStepIndex = (status: ConversationRequest['status']) => {
                      switch (status) {
                        case 'pending': return 0;
                        case 'approved': return 1;
                        case 'active': return 2;
                        case 'completed': return 3;
                        default: return -1;
                      }
                    };

                    const stepIndex = getStepIndex(req.status);
                    const steps = [
                      { label: 'Pending', desc: 'Awaiting view' },
                      { label: 'Reviewed', desc: 'Approved theme' },
                      { label: 'Active', desc: 'Open helpline' },
                      { label: 'Completed', desc: 'Session past' },
                    ];

                    if (stepIndex >= 0) {
                      const isAlerting = !!statusUpdateAlerts[req.id];
                      return (
                        <div 
                          id={`progress-flow-${req.id}`} 
                          className={`bg-zinc-950/50 border p-4 rounded-xl space-y-3.5 transition-all duration-1000 ${
                            isAlerting 
                              ? 'border-emerald-500/85 shadow-[0_0_20px_rgba(16,185,129,0.25)] bg-gradient-to-br from-emerald-950/20 to-zinc-950/90 animate-pulse' 
                              : 'border-zinc-850/60'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2 flex-wrap">
                            <span className="text-[9px] font-mono text-zinc-500 uppercase tracking-widest font-black block">Conversation Session Stage:</span>
                            {isAlerting && (
                              <span className="text-[8.5px] bg-gradient-to-r from-emerald-500 to-[#00b4fe] text-zinc-950 font-black px-2 py-0.5 rounded-md uppercase tracking-wider animate-bounce select-none flex items-center gap-1">
                                <Sparkles className="w-3 h-3 text-zinc-950 animate-spin" /> STATUS UPDATED LIVE!
                              </span>
                            )}
                          </div>
                          
                          <div className="relative flex items-center justify-between pt-1 pb-1">
                            {/* Line connecting milestones */}
                            <div className="absolute top-[14px] left-[5%] right-[5%] h-0.5 bg-zinc-855 rounded-full z-0"></div>
                            
                            {/* Color path based on status */}
                            <div 
                              className="absolute top-[14px] left-[5%] h-0.5 bg-gradient-to-r from-amber-500 via-[#5c62f9] to-[#00b4fe] rounded-full z-0 transition-all duration-700 ease-out"
                              style={{ 
                                width: `${stepIndex === 0 ? '1%' : stepIndex === 1 ? '45%' : stepIndex === 2 ? '90%' : '90%'}` 
                              }}
                            ></div>

                            {steps.map((st, idx) => {
                              const isCurrent = idx === stepIndex;
                              const isPassed = idx < stepIndex;
                              const isFuture = idx > stepIndex;

                              let bgClass = "bg-zinc-900 border-zinc-800 text-zinc-600";
                              let textClass = "text-zinc-500";
                              
                              if (isCurrent) {
                                if (idx === 0) {
                                  bgClass = "bg-amber-500 border-amber-400 text-zinc-950 font-bold ring-4 ring-amber-500/15";
                                  textClass = "text-amber-405 font-black";
                                } else if (idx === 1) {
                                  bgClass = "bg-[#5c62f9] border-[#00b4fe]/30 text-white font-bold ring-4 ring-indigo-505/15";
                                  textClass = "text-indigo-400 font-black";
                                } else if (idx === 2) {
                                  bgClass = "bg-emerald-500 border-emerald-400 text-zinc-950 font-bold ring-4 ring-emerald-500/15 animate-pulse";
                                  textClass = "text-emerald-400 font-black";
                                } else {
                                  bgClass = "bg-zinc-100 border-zinc-300 text-zinc-950 font-bold ring-4 ring-zinc-100/15";
                                  textClass = "text-zinc-100 font-extrabold";
                                }
                              } else if (isPassed) {
                                bgClass = "bg-gradient-to-tr from-[#5c62f9] to-[#00b4fe] border-transparent text-white shadow-sm";
                                textClass = "text-zinc-300 font-medium";
                              }

                              return (
                                <div key={idx} className="flex flex-col items-center relative z-10 flex-1">
                                  {/* Milestone milestone bubble */}
                                  <div className={`w-7 h-7 rounded-full border flex items-center justify-center text-[10px] font-mono select-none transition-all duration-300 relative ${bgClass}`}>
                                    {isPassed ? (
                                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                                    ) : (
                                      idx + 1
                                    )}

                                    {/* Floating dynamic pulsing indicator with raw Pending label */}
                                    {idx === 0 && isCurrent && (
                                      <div className="absolute -top-5.5 left-1/2 -translate-x-1/2 whitespace-nowrap flex items-center gap-1 bg-amber-550/15 border border-amber-500/30 px-2 py-0.5 rounded-full text-[8px] font-black uppercase tracking-wider font-mono text-amber-400 shadow-sm shadow-amber-500/5">
                                        <span className="relative flex h-1 w-1">
                                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                                          <span className="relative inline-flex rounded-full h-1 w-1 bg-amber-550"></span>
                                        </span>
                                        <span>Pending</span>
                                      </div>
                                    )}
                                  </div>
                                  
                                  {/* Labels */}
                                  <div className="text-center mt-1.5">
                                    <span className={`block text-[9.5px] uppercase tracking-wider ${textClass}`}>
                                      {st.label}
                                    </span>
                                    <span className="hidden sm:block text-[8px] text-zinc-605 font-mono mt-0.5">
                                      {st.desc}
                                    </span>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      );
                    } else {
                      return (
                        <div id={`progress-flow-cancelled-${req.id}`} className="bg-zinc-950/40 border border-red-950/60 p-3 rounded-xl flex items-center gap-3">
                          <div className="w-6 h-6 rounded-full bg-red-950 text-red-500 flex items-center justify-center text-xs font-bold border border-red-900/40 shrink-0">
                            ✕
                          </div>
                          <div>
                            <span className="text-[10px] font-mono font-black text-red-400 uppercase tracking-widest block">Request Concluded</span>
                            <span className="text-[9.5px] text-zinc-500 block leading-tight">This payment transaction has been archived, declined, or fully refunded.</span>
                          </div>
                        </div>
                      );
                    }
                  })()}

                  <div className="space-y-2">
                    <span className="text-[10px] font-mono text-zinc-500 tracking-wider block uppercase">Intake Topic Focus:</span>
                    <p className="text-zinc-200 text-xs md:text-sm leading-relaxed p-3.5 bg-zinc-950 rounded-xl border border-zinc-855 font-medium">
                      "{req.topic}"
                    </p>
                  </div>

                  {req.attachedDriveFiles && req.attachedDriveFiles.length > 0 && (
                    <div className="space-y-2">
                      <span className="text-[10px] font-mono text-zinc-500 tracking-wider block uppercase font-bold text-left">Attached Case Files:</span>
                      <div className="flex flex-wrap gap-2 text-left justify-start">
                        {req.attachedDriveFiles.map((file, idx) => (
                          <a
                            key={file.id || idx}
                            href={file.url || '#'}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="bg-zinc-950 hover:bg-zinc-850 border border-zinc-850 hover:border-amber-500/35 text-[10px] text-zinc-300 px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all font-mono"
                          >
                            <HardDrive className="w-3.5 h-3.5 text-amber-500" />
                            <span>{file.name}</span>
                            <span className="text-[8px] text-zinc-500">({file.mimeType.split('/').pop()?.toUpperCase()})</span>
                          </a>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="p-4 bg-zinc-955 rounded-xl space-y-1.5 border border-zinc-855">
                    <p className="text-[10px] font-mono text-zinc-500 uppercase font-black">Live Pulse State</p>
                    <p className="text-zinc-350 text-xs leading-normal">
                      {getStatusDescription(req.status)}
                    </p>
                    
                    {req.adminNotes && (
                      <div className="mt-3 pt-3 border-t border-zinc-850 text-xs">
                        <span className="text-[9px] font-mono bg-amber-500/10 text-amber-500 border border-amber-500/20 px-1.5 py-0.2 rounded font-black tracking-wider mr-2 uppercase">Bitty’s Response Notes</span>
                        <p className="text-zinc-350 italic inline leading-relaxed font-serif">"{req.adminNotes}"</p>
                      </div>
                    )}
                  </div>

                  {/* Detailed Status History / Transparency Timeline Log */}
                  <div className="bg-zinc-950/40 border border-zinc-850/60 rounded-xl p-4 space-y-3.5">
                    <div className="flex items-center justify-between text-[10px] font-mono select-none">
                      <span className="text-zinc-400 uppercase font-bold tracking-wider">Date-Stamped Status Timeline</span>
                      <span className="text-zinc-550 uppercase tracking-widest font-black">Transparency Log</span>
                    </div>

                    <div className="relative pl-5 space-y-5 border-l border-zinc-850/60 ml-2">
                      {(() => {
                        const timelineEvents = [
                          {
                            key: 'received',
                            title: 'Request Received',
                            desc: 'Booking verification code verified and intake details logged into the secure chat queue.',
                            completed: true,
                            date: req.createdAt,
                          },
                          {
                            key: 'verified',
                            title: 'Safety Constraints Validated',
                            desc: 'Homeschooling boundaries, child constraints, and disclaimers validated.',
                            completed: true,
                            date: new Date(Math.min(new Date(req.createdAt).getTime() + 15 * 60 * 1000, Date.now())).toISOString(),
                          },
                          {
                            key: 'reviewed',
                            title: 'Under Review & Approved',
                            desc: 'Bitty reviewed your profile topic and approved your chat gateway dialogue window.',
                            completed: req.status !== 'pending' && req.status !== 'declined' && req.status !== 'refunded',
                            date: req.status !== 'pending' && req.status !== 'declined' && req.status !== 'refunded' ? (req.updatedAt || req.createdAt) : null,
                          },
                          {
                            key: 'active',
                            title: 'Conversation Helpline Active',
                            desc: 'Encrypted communication gateway unlocked. Direct private lines are ready to launch.',
                            completed: req.status === 'active' || req.status === 'completed',
                            date: (req.status === 'active' || req.status === 'completed') ? (req.updatedAt || req.createdAt) : null,
                          },
                          {
                            key: 'completed',
                            title: 'Dialogue Session Concluded',
                            desc: 'Active dialogue block finished. Access tokens archived and connection tunnel successfully closed.',
                            completed: req.status === 'completed',
                            date: req.status === 'completed' ? (req.updatedAt || req.createdAt) : null,
                          }
                        ];

                        return timelineEvents.map((ev) => {
                          const dateFmt = ev.date ? (() => {
                            try {
                              const d = new Date(ev.date);
                              return d.toLocaleString('en-US', {
                                month: 'short',
                                day: 'numeric',
                                hour: 'numeric',
                                minute: '2-digit',
                                hour12: true
                              });
                            } catch {
                              return '';
                            }
                          })() : '';

                          return (
                            <div key={ev.key} className="relative group text-left">
                              {/* Left dot */}
                              <span className={`absolute -left-[25px] top-1.5 flex h-2 w-2 rounded-full border transition-all duration-300 ${
                                ev.completed 
                                  ? 'bg-[#5c62f9] border-[#00b4fe]/60 shadow-[0_0_8px_rgba(92,98,249,0.5)]' 
                                  : 'bg-zinc-900 border-zinc-800'
                              }`} />

                              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-1">
                                <h5 className={`text-xs font-bold uppercase tracking-wide transition-colors ${
                                  ev.completed ? 'text-zinc-200' : 'text-zinc-550'
                                }`}>
                                  {ev.title}
                                </h5>
                                
                                {ev.completed && dateFmt ? (
                                  <span className="text-[9px] font-mono text-zinc-500 font-medium shrink-0">
                                    ✓ {dateFmt}
                                  </span>
                                ) : (
                                  <span className="text-[9px] font-mono text-zinc-650 font-bold tracking-widest uppercase shrink-0">
                                    Awaiting Status
                                  </span>
                                )}
                              </div>

                              <p className={`text-[11px] leading-relaxed mt-0.5 transition-colors ${
                                ev.completed ? 'text-zinc-400' : 'text-zinc-600'
                              }`}>
                                {ev.desc}
                              </p>
                            </div>
                          );
                        });
                      })()}
                    </div>
                  </div>

                  {/* JOIN INTERACTIVE CHAT GATEWAY BUTTON */}
                  {(req.status === 'approved' || req.status === 'active') && (
                    <div className="pt-2 border-t border-zinc-850/60 flex items-center justify-between flex-wrap gap-4">
                      <div className="space-y-0.5 text-left">
                        <span className="text-[9.5px] font-mono text-zinc-555 uppercase tracking-widest block font-bold">Direct Written Dialogue Ready</span>
                        <p className="text-[10px] text-zinc-500 leading-normal">Press the button on the right to enter your private sandbox written dialogue.</p>
                      </div>
                      
                      <button
                        onClick={() => {
                          const limitMins = req.passType === 'text-30' ? 30 : 15;
                          setClientTimerSeconds(limitMins * 60);
                          setClientTimerIsActive(false);
                          setActiveClientCallId(req.id);
                          // Auto scroll to chat panel!
                          window.scrollTo({ top: 120, behavior: 'smooth' });
                        }}
                        className="bg-purple-600 hover:bg-purple-500 text-white font-black text-xs py-2 px-4 rounded-xl uppercase tracking-wider flex items-center gap-1.5 transition-all outline-none cursor-pointer"
                      >
                        <MessageSquare className="w-4 h-4 animate-pulse" />
                        <span>💬 Open Chat Stage</span>
                      </button>
                    </div>
                  )}

                  <div className="flex flex-wrap text-[10px] text-zinc-500 font-mono gap-4 pt-2 justify-between">
                    <span>Submitted: {new Date(req.createdAt).toLocaleDateString()}</span>
                    <span>Billing ID: {req.paymentId}</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12 bg-zinc-900 rounded-2xl border border-zinc-850 text-zinc-505 select-none">
                <FileText className="w-8 h-8 text-zinc-650 mx-auto mb-2" />
                <p className="text-xs font-mono uppercase">You have no active conversation requests.</p>
                <p className="text-[11px] text-zinc-600 mt-0.5">Explore Bitty’s Book a Chat page to secure a slot!</p>
              </div>
            )}
          </div>

          {/* User Purchase Receipts */}
          <div className="space-y-4">
            <h3 className="text-sm font-black text-zinc-400 uppercase font-mono tracking-wider">Purchase History Receipts</h3>

            <div className="bg-zinc-900 border border-zinc-850 rounded-2xl overflow-hidden">
              {userPayments && userPayments.length > 0 ? (
                <div className="divide-y divide-zinc-850 text-left">
                  {userPayments.map((p) => (
                    <div key={p.id} className="p-4 flex items-center justify-between gap-4 text-xs hover:bg-zinc-850/20 transition-colors">
                      <div className="space-y-0.5 text-left">
                        <span className="text-[10px] text-zinc-500 font-mono block text-left">DATE: {new Date(p.date).toLocaleDateString()}</span>
                        <h5 className="font-bold text-zinc-200 uppercase text-left">
                          {p.passType === 'text-15' ? '15m Text Pass' : '30m Real Talk Pass'}
                        </h5>
                        <span className="text-[10px] font-mono text-zinc-550 block text-left">{p.paymentId}</span>
                      </div>
                      
                      <div className="text-right">
                        <span className="text-sm font-black text-zinc-105 block">${p.amount}.00</span>
                        <span className={`text-[9px] font-mono uppercase bg-emerald-500/10 text-emerald-400 px-1.5 py-0.2 rounded font-bold border border-emerald-990/20`}>
                          Paid (stripe)
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-zinc-555 text-xs font-mono select-none">
                  <span>No transactions recorded.</span>
                </div>
              )}
            </div>
          </div>

        </div>

      </div>

      {/* Full-width Google Drive Independent Dashboard Portal */}
      {globalSettings?.enableDrivePortal && (
        <div id="dashboard-drive-portal" className="border-t border-zinc-850/65 pt-10 mt-8 space-y-4 text-left">
          <div className="space-y-1 select-none text-left">
            <h3 className="text-sm font-black text-zinc-350 uppercase font-mono tracking-wider flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-amber-500" />
              <span>Independent Google Drive Portal</span>
            </h3>
            <p className="text-zinc-500 text-xs text-left">
              Connect and manage documents in your personal Google Drive account. Feel free to preview or upload case references and journal entries.
            </p>
          </div>
          <DriveBrowser isSelectionMode={false} />
        </div>
      )}

    </div>
  );
}
