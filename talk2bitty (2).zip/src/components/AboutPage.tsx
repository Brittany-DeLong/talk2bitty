import React from 'react';
import { Heart, BookOpen, Sparkles, Camera } from 'lucide-react';
import { GlobalSettings } from '../types';

interface AboutPageProps {
  globalSettings?: GlobalSettings;
}

export default function AboutPage({ globalSettings }: AboutPageProps) {
  // Retrieve custom gallery photos
  const introPhoto = globalSettings?.galleryPhotos?.find(p => p.id === 'slot_about_intro');
  const familyPhoto = globalSettings?.galleryPhotos?.find(p => p.id === 'slot_about_family');

  const introImgUrl = introPhoto?.url || null;
  const introCaption = introPhoto?.caption || "A warm perspective • Bitty's Corner";

  const familyImgUrl = familyPhoto?.url || null;
  const familyCaption = familyPhoto?.caption || "Meet the Feathered Toddlers";

  return (
    <div className="max-w-4xl mx-auto space-y-12 py-4">
      {/* Bio Summary Hero Container */}
      <div id="about-hero-section" className="relative overflow-hidden bg-zinc-900 border border-zinc-850 p-8 rounded-2xl flex flex-col md:flex-row gap-8 items-center">
        <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/5 rounded-full filter blur-3xl pointer-events-none"></div>
        
        {/* Bitty Aspect Mugshot replaced by hand-crafted personal emblem */}
        <div id="bitty-emblem-container" className="relative shrink-0 select-none">
          {introImgUrl ? (
            <div className="w-40 h-40 rounded-2xl bg-zinc-950 border-2 border-amber-500/30 overflow-hidden shadow-xl relative group">
              <img 
                src={introImgUrl} 
                alt={introCaption} 
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-2 justify-center">
                <span className="text-[9px] font-mono text-zinc-300 tracking-wider">Bitty's Spot</span>
              </div>
            </div>
          ) : (
            <div className="w-40 h-40 rounded-2xl bg-gradient-to-b from-zinc-800 to-zinc-950 border-2 border-amber-500/30 flex flex-col items-center justify-center shadow-xl p-4 gap-2">
              <svg viewBox="0 0 100 100" className="w-16 h-16 text-amber-500 drop-shadow-[0_0_8px_rgba(245,158,11,0.2)]" fill="none" stroke="currentColor" strokeWidth="2.5">
                {/* Abstract wing/feather flowing into a B initial */}
                <path d="M35,25 C35,25 45,15 60,15 C65,15 70,18 70,23 C70,28 65,32 55,35 M35,25 L35,75 M35,45 C35,45 50,45 65,45 C72,45 78,48 78,55 C78,62 70,68 50,68 C42,68 35,68 35,68" strokeLinecap="round" strokeLinejoin="round" />
                {/* Tiny feather detail */}
                <path d="M35,40 C28,38 23,43 20,50 C24,48 30,51 35,50" strokeLinecap="round" strokeLinejoin="round" className="text-amber-500/60" strokeWidth="1.5" />
              </svg>
              <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-zinc-500 font-bold">FEATHER & SOUL</span>
            </div>
          )}
          <div className="absolute -bottom-2 -right-2 bg-amber-500 text-zinc-950 font-black px-3 py-1 text-xs rounded-lg uppercase tracking-wider font-mono">
            Bitty
          </div>
        </div>

        {/* Short Text Overview */}
        <div className="flex-1 space-y-4 text-center md:text-left">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-zinc-850 border border-zinc-800 rounded-full text-xs text-amber-400 font-mono">
            <Sparkles className="w-3 h-3" />
            <span>STUDENT • MOTHER • PERSPECTIVE SEEKER</span>
          </div>
          <h2 className="text-3xl font-extrabold text-zinc-100 tracking-tight">
            I don’t pretend to have all the answers.
          </h2>
          <p className="text-zinc-300 leading-relaxed text-sm md:text-base">
            I’m a mom of three, a Human Development and Family Studies student, and a pet mom to two cockatoos who are basically toddlers with feathers. I’ve lived through plenty of chaos, heartbreak, and healing – and I’m here to offer real, human focus.
          </p>
        </div>
      </div>

      {introImgUrl && (
        <div className="text-center font-serif text-xs italic text-zinc-500 -mt-8 tracking-wide">
          Bitty's Spot: "{introCaption}"
        </div>
      )}

      {/* Grid of details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Cards of Life experience */}
        <div className="bg-zinc-900/60 border border-zinc-850 p-6 rounded-2xl space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center text-red-400">
              <Heart className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-zinc-100 uppercase tracking-tight">The chapters I've lived</h3>
          </div>
          <p className="text-zinc-300 text-sm leading-relaxed">
            I’ve been through divorce, infidelity, toxic relationships, deep grief, depression, anxiety, trust issues, and abandonment wounds. I know how heavy these things feel because I’ve carried them.
          </p>
          <p className="text-zinc-400 text-xs font-mono uppercase tracking-wider text-zinc-500">
            I don’t judge people based on one bad page of their book. We're all trying our best.
          </p>
        </div>

        {/* Training, learning, and studies */}
        <div className="bg-zinc-900/60 border border-zinc-850 p-6 rounded-2xl space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center text-purple-450">
              <BookOpen className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-zinc-100 uppercase tracking-tight">Why I'm here</h3>
          </div>
          <p className="text-zinc-300 text-sm leading-relaxed">
            I’m a Human Development student and a mom of three. I recently lost someone I loved deeply to suicide after years of mental health struggles and unresolved trauma. It changes how you see the world. I don't want to be anyone's therapist; I just know how incredibly lonely it gets in the dark.
          </p>
          <p className="text-zinc-400 text-xs font-mono uppercase tracking-wider text-zinc-500">
            You're paying for a real person's undivided attention, caring feedback, and honest conversation.
          </p>
        </div>
      </div>

      {/* Bitty's Manifesto: Statement of honesty */}
      <div className="border border-zinc-850 bg-gradient-to-br from-zinc-90/50 to-zinc-95/50 p-8 rounded-2xl space-y-6 relative">
        <h3 className="text-xl font-bold text-zinc-100 flex items-center gap-2">
          <span>My Promise: Raw & Unfiltered Honesty</span>
        </h3>
        <div className="space-y-3 text-zinc-300 text-sm md:text-base leading-relaxed font-serif italic text-zinc-200">
          <p>“I try to understand people. But that doesn’t mean I’m a yes-person.”</p>
          <p>“If I agree with you, I’ll say it. If I disagree, I’ll probably say that too.”</p>
          <p>“Real conversations require honesty. Talk2Bitty exists because genuine connection is becoming harder to find. Sometimes people need advice. Sometimes they need perspective. Sometimes they need to vent. Sometimes they just need someone who will listen without pretending to do it perfectly. That’s what this platform is built around.”</p>
        </div>
        <div className="pt-4 border-t border-zinc-800 flex flex-wrap items-center justify-between gap-4 text-xs font-mono text-zinc-500">
          <span>— Bitty (Founder & Guardian)</span>
          <span className="text-amber-500/85">Talk2Bitty • Real dialogue. No templates.</span>
        </div>
      </div>

      {/* The Feathered Toddlers: Cockatoo Showcase */}
      <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-850 flex flex-col md:flex-row items-center gap-6">
        <div className="w-24 h-24 rounded-2xl overflow-hidden shrink-0 border border-zinc-850 bg-zinc-950 flex items-center justify-center relative shadow-md">
          {familyImgUrl ? (
            <img 
              src={familyImgUrl} 
              alt={familyCaption} 
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover select-none"
            />
          ) : (
            <div className="w-full h-full bg-zinc-950 flex flex-col items-center justify-center p-2 text-amber-500/60 border border-dashed border-zinc-800 rounded-xl">
              <svg viewBox="0 0 24 24" className="w-8 h-8" fill="none" stroke="currentColor" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
              </svg>
              <span className="text-[7px] font-mono mt-1 text-zinc-500">COCKATOOS</span>
            </div>
          )}
        </div>
        <div className="space-y-2 flex-1 text-center md:text-left">
          <h4 className="text-sm font-bold text-zinc-100 uppercase tracking-wider font-mono text-amber-500">
            {familyCaption}
          </h4>
          <p className="text-zinc-300 text-xs md:text-sm leading-relaxed">
            Outside of school and studies, my household is ruled by two cockatoos. They have massive and completely different personalities, scream at microwaves, demand emotional support walnuts, and remind me daily that beautiful relationships are loud, rowdy, and always a little chaotic.
          </p>
        </div>
      </div>

      {/* Dynamic Scrapbook Photogrid of Bitty's Life Details */}
      <div id="scrapbook-gallery-section" className="space-y-6 pt-4">
        <div className="border-b border-zinc-800 pb-3 flex items-center justify-between text-left">
          <h3 className="text-lg font-bold text-zinc-100 flex items-center gap-2">
            <Camera className="text-amber-500 w-5 h-5 animate-pulse" />
            <span>Bitty's Live Scrapbook & Snapshots</span>
          </h3>
          <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest bg-zinc-900 border border-zinc-850 px-3 py-1 rounded-full font-bold">
            Live Albums
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {globalSettings?.galleryPhotos?.filter(p => p.url).map((photo) => (
            <div key={photo.id} className="bg-zinc-900 border border-zinc-850 rounded-2xl p-4 space-y-4 hover:border-zinc-700 transition-all duration-300 group flex flex-col justify-between">
              <div className="aspect-square w-full rounded-xl overflow-hidden bg-zinc-950 border border-zinc-850 relative shadow-inner">
                <img 
                  src={photo.url} 
                  alt={photo.caption || photo.name} 
                  className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="space-y-1.5 pl-1.5 text-left">
                <span className="text-[9.5px]/none font-mono text-amber-500 uppercase font-black bg-amber-500/5 px-2 py-1 rounded border border-amber-500/10 inline-block mb-1">
                  {photo.id === 'slot_polaroid' ? 'Homepage Polaroid Frame' : 
                   photo.id === 'slot_about_intro' ? 'Intro Bio Photo' :
                   photo.id === 'slot_about_family' ? 'Meet the Feathered Toddlers (Birds Showcase)' :
                   photo.id === 'slot_community' ? 'Community Banner' :
                   'Scrapbook Album'}
                </span>
                <h5 className="text-zinc-200 text-xs font-mono font-bold uppercase tracking-wider block border-l-2 border-amber-500/40 pl-2">
                  {photo.id === 'slot_about_family' ? 'Meet the Feathered Toddlers (Cockatoos)' : photo.name}
                </h5>
                <p className="text-zinc-400 text-xs italic font-serif pl-2 leading-relaxed">
                  "{photo.caption || "A precious moment in the journey..."}"
                </p>
              </div>
            </div>
          ))}

          {(!globalSettings?.galleryPhotos || globalSettings.galleryPhotos.filter(p => p.url).length === 0) && (
            <div className="col-span-full py-16 text-center bg-zinc-900/40 border border-dashed border-zinc-850 rounded-2xl text-zinc-550 font-mono text-xs">
              Bitty hasn’t uploaded scrapbook photos yet. Click on the admin cockpit panel to customize Bitty’s live scrapbook album!
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
