import React, { useState } from 'react';
import { X, Shield, FileText, AlertTriangle, CreditCard, Cookie } from 'lucide-react';

interface LegalModalProps {
  initialTab?: 'privacy' | 'terms' | 'disclaimer' | 'refunds';
  onClose: () => void;
}

export default function LegalModal({ initialTab = 'privacy', onClose }: LegalModalProps) {
  const [activeTab, setActiveTab] = useState<'privacy' | 'terms' | 'disclaimer' | 'refunds'>(initialTab);

  const tabs = [
    { id: 'privacy', label: 'Privacy Policy', icon: Shield },
    { id: 'terms', label: 'Terms of Service', icon: FileText },
    { id: 'disclaimer', label: 'Disclaimers', icon: AlertTriangle },
    { id: 'refunds', label: 'Pass & Refund Policy', icon: CreditCard },
  ] as const;

  return (
    <div id="legal-policies-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-zinc-950 border border-zinc-800 rounded-2xl w-full max-w-3xl h-[85vh] flex flex-col shadow-2xl relative">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-900">
          <div className="space-y-0.5">
            <h2 className="text-sm font-black text-zinc-300 uppercase font-mono tracking-wider">
              Legal, Privacy & Disclosures
            </h2>
            <p className="text-xs text-zinc-500 font-mono">Talk2Bitty Platform Guidelines</p>
          </div>
          <button 
            type="button"
            onClick={onClose}
            className="text-zinc-500 hover:text-zinc-200 hover:bg-zinc-900 p-1.5 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Outer Grid */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          
          {/* Left Navigation Sidebar */}
          <div className="md:w-56 border-b md:border-b-0 md:border-r border-zinc-900 p-3 bg-zinc-950/50 flex flex-row md:flex-col gap-1 overflow-x-auto md:overflow-x-visible shrink-0">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-left text-xs font-mono uppercase tracking-wider font-bold transition-all cursor-pointer whitespace-nowrap md:whitespace-normal w-full ${
                    isActive 
                      ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30' 
                      : 'text-zinc-400 hover:text-zinc-200 border border-transparent hover:bg-zinc-900'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0 text-amber-500/80" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Right Content Area (Scrollable Markdowns) */}
          <div className="flex-1 overflow-y-auto p-6 md:p-8 font-sans text-xs md:text-sm text-zinc-300 space-y-6 scrollbar-thin">
            
            {activeTab === 'privacy' && (
              <div className="space-y-4 animate-fadeIn">
                <h3 className="text-zinc-150 font-bold uppercase tracking-wide font-mono flex items-center gap-2">
                  <Shield className="w-4 h-4 text-emerald-400" /> 1. Privacy & Information Practice
                </h3>
                
                <p className="leading-relaxed text-zinc-400">
                  Your privacy matters deeply. At Talk2Bitty, we are committed to providing a shelter for open communication, which requires complete transparency about how your user data is managed.
                </p>

                <div className="space-y-3 bg-zinc-900/40 border border-zinc-850 rounded-xl p-4">
                  <h4 className="text-xs font-bold text-zinc-200 uppercase tracking-widest font-mono">Data Collected</h4>
                  <ul className="list-disc pl-4 space-y-2 text-zinc-400">
                    <li><strong className="text-zinc-300 font-medium">Account Credentials:</strong> Your screen name, email address, custom description bio, and selected avatar profile pictures.</li>
                    <li><strong className="text-zinc-300 font-medium">Community Wall Content:</strong> Any public forum text, comment boards, and image upload assets you optionally post to our transparent bulletin channel.</li>
                    <li><strong className="text-zinc-300 font-medium">Pass Request Intakes:</strong> Any background context details, parenting notes, personal topics, and contact numbers parsed when submitting text consultation entries.</li>
                    <li><strong className="text-zinc-300 font-medium">Stripe Billing Context:</strong> Real-time checkout transactions establish dynamic payment confirmation tokens returned securely from Stripe. Credit card credentials themselves are processed directly within Stripe’s PCI-compliant checkout domain and are never parsed or stored locally.</li>
                  </ul>
                </div>

                <div className="space-y-2">
                  <h4 className="text-xs font-black text-zinc-200 uppercase tracking-widest font-mono">Information Sharing</h4>
                  <p className="leading-relaxed text-zinc-400">
                    We never sell, distribute, or license your private email or background intake notes. The only parties viewing internal details are you (the client account) and Bitty (the system operator). 
                    Please note that community posts and public replies are accessible to all platform visitors. Avoid posting personal identifiers on the Community Wall.
                  </p>
                </div>

                <div className="space-y-2">
                  <h4 className="text-xs font-black text-zinc-200 uppercase tracking-widest font-mono">Your Access Control Rights</h4>
                  <p className="leading-relaxed text-zinc-400">
                    You can inspect, rewrite, or update your account name, email, bio details, and avatar profile photograph anytime under your Account Settings button on the Member Dashboard. To request deletion of your account history, contact Bitty.
                  </p>
                </div>
              </div>
            )}

            {activeTab === 'terms' && (
              <div className="space-y-4 animate-fadeIn">
                <h3 className="text-zinc-150 font-bold uppercase tracking-wide font-mono flex items-center gap-2">
                  <FileText className="w-4 h-4 text-amber-400" /> 2. Community Terms of Service (ToS)
                </h3>

                <p className="leading-relaxed text-zinc-400">
                  By accessing or utilizing any page within the Talk2Bitty support application, you affirm your absolute consent to these rules.
                </p>

                <div className="space-y-3 bg-zinc-905 border border-zinc-850 rounded-xl p-4">
                  <h4 className="text-xs font-bold text-amber-500 uppercase tracking-widest font-mono">Conduct & Wall Policy</h4>
                  <p className="leading-relaxed text-zinc-400">
                    The Community Wall is a space for raw, unfiltered support, but we maintain a zero-tolerance boundary regarding harassment, digital abuse, slurs, threats, hate speech, or spamming. 
                  </p>
                  <ul className="list-disc pl-4 space-y-1.5 text-zinc-400">
                    <li>Absolutely <strong className="text-zinc-200">no AI-generated images</strong> or fake renders are allowed. All visuals must represent authentic realities.</li>
                    <li>Do not impersonate other users or post personal details of third-party friends or family without their explicit consent.</li>
                    <li>We reserve structural privileges to remove, append, edit, or delete any community contribution violating these standard human boundaries.</li>
                  </ul>
                </div>

                <div className="space-y-2">
                  <h4 className="text-xs font-black text-zinc-200 uppercase tracking-widest font-mono">Ownership & Moderation Rights</h4>
                  <p className="leading-relaxed text-zinc-400">
                    Talk2Bitty is owned and operated by Bitty. Users retain original authorship of the content they write, but grant the platform a licensing permit to display posted comments dynamically to other users on the Community Wall. If a member repeatedly triggers conflicts or exhibits destructive behavior, Bitty reserves complete unilateral authority to suspend or terminate the associated account.
                  </p>
                </div>
              </div>
            )}

            {activeTab === 'disclaimer' && (
              <div className="space-y-4 animate-fadeIn">
                <h3 className="text-zinc-150 font-bold uppercase tracking-wide font-mono flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-500" /> 3. Scope of Support
                </h3>

                <div className="bg-amber-500/5 border border-amber-500/20 text-amber-400 p-4 rounded-xl space-y-2">
                  <h4 className="text-xs font-bold uppercase tracking-widest font-mono flex items-center gap-1.5 text-amber-400">
                    <AlertTriangle className="w-4 h-4" /> What I am, and what I'm not
                  </h4>
                  <p className="leading-relaxed font-semibold">
                    I am Bitty. I am a mother, a student of Human Development, and a supportive, honest listening partner. I am NOT a licensed psychologist, clinical counselor, psychiatrist, social worker, doctor, or legal therapist. 
                  </p>
                </div>

                <div className="space-y-3 text-zinc-400 leading-relaxed text-xs md:text-sm">
                  <p>
                    All advice, perspectives, or feedback provided on this application are shared based on personal life lessons, active listening, and my studies in Human Development. This is NOT a substitute for professional mental health treatment or clinical medical evaluations.
                  </p>
                  <p>
                    If you are looking for medical treatment, formal diagnostic testing, or specialized legal counsel, please reach out to certified professionals who practice in those spheres.
                  </p>
                </div>

                <div className="border border-red-500/20 bg-red-500/5 text-zinc-300 p-4 rounded-xl space-y-2">
                  <h4 className="text-xs font-black uppercase text-red-400 font-mono tracking-wider">Crisis Contacts & Resources</h4>
                  <p className="text-xs text-zinc-400 leading-relaxed">
                    This platform is async and does NOT offer live emergency response or suicide crisis monitoring. If you feel you may harm yourself or another human, call emergency services (911 in the US) or contact critical hotlines immediately:
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 font-mono text-[10px]">
                    <div className="bg-zinc-950 p-2 rounded border border-zinc-900 text-zinc-400">
                      <strong className="text-red-400 font-bold">Suicide & Crisis Lifeline:</strong> Call/Text 988 (USA)
                    </div>
                    <div className="bg-zinc-950 p-2 rounded border border-zinc-900 text-zinc-400">
                      <strong className="text-red-400 font-bold">Crisis Text Line:</strong> Text HOME to 741741
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'refunds' && (
              <div className="space-y-4 animate-fadeIn">
                <h3 className="text-zinc-150 font-bold uppercase tracking-wide font-mono flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-amber-400" /> 4. Dialogue Slot Bookings & Refund Disclosures
                </h3>

                <p className="leading-relaxed text-zinc-400">
                  Booking an open Chat Dialogue Slot enables direct text messaging access with Bitty regarding private real-life situations, parenting context, or relationship navigation.
                </p>

                <div className="space-y-3 bg-zinc-900/40 border border-zinc-850 rounded-xl p-4">
                  <h4 className="text-xs font-bold text-zinc-200 uppercase tracking-widest font-mono">Stripe Checkout Security</h4>
                  <p className="leading-relaxed text-zinc-400">
                    All financial operations are routed to secure external Stripe checkouts via encrypted SSL protocols. High-grade security means zero credit card information ever enters the local Talk2Bitty database.
                  </p>
                </div>

                <div className="space-y-3 text-zinc-400 leading-relaxed">
                  <h4 className="text-xs font-black text-zinc-200 uppercase tracking-widest font-mono">Refund & Intake Guidelines</h4>
                  <p>
                    Because this is a personalized direct support service involving extensive time and emotional devotion:
                  </p>
                  <ul className="list-disc pl-4 space-y-1.5 text-zinc-400">
                    <li><strong className="text-zinc-300">Case-by-Case Refunds:</strong> Once Bitty reviews your intake request and provides direct, handwritten communication responses back to your inbox, the fee handles that dedicated time and is considered fully rendered.</li>
                    <li><strong className="text-zinc-300">Pre-Service Cancellations:</strong> If you buy a pass but require cancellation prior to Bitty starting or approving your topic, you may submit a request for a refund under your member logs, which Bitty reviews directly within 3-5 days.</li>
                    <li><strong className="text-zinc-300">Declined Intakes:</strong> If Bitty reviews an intake and determines it involves medical or emergency topics beyond her boundary scope, the request will be gracefully declined, and a 100% full reversal refund will be executed.</li>
                  </ul>
                </div>
              </div>
            )}

          </div>

        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-zinc-900 flex justify-between items-center bg-zinc-950/80">
          <span className="text-[10px] text-zinc-600 font-mono flex items-center gap-1">
            <Cookie className="w-3 h-3 text-amber-500/60" /> Uses secure localStorage for local session state. No track cookies.
          </span>
          <button
            type="button"
            onClick={onClose}
            className="bg-zinc-800 hover:bg-zinc-700 text-zinc-200 hover:text-white font-mono text-xs py-2 px-5 rounded-xl uppercase tracking-wider font-bold transition-all cursor-pointer"
          >
            Acknowledge & Close
          </button>
        </div>

      </div>
    </div>
  );
}
