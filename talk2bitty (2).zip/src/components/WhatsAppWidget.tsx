import React, { useState } from 'react';
import { X, Send } from 'lucide-react';
import { GlobalSettings } from '../types';

interface WhatsAppWidgetProps {
  globalSettings: GlobalSettings;
  bittyProfile: { avatarUrl: string };
}

export default function WhatsAppWidget({ globalSettings, bittyProfile }: WhatsAppWidgetProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [userMsg, setUserMsg] = useState('');
  const [hasPulse, setHasPulse] = useState(true);
  const [isDismissed, setIsDismissed] = useState(() => {
    try {
      return localStorage.getItem('bitty_wa_widget_dismissed') === 'true';
    } catch {
      return false;
    }
  });

  const contactOption = globalSettings?.contactType || 'whatsapp';
  const rawContact = globalSettings?.customContactInfo || '12207102021';

  // Only display this floating interactive widget if Bitty has configured her Helpline setting as 'whatsapp' and it has not been dismissed
  if (contactOption !== 'whatsapp' || isDismissed) return null;

  // Render proper URL for wa.me redirect
  const getWhatsAppUrl = (text: string) => {
    const trimmed = rawContact.trim();
    const encoded = encodeURIComponent(text);
    if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
      // It's a full custom invite link
      if (trimmed.includes('?')) {
        return `${trimmed}&text=${encoded}`;
      }
      return `${trimmed}?text=${encoded}`;
    }
    // It's a clean phone string digits
    const cleanNum = trimmed.replace(/[^0-9]/g, '');
    return `https://wa.me/${cleanNum}?text=${encoded}`;
  };

  const handleOpenWidget = () => {
    setIsOpen(true);
    setHasPulse(false);
  };

  const handleSubmitMsg = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userMsg.trim()) return;

    const targetUrl = getWhatsAppUrl(userMsg);
    window.open(targetUrl, '_blank', 'noreferrer,noopener');
    setUserMsg('');
  };

  return (
    <div id="bitty-whatsapp-floating-widget" className="fixed bottom-6 right-6 z-50 font-sans select-none pointer-events-auto">
      {isOpen ? (
        /* Expanded Live Messenger Popover Card */
        <div 
          id="wa-messenger-box"
          className="bg-zinc-90 w-[310px] sm:w-[340px] bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden animate-fadeIn"
        >
          {/* Header Block in Official Brand Green */}
          <div className="bg-emerald-600 px-4 py-4 flex items-center justify-between text-white relative">
            <div className="flex items-center gap-2.5">
              <div className="relative">
                {bittyProfile?.avatarUrl ? (
                  <img 
                    src={bittyProfile.avatarUrl} 
                    alt="Bitty Avatar"
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 rounded-full object-cover border border-emerald-500 bg-zinc-950 shrink-0"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-gradient-to-b from-amber-400 to-amber-650 border border-emerald-500 flex items-center justify-center text-zinc-950 font-black text-sm shadow-md shrink-0 select-none">
                    B
                  </div>
                )}
                <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-400 border-2 border-emerald-600 rounded-full"></span>
              </div>
              <div className="leading-tight">
                <h4 className="font-extrabold text-sm tracking-tight text-white uppercase">Bitty</h4>
                <span className="text-[10px] text-emerald-100 font-medium">Active (Homeschool Hours)</span>
              </div>
            </div>
            
            <button 
              onClick={() => setIsOpen(false)}
              className="text-emerald-100 hover:text-white p-1 rounded-lg hover:bg-emerald-700/50 transition-all cursor-pointer shrink-0"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Visual Message Feed Scroll Panel */}
          <div className="p-4 bg-[#0a090f] max-h-[220px] overflow-y-auto space-y-3.5 relative">
            <div className="absolute inset-0 bg-gradient-to-tr from-emerald-500/[0.01] to-transparent pointer-events-none"></div>
            
            {/* Timestamp */}
            <div className="text-center">
              <span className="text-[9px] font-mono text-zinc-600 bg-zinc-950 px-2 py-0.5 rounded-full uppercase">Today</span>
            </div>

            {/* Simulated Chat bubble from Bitty */}
            <div className="flex gap-2">
              <div className="bg-zinc-850 text-zinc-200 text-[11.5px] leading-relaxed p-3 rounded-2xl rounded-tl-none border border-zinc-800 max-w-[85%] shadow-md">
                <p className="font-serif italic mb-1.5 text-zinc-300">
                  "Hey! I'm Bitty. If you secured a Chat Slot and received approval, tap below to open a direct 1-on-1 private line on WhatsApp!"
                </p>
                <span className="text-[9px] font-mono text-zinc-550 block text-right mt-1">Bitty • Support Admin</span>
              </div>
            </div>
          </div>

          {/* User Fast Send Box Form */}
          <form onSubmit={handleSubmitMsg} className="p-3 bg-zinc-900 border-t border-zinc-850 flex gap-2 items-center">
            <input 
              type="text"
              id="whatsapp-widget-message-input"
              name="whatsappMessage"
              value={userMsg}
              onChange={(e) => setUserMsg(e.target.value)}
              placeholder="Type your message to Bitty..."
              className="flex-grow bg-zinc-950 text-zinc-100 text-xs rounded-xl px-3.5 py-2.5 border border-zinc-800 outline-none focus:border-emerald-500/45 placeholder-zinc-600 transition-all"
            />
            <button
              type="submit"
              className="bg-emerald-600 hover:bg-emerald-500 text-white p-2.5 rounded-full shadow-lg shadow-emerald-500/10 cursor-pointer flex items-center justify-center hover:scale-105 active:scale-95 transition-all shrink-0"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      ) : (
        /* Floating Ripple WhatsApp support Button with Dismissal */
        <div className="flex items-center gap-1.5 pointer-events-auto">
          <button
            onClick={handleOpenWidget}
            className="group relative flex items-center gap-2.5 bg-emerald-600 hover:bg-emerald-500 px-4 py-3.5 rounded-full shadow-[0_20px_50px_rgba(16,185,129,0.3)] hover:shadow-[0_20px_50px_rgba(16,185,129,0.5)] transition-all duration-300 transform hover:scale-105 active:scale-95 cursor-pointer text-white font-extrabold uppercase text-[11px] tracking-wider"
          >
            {/* Notification Pulsing Indicator */}
            {hasPulse && (
              <span className="absolute -top-1.5 -right-1.5 flex h-4 w-4">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-4 w-4 bg-amber-500 text-[9px] font-black text-zinc-950 items-center justify-center leading-none">1</span>
              </span>
            )}

            {/* Official WhatsApp Outlined SVG path */}
            <svg className="w-4.5 h-4.5 fill-white" viewBox="0 0 24 24">
              <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.513 2.262 2.268 3.507 5.28 3.51 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.724-1.458L0 24zm6.59-4.846c1.6.95 3.1 1.45 4.7 1.45 5.336 0 9.673-4.334 9.676-9.67 0-2.584-1.006-5.01-2.834-6.84C16.304 2.25 13.882 1.24 11.3 1.24 11.3 1.24 11.3 1.24 11.2 1.24c-5.337 0-9.673 4.336-9.677 9.675 0 2.113.553 4.184 1.624 6.01L2.24 21.84l4.41-1.16c1.782.97 3.633 1.47 5.513 1.5l.004-.01-5.52-.016zM17.51 14.8c-.29-.145-1.72-.85-1.99-.95-.266-.1-.46-.144-.655.15-.19.294-.75.95-.92 1.14-.173.19-.347.21-.64.07-.3-.15-1.25-.46-2.39-1.47-.88-.78-1.48-1.76-1.65-2.05-.17-.29-.02-.45.13-.59.13-.13.3-.34.44-.5.15-.17.2-.29.3-.49.1-.2.05-.38-.02-.52-.07-.15-.65-1.58-.9-2.17-.25-.59-.5-.5-.68-.51-.18-.01-.39-.01-.59-.01-.2 0-.52.075-.8.375-.27.298-1.04 1.018-1.04 2.48s1.07 2.89 1.22 3.09c.15.2 2.11 3.22 5.11 4.52.71.31 1.27.5 1.71.64.72.23 1.37.2 1.89.12.58-.09 1.72-.7 1.96-1.38.24-.68.24-1.27.17-1.39-.07-.12-.27-.19-.57-.34z"/>
            </svg>
            
            <span>Chat on WhatsApp Business</span>
          </button>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setIsDismissed(true);
              try {
                localStorage.setItem('bitty_wa_widget_dismissed', 'true');
              } catch (err) {}
            }}
            className="bg-zinc-950/90 hover:bg-zinc-900 border border-zinc-800 text-zinc-500 hover:text-zinc-350 p-3.5 rounded-full transition-all cursor-pointer shadow-lg active:scale-90 flex items-center justify-center grow-0 shrink-0"
            title="Hide WhatsApp support bubble"
          >
            <X className="w-4 h-4 shrink-0" />
          </button>
        </div>
      )}
    </div>
  );
}
