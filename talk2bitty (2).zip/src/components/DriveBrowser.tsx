import React, { useState, useEffect } from 'react';
import { 
  googleSignIn, 
  googleLogout, 
  initGoogleAuth,
  listGoogleDriveFiles, 
  uploadFileToGoogleDrive, 
  deleteGoogleDriveFile, 
  DriveFile, getCachedAccessToken 
} from '../services/googleAuth';
import { User } from 'firebase/auth';
import { 
  File, FileText, Image, Folder, HelpCircle, 
  Search, RefreshCw, Upload, Trash2, LogOut, Link2, Check, ExternalLink, AlertCircle 
} from 'lucide-react';

interface DriveBrowserProps {
  onSelectFiles?: (files: DriveFile[]) => void;
  selectedFiles?: DriveFile[];
  isSelectionMode?: boolean;
}

export default function DriveBrowser({ onSelectFiles, selectedFiles = [], isSelectionMode = true }: DriveBrowserProps) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [files, setFiles] = useState<DriveFile[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Tab filters
  const [filterType, setFilterType] = useState<'all' | 'documents' | 'images'>('all');

  // File Upload states
  const [uploadProgress, setUploadProgress] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState<string | null>(null);

  // Destructive deletion confirmation state
  const [fileToDelete, setFileToDelete] = useState<DriveFile | null>(null);

  // Initialize auth state
  useEffect(() => {
    const unsubscribe = initGoogleAuth(
      (currentUser, currentToken) => {
        setUser(currentUser);
        setToken(currentToken);
        fetchFiles(currentToken);
      },
      () => {
        setUser(null);
        setToken(null);
        setFiles([]);
      }
    );
    return () => unsubscribe();
  }, []);

  const fetchFiles = async (currentToken: string, query?: string) => {
    setLoading(true);
    setError(null);
    try {
      const driveFiles = await listGoogleDriveFiles(currentToken, query);
      setFiles(driveFiles);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch files from Google Drive.');
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async () => {
    setError(null);
    setLoading(true);
    try {
      const result = await googleSignIn(true);
      if (result) {
        setUser(result.user);
        setToken(result.accessToken);
        fetchFiles(result.accessToken);
      }
    } catch (err: any) {
      const isClosedByUser = err?.code === 'auth/popup-closed-by-user' || 
                             err?.message?.includes('popup-closed-by-user');
      if (!isClosedByUser) {
        setError(err.message || 'Google Authenticate sequence rejected.');
      } else {
        console.log('Google Sign-In popup closed by user in Drive Browser.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await googleLogout();
      setUser(null);
      setToken(null);
      setFiles([]);
    } catch (err: any) {
      setError('Logout failed.');
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (token) {
      fetchFiles(token, searchQuery);
    }
  };

  const handleRefresh = () => {
    if (token) {
      fetchFiles(token, searchQuery);
    }
  };

  // Upload to Google Drive directly
  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !token) return;

    setUploadProgress(true);
    setError(null);
    setUploadSuccess(null);

    try {
      const uploaded = await uploadFileToGoogleDrive(token, file);
      setUploadSuccess(`"${uploaded.name}" uploaded successfully to Google Drive!`);
      // Add immediately to local list to save an extra network request
      setFiles(prev => [uploaded, ...prev]);
      
      // Auto dismiss success label
      setTimeout(() => setUploadSuccess(null), 4000);
    } catch (err: any) {
      setError(err.message || 'Error occurred during file upload.');
    } finally {
      setUploadProgress(false);
    }
  };

  // Perform safe deletion of files with explicit confirmation dialog
  const handleConfirmDelete = async () => {
    if (!fileToDelete || !token) return;

    setLoading(true);
    setError(null);
    const deletedFileName = fileToDelete.name;

    try {
      await deleteGoogleDriveFile(token, fileToDelete.id);
      setFiles(prev => prev.filter(f => f.id !== fileToDelete.id));
      setUploadSuccess(`"${deletedFileName}" deleted from your Google Drive.`);
      setTimeout(() => setUploadSuccess(null), 4000);
    } catch (err: any) {
      setError(err.message || 'Could not complete file disposal.');
    } finally {
      setFileToDelete(null);
      setLoading(false);
    }
  };

  // File selection toggle callback
  const handleToggleSelectFile = (file: DriveFile) => {
    if (!onSelectFiles) return;

    const exists = selectedFiles.some(f => f.id === file.id);
    if (exists) {
      onSelectFiles(selectedFiles.filter(f => f.id !== file.id));
    } else {
      onSelectFiles([...selectedFiles, file]);
    }
  };

  // Compile icon by mime type
  const getFileIcon = (mimeType: string) => {
    if (mimeType.includes('folder')) return <Folder className="w-5 h-5 text-amber-500 fill-amber-500/20" />;
    if (mimeType.includes('image')) return <Image className="w-5 h-5 text-emerald-400" />;
    if (mimeType.includes('document') || mimeType.includes('pdf') || mimeType.includes('text')) {
      return <FileText className="w-5 h-5 text-blue-400" />;
    }
    return <File className="w-5 h-5 text-zinc-400" />;
  };

  // Apply visual category standard filters (client side)
  const filteredFiles = files.filter(file => {
    if (filterType === 'all') return true;
    if (filterType === 'documents') {
      return file.mimeType.includes('document') || 
             file.mimeType.includes('pdf') || 
             file.mimeType.includes('text') || 
             file.mimeType.includes('spreadsheet');
    }
    if (filterType === 'images') {
      return file.mimeType.includes('image');
    }
    return true;
  });

  return (
    <div id="google-drive-explorer" className="bg-zinc-900 border border-zinc-850 rounded-2xl p-6 space-y-6">
      
      {/* Header element */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-800 pb-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M19.467 15.3333L14.733 6.99997H9.26697L4.53303 15.3333H19.467Z" fill="#132F23" />
              <path d="M19.467 15.3333L16.2 21H7.80003L4.53303 15.3333H19.467Z" fill="#0E241E" />
              <path d="M9.26697 6.99997L12 2.1333L14.733 6.99997H9.26697Z" fill="#1B4231" />
              <path d="M12 2.1333L16.2 9.46664" fill="none" stroke="#22C55E" strokeWidth="2" strokeLinecap="round" />
              <path d="M4.53303 15.3333L9.26697 6.99997" fill="none" stroke="#EAB308" strokeWidth="2" strokeLinecap="round" />
              <path d="M19.467 15.3333L7.80003 21" fill="none" stroke="#3B82F6" strokeWidth="2" strokeLinecap="round" />
            </svg>
            <h3 className="text-xs sm:text-sm font-black font-mono uppercase tracking-widest text-zinc-300">
              Google Drive Repository
            </h3>
          </div>
          <p className="text-[10px] text-zinc-500 font-sans leading-relaxed">
            Review, upload, and select important background reading or PDF files straight from your Google Drive.
          </p>
        </div>

        {/* Auth profile pill or login */}
        {user && token ? (
          <div className="flex items-center gap-3 bg-zinc-950 p-2 border border-zinc-850 rounded-xl max-w-full">
            {user.photoURL ? (
              <img 
                src={user.photoURL} 
                alt={user.displayName || 'Google Member'} 
                className="w-7 h-7 rounded-lg border border-zinc-800 object-cover"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-7 h-7 rounded-lg bg-zinc-800 flex items-center justify-center font-mono font-bold text-zinc-450 uppercase text-[10px]">
                {user.displayName?.charAt(0) || 'G'}
              </div>
            )}
            <div className="flex-1 min-w-0 pr-1">
              <p className="text-[10px] text-zinc-300 font-bold font-sans truncate select-none leading-tight">
                {user.displayName || 'Authorized Member'}
              </p>
              <p className="text-[8px] text-zinc-550 font-mono truncate select-none leading-none">
                {user.email || 'Google Connected'}
              </p>
            </div>
            
            <button
              onClick={handleLogout}
              type="button"
              className="p-1 px-2 text-[9px] font-mono text-zinc-500 hover:text-red-400 bg-zinc-900 border border-zinc-850 hover:bg-neutral-950 hover:border-red-950/40 rounded transition-all cursor-pointer"
              title="Disconnect Google Drive"
            >
              Sign Out
            </button>
          </div>
        ) : null}
      </div>

      {/* Main Container */}
      {!user || !token ? (
        <div className="py-12 bg-zinc-950/30 border border-zinc-850/60 rounded-2xl flex flex-col items-center text-center px-6 space-y-6">
          <div className="w-14 h-14 rounded-2xl bg-zinc-900 flex items-center justify-center border border-zinc-800">
            <svg className="w-8 h-8 text-zinc-550" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 16.5V9.75m0 0l3 3m-3-3l-3 3M6.75 19.5a4.5 4.5 0 01-1.41-8.775 5.25 5.25 0 0110.233-2.33 3 3 0 013.758 3.848A3.752 3.752 0 0118 19.5H6.75z" />
            </svg>
          </div>

          <div className="space-y-2 max-w-sm">
            <h4 className="text-xs font-black font-mono tracking-widest text-zinc-400 uppercase">
              Authorize Bitty To View Drive
            </h4>
            <p className="text-[11px] text-zinc-500 leading-normal">
              To securely browse and reference your personal documents during intake, authorize read capabilities directly to Bitty's console using Google's secure account prompt:
            </p>
          </div>

          {/* Clean custom Google Sign-In button built natively following branding expectations */}
          <button
            onClick={handleLogin}
            disabled={loading}
            type="button"
            className="flex items-center gap-3 bg-white hover:bg-zinc-100 text-zinc-900 font-sans font-medium text-xs sm:text-sm px-4 py-2.5 rounded-xl border border-zinc-300 shadow-md transition-all active:scale-[0.98] cursor-pointer"
          >
            <svg className="w-4 h-4" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
              <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
              <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
              <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
              <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
            </svg>
            <span>{loading ? 'Opening popup...' : 'Connect to Google Drive'}</span>
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          
          {/* Action alerts */}
          {error && (
            <div className="bg-red-500/5 border border-red-550/20 text-red-400 p-3 rounded-xl text-xs flex items-center gap-2 font-mono">
              <span className="w-1.5 h-1.5 bg-red-400 rounded-full shrink-0"></span>
              <span>{error}</span>
            </div>
          )}

          {uploadSuccess && (
            <div className="bg-emerald-500/5 border border-emerald-550/20 text-emerald-400 p-3 rounded-xl text-xs flex items-center gap-2 font-mono">
              <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full shrink-0 animate-ping"></span>
              <span>{uploadSuccess}</span>
            </div>
          )}

          {/* Browser Navigation Controls */}
          <div className="flex flex-col sm:flex-row items-center gap-3">
            <form onSubmit={handleSearch} className="flex-1 w-full relative">
              <input
                type="text"
                id="drive-browser-search-input"
                name="driveSearchQuery"
                placeholder="Search files by phrase..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-850 focus:border-amber-500/40 rounded-xl py-2 pl-9 pr-4 text-xs outline-none font-sans text-zinc-300 placeholder-zinc-600"
              />
              <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-zinc-600" />
            </form>

            <div className="flex items-center gap-2 w-full sm:w-auto self-stretch">
              <button
                type="button"
                onClick={handleRefresh}
                className="bg-zinc-950 hover:bg-zinc-850 p-2 border border-zinc-850 hover:text-zinc-200 text-zinc-450 rounded-xl cursor-pointer transition-colors shrink-0"
                title="Refresh File List"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              </button>

              {/* Upload to Google Drive file input trigger */}
              <label className="flex-1 sm:flex-initial bg-zinc-800 hover:bg-zinc-750 border border-zinc-700 text-zinc-200 text-xs font-mono font-black uppercase px-4 py-2.5 rounded-xl cursor-pointer transition-all flex items-center justify-center gap-2">
                <Upload className="w-3.5 h-3.5 text-zinc-300" />
                <span>{uploadProgress ? 'Uploading...' : 'Upload File'}</span>
                <input
                  type="file"
                  id="drive-browser-file-picker"
                  name="driveUploadFile"
                  onChange={handleUpload}
                  disabled={uploadProgress}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          {/* Tab switches */}
          <div className="flex border-b border-zinc-850/80 gap-3.5 text-xs">
            {(['all', 'documents', 'images'] as const).map((t) => {
              const active = filterType === t;
              return (
                <button
                  key={t}
                  type="button"
                  onClick={() => setFilterType(t)}
                  className={`pb-2 outline-none cursor-pointer transition-all uppercase tracking-wide font-bold font-mono text-[10px] ${
                    active 
                      ? 'border-b-2 border-amber-500 text-zinc-150 font-black' 
                      : 'text-zinc-500 border-transparent hover:text-zinc-350'
                  }`}
                >
                  {t}
                </button>
              );
            })}
          </div>

          {/* Files collection */}
          {loading ? (
            <div className="py-12 text-center text-xs text-zinc-600 font-mono uppercase tracking-widest animate-pulse">
              Syncing Google Drive files...
            </div>
          ) : filteredFiles.length === 0 ? (
            <div className="py-12 text-center bg-zinc-950/20 border-2 border-dashed border-zinc-900 rounded-xl text-xs text-zinc-550 italic">
              No matching files found in your Google Drive folder.
            </div>
          ) : (
            <div className="overflow-hidden border border-zinc-850 rounded-xl divide-y divide-zinc-850 bg-zinc-950/40">
              {filteredFiles.map((file) => {
                const isSelected = selectedFiles.some(f => f.id === file.id);
                return (
                  <div 
                    key={file.id} 
                    className={`p-3.5 flex items-center justify-between gap-4 transition-colors group ${
                      isSelected ? 'bg-zinc-900/60' : 'hover:bg-zinc-900/25'
                    }`}
                  >
                    
                    {/* Icon + Title */}
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      
                      {/* Selection Box if callable */}
                      {isSelectionMode && onSelectFiles && (
                        <button
                          type="button"
                          onClick={() => handleToggleSelectFile(file)}
                          className={`w-4 h-4 rounded-md border flex items-center justify-center transition-all cursor-pointer ${
                            isSelected 
                              ? 'bg-amber-500 border-amber-500 text-zinc-950' 
                              : 'border-zinc-700 hover:border-amber-500/55 text-transparent'
                          }`}
                        >
                          <Check className="w-2.5 h-2.5 stroke-[3]" />
                        </button>
                      )}

                      <div className="shrink-0">{getFileIcon(file.mimeType)}</div>

                      <div className="flex flex-col min-w-0">
                        <span className="text-zinc-200 font-sans text-xs font-semibold truncate">
                          {file.name}
                        </span>
                        <div className="flex items-center gap-2 text-[9px] text-zinc-550 font-mono">
                          <span>
                            {file.size 
                              ? `${(parseInt(file.size) / (1024 * 1024)).toFixed(2)} MB` 
                              : 'Unknown size'
                            }
                          </span>
                          <span>•</span>
                          <span>
                            {file.modifiedTime 
                              ? new Date(file.modifiedTime).toLocaleDateString() 
                              : 'Unknown edit date'
                            }
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Action Panel */}
                    <div className="flex items-center gap-2">
                      {file.webViewLink && (
                        <a 
                          href={file.webViewLink} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-[10px] text-zinc-400 hover:text-zinc-200 font-mono px-2 py-1 rounded inline-flex items-center gap-1 transition-all"
                        >
                          <ExternalLink className="w-3 h-3" />
                          <span className="hidden sm:inline">View</span>
                        </a>
                      )}

                      <button
                        type="button"
                        onClick={() => setFileToDelete(file)}
                        className="bg-zinc-900 hover:bg-red-950/20 border border-zinc-800 hover:border-red-900/30 text-zinc-550 hover:text-red-400 p-1 rounded transition-all cursor-pointer"
                        title="Delete from Google Drive"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                  </div>
                );
              })}
            </div>
          )}

          {/* Connected selection summary info banner */}
          {isSelectionMode && selectedFiles.length > 0 && (
            <div className="p-3 bg-zinc-950/80 border border-amber-500/20 rounded-xl flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                <span className="text-[10px] font-mono text-zinc-350 tracking-tight">
                  <strong className="text-amber-400">{selectedFiles.length}</strong> file(s) selected to attach to conversation intake.
                </span>
              </div>
              <button 
                type="button"
                onClick={() => onSelectFiles?.([])}
                className="text-[9px] font-mono uppercase font-black text-zinc-500 hover:text-zinc-300 underline cursor-pointer"
              >
                Clear all
              </button>
            </div>
          )}

        </div>
      )}

      {/* Structured Deletion Confirmation Modal Dialog (Safeguard) */}
      {fileToDelete && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50 animate-fadeIn backdrop-blur-xs">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl max-w-sm w-full p-6 space-y-6 shadow-2xl">
            <div className="flex items-center gap-3 text-red-400 border-b border-zinc-805 pb-3">
              <AlertCircle className="w-5 h-5 shrink-0" />
              <h4 className="text-xs font-black font-mono uppercase tracking-widest text-zinc-200">
                Confirm Deletion
              </h4>
            </div>

            <div className="space-y-2 text-xs text-zinc-400">
              <p>
                Are you sure you want to permanently delete the following file from your personal Google Drive?
              </p>
              <p className="bg-zinc-950 p-2.5 rounded-xl text-zinc-300 font-mono font-semibold break-all border border-zinc-850">
                {fileToDelete.name}
              </p>
              <p className="text-[10px] text-zinc-500 leading-normal italic">
                This action is irreversible and edits will run directly on your Google Drive storage.
              </p>
            </div>

            <div className="flex gap-2.5">
              <button
                type="button"
                onClick={() => setFileToDelete(null)}
                className="flex-1 bg-zinc-800 hover:bg-zinc-750 text-zinc-300 text-xs font-mono font-black uppercase py-2.5 rounded-xl cursor-pointer border border-zinc-750 text-center"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="flex-1 bg-red-650 hover:bg-red-550 text-white text-xs font-mono font-black uppercase py-2.5 rounded-xl cursor-pointer text-center"
              >
                Delete File
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
