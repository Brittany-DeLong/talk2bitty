import React, { useState } from 'react';
import { ConversationRequest, PaymentRecord, GlobalSettings } from '../types';
import { 
  Search, Check, X, Clipboard, 
  DollarSign, Activity, Trash2, 
  ShieldAlert, Camera, Sparkles,
  ToggleRight, ToggleLeft, RefreshCw, FileText,
  Upload, Plus, Minus, Crop
} from 'lucide-react';
import ImageCropperModal from './ImageCropperModal';
import { uploadBase64ToFirebaseStorage, deleteFileFromFirebaseStorageByUrl } from '../services/googleAuth';
import { compressImage } from '../services/imageCompressor';

interface AdminPanelProps {
  requests: ConversationRequest[];
  payments: PaymentRecord[];
  globalSettings: GlobalSettings;
  bittyProfile: { avatarUrl: string; bio: string };
  onUpdateSettings: (settings: GlobalSettings) => void;
  onUpdateRequestStatus: (
    requestId: string,
    newStatus: ConversationRequest['status'],
    adminNotes: string
  ) => void;
  onUpdateBittyProfile: (avatarUrl: string, bio: string) => void;
  onDeleteRequest?: (requestId: string) => void;
}

export default function AdminPanel({
  requests,
  payments,
  globalSettings,
  bittyProfile,
  onUpdateSettings,
  onUpdateRequestStatus,
  onUpdateBittyProfile,
  onDeleteRequest,
}: AdminPanelProps) {
  
  // Search state
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'approved' | 'active' | 'completed' | 'declined' | 'refunded'>('all');

  // Interactive notes state (mapped by requestId)
  const [localNotes, setLocalNotes] = useState<{ [requestId: string]: string }>({});

  // Availability setup state
  const [availabilityStatus, setAvailabilityStatus] = useState<'open' | 'waitlist' | 'closed'>(
    globalSettings.availabilityStatus || (globalSettings.isAvailable ? 'open' : 'closed')
  );
  const [unavailableMsg, setUnavailableMsg] = useState(globalSettings.unavailableMessage);
  const [waitlistMsg, setWaitlistMsg] = useState(
    globalSettings.waitlistMessage || 'Bitty is currently full and running on waitlist mode. Enter your email to be the first to know when standard conversation slots open back up!'
  );
  const [contactType, setContactType] = useState<'phone' | 'email' | 'chat_link' | 'whatsapp'>(
    globalSettings.contactType || 'phone'
  );
  const [customContactInfo, setCustomContactInfo] = useState(
    globalSettings.customContactInfo || '12207102021'
  );
  const [enableDrivePortal, setEnableDrivePortal] = useState<boolean>(
    globalSettings.enableDrivePortal !== undefined ? globalSettings.enableDrivePortal : false
  );
  const [settingsSaved, setSettingsSaved] = useState(false);

  // Gallery photo state inside Admin Panel
  const defaultSlots = [
    { id: 'slot_polaroid', name: 'Home Page Vintage Polaroid Frame', url: '', caption: 'Me 🤍' },
    { id: 'slot_about_family', name: 'Meet the Feathered Toddlers (Cockatoo Birds Showcase)', url: 'https://images.unsplash.com/photo-1548232623-24831a788647?w=800', caption: 'Meet the Feathered Toddlers' },
    { id: 'slot_about_intro', name: 'About Page Introduction Bio Photo (Bitty\'s Spot)', url: '', caption: 'Creating space for genuine thoughts.' },
    { id: 'slot_community', name: 'Community Pin Board Collage Banner Banner', url: '', caption: 'Daily visual anchor' }
  ];

  const [galleryPhotos, setGalleryPhotos] = useState<any[]>(
    globalSettings.galleryPhotos && globalSettings.galleryPhotos.length > 0
      ? globalSettings.galleryPhotos
      : defaultSlots
  );
  const [uploadedPhotos, setUploadedPhotos] = useState<any[]>(
    globalSettings.uploadedPhotos || []
  );
  const [isUploadingToFirebase, setIsUploadingToFirebase] = useState(false);
  const [firebaseUploadError, setFirebaseUploadError] = useState<string | null>(null);
  const [firebaseSuccessMessage, setFirebaseSuccessMessage] = useState<string | null>(null);
  const [assigningSlotIndex, setAssigningSlotIndex] = useState<number | null>(null); // -1 for main profile avatar, or index in galleryPhotos list
  const [gallerySaved, setGallerySaved] = useState(false);

  // Camera & local uploader crop states:
  const [rawImageSrc, setRawImageSrc] = useState<string | null>(null);
  const [croppingSlotIndex, setCroppingSlotIndex] = useState<number | null>(null); // -1 for main avatar, >=0 for galleryPhotos index
  const [croppingAspectRatio, setCroppingAspectRatio] = useState<number>(1);
  const [slotUploadError, setSlotUploadError] = useState<string | null>(null);

  const handleSlotFileChange = (e: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setSlotUploadError("Only image files are allowed.");
      return;
    }

    if (file.size > 3 * 1024 * 1024) {
      setSlotUploadError("Image too large. Max 3MB recommended so local sync holds!");
      return;
    }

    setSlotUploadError(null);
    const reader = new FileReader();
    reader.onloadend = () => {
      setCroppingSlotIndex(index);
      setRawImageSrc(reader.result as string);
      setCroppingAspectRatio(1); // 1:1 square is superb for Polaroid & avatar slots
    };
    reader.onerror = () => {
      setSlotUploadError("Failed to parse local image file.");
    };
    reader.readAsDataURL(file);
  };

  const handleAddSlot = () => {
    const nextIdx = galleryPhotos.length + 1;
    const newSlot = {
      id: `slot_custom_${Date.now()}`,
      name: `Custom Highlight Slot # ${nextIdx}`,
      url: '',
      caption: 'Describe this snapshot... 🤍',
      isCustom: true
    };
    setGalleryPhotos([...galleryPhotos, newSlot]);
  };

  const handleDeleteSlot = (index: number) => {
    const next = [...galleryPhotos];
    next.splice(index, 1);
    setGalleryPhotos(next);
  };

  // Waitlist emails state
  const [waitlist, setWaitlist] = useState<{ id: string; email: string; createdAt: string }[]>([]);
  const [loadingWaitlist, setLoadingWaitlist] = useState(false);

  const fetchWaitlist = async () => {
    setLoadingWaitlist(true);
    try {
      const response = await fetch('/api/admin/waitlist');
      if (response.ok) {
        const data = await response.json();
        setWaitlist(data.waitlist || []);
      }
    } catch (err) {
      console.error("Failed to load waitlist:", err);
    } finally {
      setLoadingWaitlist(false);
    }
  };

  React.useEffect(() => {
    fetchWaitlist();
  }, []);

  React.useEffect(() => {
    if (bittyProfile) {
      if (bittyProfile.avatarUrl !== undefined && bittyProfile.avatarUrl !== null) {
        setBittyAvatar(bittyProfile.avatarUrl);
      }
      if (bittyProfile.bio !== undefined && bittyProfile.bio !== null) {
        setBittyBio(bittyProfile.bio);
      }
    }
  }, [bittyProfile]);

  React.useEffect(() => {
    if (globalSettings) {
      if (globalSettings.availabilityStatus) {
        setAvailabilityStatus(globalSettings.availabilityStatus);
      }
      if (globalSettings.unavailableMessage !== undefined) {
        setUnavailableMsg(globalSettings.unavailableMessage);
      }
      if (globalSettings.waitlistMessage !== undefined) {
        setWaitlistMsg(globalSettings.waitlistMessage || '');
      }
      if (globalSettings.customContactInfo !== undefined) {
        setCustomContactInfo(globalSettings.customContactInfo || '');
      }
      if (globalSettings.enableDrivePortal !== undefined) {
        setEnableDrivePortal(globalSettings.enableDrivePortal);
      }
      if (globalSettings.galleryPhotos && globalSettings.galleryPhotos.length > 0) {
        setGalleryPhotos(globalSettings.galleryPhotos);
      }
      if (globalSettings.uploadedPhotos) {
        setUploadedPhotos(globalSettings.uploadedPhotos);
      }
    }
  }, [globalSettings]);

  const handleRemoveWaitlistItem = async (id: string) => {
    try {
      const response = await fetch('/api/admin/waitlist/remove', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      if (response.ok) {
        const data = await response.json();
        setWaitlist(data.waitlist || []);
      }
    } catch (err) {
      console.error("Failed to remove waitlist item:", err);
    }
  };

  // Bitty Profile Editing States
  const [bittyAvatar, setBittyAvatar] = useState(bittyProfile?.avatarUrl || '');
  const [bittyBio, setBittyBio] = useState(bittyProfile?.bio || '');
  const [profileSaved, setProfileSaved] = useState(false);
  const [avatarError, setAvatarError] = useState('');

  const handleSaveSettings = () => {
    onUpdateSettings({
      isAvailable: availabilityStatus === 'open',
      availabilityStatus,
      unavailableMessage: unavailableMsg,
      waitlistMessage: waitlistMsg,
      contactType: 'whatsapp',
      customContactInfo,
      enableDrivePortal,
      galleryPhotos, // Preserve gallery photo slots configuration!
      uploadedPhotos // Save our uploaded Firebase photo pool!
    });
    setSettingsSaved(true);
    setTimeout(() => setSettingsSaved(false), 2500);
  };

  const handleSaveGalleryPhotos = () => {
    onUpdateSettings({
      ...globalSettings,
      galleryPhotos,
      uploadedPhotos // Save our uploaded Firebase photo pool!
    });
    setGallerySaved(true);
    setTimeout(() => setGallerySaved(false), 2500);
  };

  const handleSaveBittyProfile = () => {
    onUpdateBittyProfile(bittyAvatar, bittyBio);
    setProfileSaved(true);
    setTimeout(() => setProfileSaved(false), 2500);
  };

  const handleSaveNotesAndStatus = (
    reqId: string, 
    newStatus: ConversationRequest['status'], 
    currentNotes: string
  ) => {
    const finalNotes = localNotes[reqId] !== undefined ? localNotes[reqId] : currentNotes;
    onUpdateRequestStatus(reqId, newStatus, finalNotes);
  };

  // Search logic
  const filteredRequests = requests.filter((req) => {
    const visibleName = req.isAnonymous ? 'Anonymous Client' : req.userName;
    const matchesSearch =
      visibleName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      req.topic.toLowerCase().includes(searchQuery.toLowerCase()) ||
      req.id.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = filterStatus === 'all' ? true : req.status === filterStatus;

    return matchesSearch && matchesStatus;
  });

  // Calculate earnings and counts
  const totalRevenue = payments
    .filter((p) => p.status === 'paid')
    .reduce((sum, p) => sum + p.amount, 0);

  const pendingCount = requests.filter((r) => r.status === 'pending').length;
  const activeCount = requests.filter((r) => r.status === 'active').length;

  return (
    <div className="max-w-6xl mx-auto space-y-10 py-4">
      
      {/* Page Title Header */}
      <div className="space-y-1">
        <h2 className="text-2xl font-black text-zinc-100 uppercase tracking-tight">Admin Operations Deck</h2>
        <p className="text-zinc-450 text-xs">
          Exclusive console for Bitty. Set global availability state, curate gallery photos, and manage subscriber waitlists.
        </p>
      </div>

      {/* METRICS GRID */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        
        {/* Metric 1 */}
        <div className="bg-zinc-900 border border-zinc-850 p-5 rounded-2xl flex items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider font-extrabold block">Estimated Earnings</span>
            <span className="text-3xl font-black text-emerald-400 tracking-tight">${totalRevenue}.00</span>
          </div>
          <div className="w-12 h-12 bg-emerald-500/10 rounded-xl flex items-center justify-center text-emerald-400">
            <DollarSign className="w-6 h-6" />
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-zinc-900 border border-zinc-850 p-5 rounded-2xl flex items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider font-extrabold block">Pending Intake Forms</span>
            <span className="text-3xl font-black text-amber-400 tracking-tight">{pendingCount}</span>
          </div>
          <div className="w-12 h-12 bg-amber-500/10 rounded-xl flex items-center justify-center text-amber-400">
            <Clipboard className="w-6 h-6 animate-pulse" />
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-zinc-900 border border-zinc-850 p-5 rounded-2xl flex items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider font-extrabold block">Live Underway Dialogues</span>
            <span className="text-3xl font-black text-indigo-400 tracking-tight">{activeCount}</span>
          </div>
          <div className="w-12 h-12 bg-indigo-500/10 rounded-xl flex items-center justify-center text-indigo-400">
            <Activity className="w-6 h-6" />
          </div>
        </div>

      </div>

      {/* SYSTEM AVAILABILITY CONTROL PANEL (Bitty's Global Availability Settings) */}
      <div className="bg-zinc-950 border-2 border-zinc-850 rounded-2xl p-6 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-900 pb-4">
          <div className="space-y-1 col-span-2">
            <h3 className="text-sm font-black text-zinc-300 uppercase font-mono tracking-wider">Bitty’s Global Availability Settings</h3>
            <p className="text-zinc-500 text-xs text-left">
              Manage your current mode to either accept passes, collect notifications via a waitlist, or disable incoming passes completely.
            </p>
          </div>
          
          <div className="flex bg-zinc-900 p-1 border border-zinc-800 rounded-xl gap-1 shrink-0 self-start sm:self-auto">
            {(['open', 'waitlist', 'closed'] as const).map((statusOption) => {
              const isActive = availabilityStatus === statusOption;
              const styles = {
                open: isActive 
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-900/30 font-bold' 
                  : 'text-zinc-500 border-transparent hover:text-zinc-400',
                waitlist: isActive 
                  ? 'bg-amber-500/10 text-amber-400 border-amber-900/30 font-bold' 
                  : 'text-zinc-500 border-transparent hover:text-zinc-400',
                closed: isActive 
                  ? 'bg-red-500/10 text-red-400 border-red-900/30 font-bold' 
                  : 'text-zinc-500 border-transparent hover:text-zinc-400'
              };
              const label = {
                open: 'Open (Active)',
                waitlist: 'Waitlist',
                closed: 'Paused (Off)'
              };
              return (
                <button
                  key={statusOption}
                  type="button"
                  onClick={() => setAvailabilityStatus(statusOption)}
                  className={`text-[10px] font-mono uppercase py-1.5 px-3 border rounded-lg transition-all cursor-pointer outline-none ${styles[statusOption]}`}
                >
                  {label[statusOption]}
                </button>
              );
            })}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
          <div className="space-y-3">
            <label className="block text-[11px] font-mono text-zinc-405 uppercase tracking-wider font-black">
              Unavailable Downtime Notice Display:
            </label>
            <textarea 
              rows={3}
              value={unavailableMsg}
              onChange={(e) => setUnavailableMsg(e.target.value)}
              placeholder="e.g. Bitty is currently with family or completing exams. Feel free to connect in the community..."
              className="w-full bg-zinc-900 border border-zinc-850 text-zinc-100 text-xs rounded-xl p-3 focus:outline-none focus:border-amber-500/40 resize-none font-medium"
            />
            <p className="text-[10px] text-zinc-500 leading-relaxed text-left">
              Used when Bitty is set to <span className="text-red-400 font-bold">Paused (Off)</span> limit.
            </p>
          </div>

          <div className="space-y-3">
            <label className="block text-[11px] font-mono text-zinc-405 uppercase tracking-wider font-black">
              Waitlist Alert Notice Display:
            </label>
            <textarea 
              rows={3}
              value={waitlistMsg}
              onChange={(e) => setWaitlistMsg(e.target.value)}
              placeholder="e.g. Bitty is currently running on waitlist. Leave your email to receive an early alert..."
              className="w-full bg-zinc-900 border border-zinc-850 text-zinc-100 text-xs rounded-xl p-3 focus:outline-none focus:border-amber-500/40 resize-none font-medium"
            />
            <p className="text-[10px] text-zinc-500 leading-relaxed text-left">
              Used when Bitty is set to <span className="text-amber-400 font-bold">Waitlist</span> limit.
            </p>
          </div>

          {/* Secure Helpline configuration for paid members (WhatsApp Only) */}
          <div className="border-t border-zinc-900 col-span-full pt-5 space-y-4">
            <div className="space-y-1 text-left">
              <h4 className="text-xs font-black font-mono tracking-wider text-amber-500 uppercase flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span>
                Official Paid Member WhatsApp Connection Line
              </h4>
              <p className="text-[10.5px] text-zinc-450 leading-relaxed">
                Configure your official WhatsApp Business number or custom invite link to be shown in the client dashboard once their pass is approved. By utilizing WhatsApp Business or a masked virtual WhatsApp profile, you ensure your personal cell number remains fully private while allowing clients to connect for their texting sessions.
              </p>
            </div>

            <div className="bg-zinc-900/10 p-4 rounded-xl border border-zinc-900 text-left space-y-2">
              <label className="block text-[9.5px] font-mono text-zinc-400 uppercase font-bold tracking-wider">
                WhatsApp Phone Number or Custom Invite URL Link:
              </label>
              <input
                type="text"
                id="admin-whatsapp-contact-input"
                name="customContactInfo"
                value={customContactInfo}
                onChange={(e) => setCustomContactInfo(e.target.value)}
                placeholder="e.g. 12207102021 or https://wa.me/12207102021"
                className="w-full bg-zinc-950 border border-zinc-850 text-zinc-200 text-xs rounded-xl px-3.5 py-2.5 outline-none focus:border-amber-500/40 font-mono"
              />
              <span className="text-[9.5px] text-zinc-500 block leading-tight">
                Enter the clean digit string with country code (e.g., 12207102021) or an invitation web link.
              </span>
            </div>
          </div>

          {/* Google Drive File Attachment option toggle switch */}
            <div className="bg-zinc-950/40 p-4 rounded-xl border border-zinc-900 flex items-center justify-between gap-4 mt-2">
              <div className="space-y-0.5 text-left">
                <span className="text-xs font-bold text-zinc-200 uppercase tracking-wide block">Enable Google Drive File Sharing Option</span>
                <span className="text-[10px] text-zinc-455 leading-relaxed block max-w-xl">
                  Leave this OFF if you want to keep the application straightforward with only text-and-phone interaction. Turn this ON if you want clients to be able to upload mock backstory documents or select case files from their Google Drive directory.
                </span>
              </div>
              <button
                type="button"
                onClick={() => setEnableDrivePortal(!enableDrivePortal)}
                className="text-amber-500 hover:text-amber-400 shrink-0 cursor-pointer transition-all duration-300"
              >
                {enableDrivePortal ? (
                  <ToggleRight className="w-10 h-10 stroke-[1.5]" />
                ) : (
                  <ToggleLeft className="w-10 h-10 text-zinc-700 stroke-[1.5]" />
                )}
              </button>
            </div>

          </div>

        {/* Dynamic Waitlist Subscriber Management Section */}
        <div className="pt-4 border-t border-zinc-900 space-y-4 text-left">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <h4 className="text-xs font-black font-mono tracking-wider text-zinc-400 uppercase">
                Waitlist Subscriber Directory ({waitlist.length})
              </h4>
              <p className="text-zinc-550 text-[10px]">Patrons registered here will receive automatic emails when availability status shifts back to Open.</p>
            </div>
            
            <button
              onClick={fetchWaitlist}
              disabled={loadingWaitlist}
              className="text-[10px] font-mono font-bold text-zinc-405 hover:text-zinc-202 border border-zinc-800 bg-zinc-900 px-3 py-1 rounded hover:bg-zinc-850 cursor-pointer flex items-center gap-1.5 transition-all outline-none"
            >
              <RefreshCw className={`w-3 h-3 ${loadingWaitlist ? 'animate-spin' : ''}`} /> RELOAD SUBS
            </button>
          </div>

          {waitlist.length === 0 ? (
            <div className="p-4 text-center rounded-xl bg-zinc-950/60 border border-zinc-900 text-zinc-550 font-mono text-xs">
              Waitlist registry is currently clean.
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {waitlist.map((item) => (
                <div key={item.id} className="p-3 bg-zinc-950/60 border border-zinc-900 rounded-xl flex items-center justify-between gap-3 font-mono text-[11px]">
                  <div className="space-y-0.5">
                    <span className="text-zinc-250 font-bold block select-all">{item.email}</span>
                    <span className="text-zinc-550 font-semibold block text-[9.5px]">ADDED: {new Date(item.createdAt).toLocaleString()}</span>
                  </div>
                  <button
                    onClick={() => handleRemoveWaitlistItem(item.id)}
                    className="text-[10px] font-mono text-zinc-500 hover:text-red-400 px-2 py-1 rounded bg-zinc-900/40 hover:bg-red-950/20 border border-zinc-850 hover:border-red-900/30 transition-all cursor-pointer"
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="flex justify-between items-center pt-2">
          {settingsSaved ? (
            <span className="text-xs text-emerald-400 font-mono flex items-center gap-1.5 animate-pulse bg-emerald-950/20 py-1 px-2.5 rounded border border-[#065f46]/40 font-bold">
              <Check className="w-4 h-4" /> LIVE AVAILABILITY UPDATED SUCCESSFULLY
            </span>
          ) : (
            <span></span>
          )}

          <button
            onClick={handleSaveSettings}
            className="bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-xs py-2.5 px-6 rounded-xl uppercase tracking-wider cursor-pointer shadow-lg shadow-amber-500/5"
          >
            Save Controls
          </button>
        </div>
      </div>

      {/* BITTY'S PERSISTENT FIREBASE STORAGE MEDIA LIBRARY & POOL */}
      <div id="firebase-media-library" className="bg-zinc-950 border-2 border-zinc-850 rounded-2xl p-6 space-y-6">
        <div className="border-b border-zinc-900 pb-4 text-left">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <h3 className="text-sm font-black text-amber-500 uppercase font-mono tracking-wider flex items-center gap-2">
                <Sparkles className="text-amber-500 w-4 h-4" />
                Firebase Media Library Pool 📂
              </h3>
              <p className="text-zinc-550 text-xs">
                Upload photos directly to your secure Firebase Storage bucket. Keep an organized library of your Cockatoos, Toddlers, and personal snaps, and assign any image to specific slots instantly!
              </p>
            </div>
            
            <div className="flex items-center gap-3">
              <label className="shrink-0 bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-xs py-2 px-4 rounded-xl uppercase tracking-wider flex items-center gap-1.5 cursor-pointer shadow-lg shadow-amber-500/5 hover:scale-102 transition-transform self-start sm:self-center">
                <Upload className="w-3.5 h-3.5 text-zinc-950" />
                <span>Upload to Library</span>
                <input 
                  type="file" 
                  id="admin-library-upload-input"
                  name="libraryUploadInput"
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    const reader = new FileReader();
                    reader.onloadend = () => {
                      setCroppingSlotIndex(-2); // -2 represents the General Photo Library uploader
                      setRawImageSrc(reader.result as string);
                      setCroppingAspectRatio(1); // 1:1 ratio is phenomenal for library profiles
                    };
                    reader.readAsDataURL(file);
                  }}
                  className="hidden" 
                />
              </label>
            </div>
          </div>
        </div>

        {isUploadingToFirebase && (
          <div className="p-4 bg-zinc-900 border border-zinc-800 text-amber-500 text-xs rounded-xl font-mono flex items-center gap-3 animate-pulse">
            <RefreshCw className="w-4 h-4 animate-spin shrink-0" />
            <span>Processing photo crop & uploading into secure Google Cloud Storage bucket...</span>
          </div>
        )}

        {firebaseUploadError && (
          <div className="p-3 bg-red-950/20 border border-red-900/30 text-red-400 text-xs rounded-xl font-mono">
            ⚠️ {firebaseUploadError}
          </div>
        )}

        {firebaseSuccessMessage && (
          <div className="p-3 bg-emerald-950/20 border border-emerald-900/30 text-emerald-400 text-xs rounded-xl font-mono">
            ✨ {firebaseSuccessMessage}
          </div>
        )}

        {/* Media grid pool preview */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {uploadedPhotos.map((photo) => (
            <div key={photo.id} className="bg-zinc-900 border border-zinc-850 rounded-xl p-2.5 space-y-2 flex flex-col justify-between group relative hover:border-zinc-700 transition-colors">
              <div className="aspect-square w-full rounded-lg overflow-hidden bg-zinc-950 border border-zinc-850 relative">
                <img 
                  src={photo.url} 
                  alt={photo.name} 
                  className="w-full h-full object-cover" 
                  referrerPolicy="no-referrer"
                />
                
                {/* Actions overlay */}
                <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                  <button
                    onClick={async () => {
                      if (confirm("Delete this physical photo file from Firebase Storage permanently? Any active slot referencing it will fallback to empty link.")) {
                        try {
                          await deleteFileFromFirebaseStorageByUrl(photo.url);
                          const updated = uploadedPhotos.filter(p => p.id !== photo.id);
                          setUploadedPhotos(updated);
                          onUpdateSettings({
                            ...globalSettings,
                            uploadedPhotos: updated,
                            galleryPhotos
                          });
                          setFirebaseSuccessMessage("Photo physically removed from Firebase Storage!");
                          setTimeout(() => setFirebaseSuccessMessage(null), 2500);
                        } catch (err: any) {
                          setFirebaseUploadError("Failed to remove: " + err.message);
                        }
                      }
                    }}
                    className="p-1.5 bg-zinc-950/80 hover:bg-red-950 text-zinc-400 hover:text-red-400 rounded-md transition-all border border-zinc-800"
                    title="Delete permanently from Firebase Storage"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                  
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(photo.url);
                      setFirebaseSuccessMessage("Direct Storage URL copied to clipboard!");
                      setTimeout(() => setFirebaseSuccessMessage(null), 2500);
                    }}
                    className="p-1.5 bg-zinc-950/80 hover:bg-zinc-900 text-zinc-400 hover:text-amber-400 rounded-md transition-all border border-zinc-800"
                    title="Copy direct HTTPS URL"
                  >
                    <Clipboard className="w-3 h-3" />
                  </button>
                </div>
              </div>

              <div className="space-y-1 text-left min-w-0 pr-1">
                <h6 className="text-[11px] text-zinc-300 font-bold truncate font-mono uppercase tracking-tight">{photo.name}</h6>
                <p className="text-[9px] text-zinc-550 font-mono">{photo.uploadedAt || 'Uploaded Snap'}</p>
              </div>

              {/* Instant Slot Assigment Dropdown */}
              <div className="pt-1.5 border-t border-zinc-850/50">
                <select
                  onChange={(e) => {
                    const targetVal = e.target.value;
                    if (!targetVal) return;
                    
                    if (targetVal === 'bitty_avatar') {
                      setBittyAvatar(photo.url);
                      setFirebaseSuccessMessage("Assigned photo to Main Profile Bio avatar!");
                    } else {
                      const sIdx = parseInt(targetVal, 10);
                      const next = [...galleryPhotos];
                      next[sIdx].url = photo.url;
                      setGalleryPhotos(next);
                      setFirebaseSuccessMessage(`Assigned photo to spot: ${next[sIdx].name}!`);
                    }
                    
                    setTimeout(() => setFirebaseSuccessMessage(null), 3500);
                    e.target.value = ''; // reset Select
                  }}
                  className="w-full bg-zinc-950 border border-zinc-850 hover:border-amber-500/20 text-zinc-400 hover:text-amber-500 text-[10px] font-mono rounded px-1.5 py-1 focus:outline-none cursor-pointer text-center uppercase tracking-wider font-extrabold"
                  defaultValue=""
                >
                  <option value="" disabled>Assign Slot...</option>
                  <option value="bitty_avatar">Profile Picture / Bio</option>
                  {galleryPhotos.map((slot, sIdx) => (
                    <option key={slot.id} value={sIdx}>{slot.name}</option>
                  ))}
                </select>
              </div>
            </div>
          ))}

          {uploadedPhotos.length === 0 && (
            <div className="col-span-full py-8 text-center bg-zinc-900/30 border border-dashed border-zinc-850 rounded-2xl text-zinc-600 font-mono text-xs">
              📂 Your library is currently empty. Direct upload your toddlers, cockatoos, and personal snap photographs straight to Firebase Storage using the button above!
            </div>
          )}
        </div>
      </div>

      {/* BITTY'S CUSTOM PHOTOBOARD & LIFE SNIPPETS 📸 */}
      <div id="photoboard-editor" className="bg-zinc-950 border-2 border-zinc-800 rounded-2xl p-6 space-y-6">
        <div className="border-b border-zinc-900 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-left">
          <div className="space-y-1">
            <h3 className="text-sm font-black text-zinc-300 uppercase font-mono tracking-wider flex items-center gap-2">
              <Camera className="text-amber-500 w-4 h-4" />
              Bitty’s Custom Photoboard & Life Snippets 📸
            </h3>
            <p className="text-zinc-500 text-xs">
              Put pictures in different parts throughout the app for people to see, but they can't change them—only you can! Direct photo uploading and crop align supported below.
            </p>
          </div>
          <button
            type="button"
            onClick={handleAddSlot}
            className="shrink-0 bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-xs py-2 px-4 rounded-xl uppercase tracking-wider flex items-center gap-1.5 cursor-pointer shadow-lg shadow-amber-500/5 hover:scale-102 transition-transform self-start sm:self-center"
          >
            <Plus className="w-3.5 h-3.5 stroke-[3]" /> Add New Spot
          </button>
        </div>

        {slotUploadError && (
          <div className="p-3 bg-red-950/20 border border-red-900/30 text-red-400 text-xs rounded-xl font-mono">
            {slotUploadError}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
          {galleryPhotos.map((photo, index) => {
            const isCustomSlot = photo.isCustom || !['slot_polaroid', 'slot_about_family', 'slot_about_intro', 'slot_community'].includes(photo.id);
            return (
              <div key={photo.id} className="bg-zinc-900 border border-zinc-850 rounded-xl p-4 flex flex-col justify-between space-y-4">
                
                {/* Visual Image Preview area */}
                <div className="flex gap-4 items-start">
                  <div className="w-20 h-20 rounded-lg bg-zinc-950 border border-zinc-800 overflow-hidden flex items-center justify-center shrink-0">
                    {photo.url ? (
                      <img 
                        src={photo.url} 
                        alt="Slot preview" 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="text-[10px] text-zinc-650 font-mono text-center px-1">
                        No image uploaded or pasted
                      </div>
                    )}
                  </div>

                  <div className="space-y-1 flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[9px] font-mono text-amber-500 font-extrabold uppercase bg-amber-500/10 px-1.5 py-0.5 rounded shrink-0">
                        Slot ID: {photo.id.replace('slot_custom_', 'custom_')}
                      </span>
                      {isCustomSlot && (
                        <button
                          type="button"
                          onClick={() => handleDeleteSlot(index)}
                          className="text-zinc-550 hover:text-red-400 transition-colors p-1"
                          title="Delete custom slot"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                    {isCustomSlot ? (
                      <input 
                        type="text"
                        id={`admin-slot-name-input-${photo.id || index}`}
                        name="slotName"
                        value={photo.name}
                        onChange={(e) => {
                          const next = [...galleryPhotos];
                          next[index].name = e.target.value;
                          setGalleryPhotos(next);
                        }}
                        className="w-full bg-zinc-950 border border-zinc-850 text-zinc-200 rounded px-2 py-1 focus:outline-none focus:border-amber-500 text-xs font-bold font-mono"
                        placeholder="Configure Slot Name..."
                      />
                    ) : (
                      <div className="space-y-1">
                        <h5 className="text-zinc-250 text-xs font-black leading-tight uppercase font-mono tracking-tight text-amber-500">
                          {photo.id === 'slot_about_family' ? 'Meet the Feathered Toddlers (Birds)' : photo.name}
                        </h5>
                        <p className="text-[10px] text-zinc-500 font-mono">
                          {photo.id === 'slot_polaroid' ? 'Default Static Slot (Polaroid Frame)' :
                           photo.id === 'slot_about_family' ? 'Default Static Slot (Birds Showcase)' :
                           photo.id === 'slot_about_intro' ? 'Default Static Slot (Intro Bio Photo)' :
                           photo.id === 'slot_community' ? 'Default Static Slot (Community Board)' : 'Default Slot'}
                        </p>
                      </div>
                    )}
                    <p className="text-zinc-400 text-[10px] leading-relaxed mt-1">
                      {photo.id === 'slot_polaroid' ? '🏠 Shows inside the handwritten style welcome envelope on the Front Homepage.' : 
                       photo.id === 'slot_about_family' ? '🦜 Shows inside the "Meet the Feathered Toddlers" birds card section on the About tab. Located above the Live Scrapbook Album.' :
                       photo.id === 'slot_about_intro' ? '👩 Shows in Bitty\'s personal intro letter vignette on the About tab (top bio).' :
                       photo.id === 'slot_community' ? '💬 Shows inside the header bulletin collage of your Community Wall tab.' :
                       '📸 Rendered inside your dynamic live scrapbook album photogrid.'}
                    </p>
                  </div>
                </div>

                {/* Edit forms */}
                <div className="space-y-3 text-xs">
                  {/* Local file upload field */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-mono text-zinc-450 uppercase block font-black">
                      Local Picture Upload & Crop Align
                    </label>
                    <label className="flex items-center justify-center gap-2 bg-zinc-950 hover:bg-zinc-850 border border-dashed border-zinc-850 hover:border-amber-500/30 text-zinc-400 hover:text-amber-400 px-3.5 py-2.5 rounded-xl cursor-pointer transition-colors text-xs font-mono uppercase font-black text-center select-none">
                      <Upload className="w-3.5 h-3.5 text-zinc-500 group-hover:text-amber-400" />
                      <span>{photo.url ? 'Choose another image...' : 'Upload & Align File'}</span>
                      <input 
                        type="file" 
                        id={`admin-slot-file-input-${photo.id || index}`}
                        name="slotFileInput"
                        accept="image/*"
                        onChange={(e) => handleSlotFileChange(e, index)}
                        className="hidden" 
                      />
                    </label>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono text-zinc-450 uppercase block font-black">Or Paste Picture URL</label>
                    <input 
                      type="url" 
                      id={`admin-slot-url-input-${photo.id || index}`}
                      name="slotUrlInput"
                      value={photo.url}
                      onChange={(e) => {
                        const next = [...galleryPhotos];
                        next[index].url = e.target.value;
                        setGalleryPhotos(next);
                      }}
                      onBlur={() => {
                        onUpdateSettings({
                          ...globalSettings,
                          galleryPhotos,
                          uploadedPhotos
                        });
                      }}
                      placeholder="Paste any HTTPS image URL (e.g. from Unsplash)"
                      className="w-full bg-zinc-950 border border-zinc-850 text-zinc-200 rounded-lg px-3 py-1.5 focus:outline-none focus:border-amber-505 font-mono text-[11px]"
                    />
                  </div>

                  {uploadedPhotos.length > 0 && (
                    <div className="space-y-1">
                      <label className="text-[10px] font-mono text-zinc-450 uppercase block font-black">Assign from Firebase Library</label>
                      <select
                        onChange={(e) => {
                          const url = e.target.value;
                          if (!url) return;
                          const next = [...galleryPhotos];
                          next[index].url = url;
                          setGalleryPhotos(next);
                          // Auto persist library assignment to database
                          onUpdateSettings({
                            ...globalSettings,
                            galleryPhotos: next,
                            uploadedPhotos
                          });
                          e.target.value = '';
                        }}
                        className="w-full bg-zinc-950 border border-zinc-850 text-zinc-300 rounded px-2.5 py-1.5 focus:outline-none focus:border-amber-500 text-xs font-mono cursor-pointer"
                        defaultValue=""
                      >
                        <option value="" disabled>Select a snapshot...</option>
                        {uploadedPhotos.map(p => (
                          <option key={p.id} value={p.url}>{p.name}</option>
                        ))}
                      </select>
                    </div>
                  )}

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono text-zinc-450 uppercase block font-black">Handwritten Caption</label>
                    <input 
                      type="text" 
                      id={`admin-slot-caption-input-${photo.id || index}`}
                      name="slotCaptionInput"
                      value={photo.caption || ''}
                      onChange={(e) => {
                        const next = [...galleryPhotos];
                        next[index].caption = e.target.value;
                        setGalleryPhotos(next);
                      }}
                      onBlur={() => {
                        onUpdateSettings({
                          ...globalSettings,
                          galleryPhotos,
                          uploadedPhotos
                        });
                      }}
                      placeholder="e.g. Meet the Feathered Toddlers 🤍"
                      className="w-full bg-zinc-950 border border-zinc-850 text-zinc-200 rounded-lg px-3 py-1.5 focus:outline-none focus:border-amber-505"
                    />
                  </div>
                </div>

              </div>
            );
          })}
        </div>

        <div className="flex justify-between items-center pt-2">
          {gallerySaved ? (
            <span className="text-xs text-amber-400 font-mono flex items-center gap-1.5 animate-pulse bg-amber-950/20 py-1 px-2.5 rounded border border-amber-900/40 font-bold">
              <Check className="w-4 h-4" /> PHOTOBOARD ALBUM PRESETTINGS STORED SUCCESSFULLY
            </span>
          ) : (
            <span></span>
          )}

          <button
            onClick={handleSaveGalleryPhotos}
            className="bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-xs py-2.5 px-6 rounded-xl uppercase tracking-wider cursor-pointer shadow-lg shadow-amber-500/5 ml-auto"
          >
            Save Photoboard Settings
          </button>
        </div>
      </div>

      {/* BITTY PERSONAL PROFILE PHOTO & BIO CONFIGURATION */}
      <div className="bg-zinc-950 border-2 border-zinc-850 rounded-2xl p-6 space-y-6">
        <div className="border-b border-zinc-900 pb-4 text-left">
          <h3 className="text-sm font-black text-zinc-300 uppercase font-mono tracking-wider">Bitty’s Profile Customization</h3>
          <p className="text-zinc-500 text-xs text-left">
            Upload your real photo (strictly no AI-generated images allowed) and customize your bio. All your posts and replies update instantly.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 items-start text-left">
          
          {/* Left section: Avatar display and file selector */}
          <div className="flex flex-col items-center gap-3 bg-zinc-900/40 p-4 border border-zinc-850 rounded-xl w-full">
            <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider font-extrabold block text-center">Profile Avatar</span>
            {bittyAvatar ? (
              <img 
                src={bittyAvatar} 
                alt="Bitty Avatar" 
                className="w-24 h-24 rounded-2xl border border-zinc-700 object-cover shadow-inner mx-auto mb-2"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-24 h-24 rounded-2xl border border-zinc-805 bg-zinc-950 flex items-center justify-center font-black text-[30px] text-zinc-650 font-mono mx-auto mb-2">
                B
              </div>
            )}

            <div className="w-full space-y-1.5 text-left mb-2 text-xs">
              <label className="text-[9px] font-mono text-zinc-500 uppercase tracking-wider block font-bold">Local Profile Photo Upload</label>
              <label className="flex items-center justify-center gap-2 bg-zinc-950 hover:bg-zinc-850 border border-dashed border-zinc-850 hover:border-amber-500/30 text-zinc-400 hover:text-amber-400 px-3 py-2 rounded-xl cursor-pointer transition-all text-xs font-mono uppercase font-black text-center select-none block mb-2">
                <Upload className="w-3.5 h-3.5 text-zinc-500" />
                <span>{bittyAvatar ? 'Choose another...' : 'Upload Avatar'}</span>
                <input 
                  type="file" 
                  id="admin-bitty-avatar-upload-file"
                  name="bittyAvatarUpload"
                  accept="image/*"
                  onChange={(e) => handleSlotFileChange(e, -1)}
                  className="hidden" 
                />
              </label>

              <label className="text-[9px] font-mono text-zinc-450 uppercase tracking-wider block font-black">Or Paste Avatar URL Address</label>
              <input 
                type="url" 
                id="admin-bitty-avatar-url-input"
                name="bittyAvatarUrl"
                value={bittyAvatar}
                onChange={(e) => {
                  setBittyAvatar(e.target.value);
                  setAvatarError('');
                }}
                className="w-full bg-zinc-950 border border-zinc-850 text-zinc-200 text-[11px] rounded-lg p-2 focus:outline-none focus:border-amber-500/40 font-mono"
                placeholder="https://..."
              />

              {uploadedPhotos.length > 0 && (
                <div className="mt-2 space-y-1">
                  <label className="text-[9px] font-mono text-zinc-450 uppercase tracking-wider block font-black">Assign Avatar from Firebase Library</label>
                  <select
                    onChange={(e) => {
                      const url = e.target.value;
                      if (!url) return;
                      setBittyAvatar(url);
                      setAvatarError('');
                      e.target.value = '';
                    }}
                    className="w-full bg-zinc-950 border border-zinc-850 text-zinc-300 rounded px-2.5 py-1.5 focus:outline-none focus:border-amber-500 text-xs font-mono cursor-pointer"
                    defaultValue=""
                  >
                    <option value="" disabled>Select a snapshot...</option>
                    {uploadedPhotos.map(p => (
                      <option key={p.id} value={p.url}>{p.name}</option>
                    ))}
                  </select>
                </div>
              )}
            </div>
            {avatarError && (
              <p className="text-red-400 text-[10px] bg-red-950/20 p-2 rounded border border-red-900/30 font-mono text-center">
                {avatarError}
              </p>
            )}
          </div>

          {/* Right section: Bio edit */}
          <div className="md:col-span-3 space-y-4">
            <div className="space-y-1.5">
              <label className="block text-[11px] font-mono text-zinc-400 uppercase tracking-wider font-black">
                Bitty’s Personal Introduction Narrative (Bio):
              </label>
              <textarea 
                rows={5}
                value={bittyBio}
                onChange={(e) => setBittyBio(e.target.value)}
                placeholder="Customize your biography narrative statement shown under posts on the community board..."
                className="w-full bg-zinc-900 border border-zinc-850 text-zinc-200 text-xs rounded-xl p-4 focus:outline-none focus:border-amber-505 resize-y leading-relaxed"
              />
            </div>

            <div className="flex justify-between items-center pt-2">
              {profileSaved ? (
                <span className="text-xs text-emerald-400 font-mono flex items-center gap-1.5 animate-pulse bg-emerald-950/20 py-1 px-2.5 rounded border border-[#065f46]/40 font-bold">
                  <Check className="w-4 h-4" /> PROFILE METADATA SYNCED SUCCESSFULLY
                </span>
              ) : (
                <span></span>
              )}

              <button
                type="button"
                onClick={handleSaveBittyProfile}
                className="bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-xs py-2.5 px-6 rounded-xl uppercase tracking-wider cursor-pointer shadow-lg shadow-amber-500/5 ml-auto"
              >
                Save Profile Details
              </button>
            </div>
          </div>

        </div>
      </div>

      {/* SEARCH AND FILTERS TOOLBAR */}
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row gap-4 justify-between items-center text-left">
          <h3 className="text-sm font-black text-zinc-400 uppercase font-mono tracking-wider self-start sm:self-center">Intake Submissions Directory</h3>
          
          <div className="flex gap-2 text-[10px] uppercase font-mono text-zinc-400 font-bold flex-wrap">
            {(['all', 'pending', 'approved', 'active', 'completed', 'declined', 'refunded'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setFilterStatus(st)}
                className={`px-2.5 py-1.5 rounded-lg border transition-colors cursor-pointer ${
                  filterStatus === st
                    ? 'bg-amber-500 border-amber-500 text-zinc-950 font-black'
                    : 'bg-zinc-900 border-zinc-800 hover:text-white'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        <div className="relative">
          <input 
            type="text" 
            id="admin-request-search-input"
            name="adminRequestSearch"
            placeholder="Search request database by user name, ID, or topic keyword..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-zinc-900 border border-zinc-850 text-zinc-100 text-xs rounded-xl pl-10 pr-4 py-3 placeholder-zinc-550 focus:outline-none focus:border-amber-500/40"
          />
          <Search className="w-4 h-4 text-zinc-600 absolute left-3.5 top-1/2 -translate-y-1/2" />
        </div>

        {/* Requests Container list */}
        <div className="space-y-6 text-left">
          {filteredRequests && filteredRequests.length > 0 ? (
            filteredRequests.map((req) => {
              const textNoteVal = localNotes[req.id] !== undefined ? localNotes[req.id] : req.adminNotes;
              
              return (
                <div 
                  key={req.id} 
                  className={`bg-zinc-900 border rounded-2xl p-6 space-y-5 transition-all ${
                    req.status === 'pending'
                      ? 'border-amber-500/40 shadow-[0px_0px_12px_rgba(245,158,11,0.03)]'
                      : req.status === 'active'
                      ? 'border-indigo-500/45'
                      : 'border-zinc-850'
                  }`}
                >
                  {/* Top identification info bar */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-850 pb-3">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono text-[10px] text-zinc-500 font-extrabold">{req.id}</span>
                        <span className="font-mono text-zinc-400 font-black uppercase text-[10px] bg-zinc-955 py-0.5 px-2 rounded-md border border-zinc-850">
                          {req.passType === 'text-15' ? '15 Min Pass' : '30 Min Pass'}
                        </span>
                      </div>
                      <h4 className="text-zinc-150 font-extrabold text-base uppercase tracking-tight">
                        {req.isAnonymous ? (
                          <span className="flex items-center gap-1.5 text-amber-450">
                            <span className="w-2 h-2 rounded bg-amber-500 animate-pulse"></span>
                            <span>Anonymous User</span>
                          </span>
                        ) : (
                          req.userName
                        )}
                      </h4>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-[10px] font-mono text-zinc-550">PAYMENT: <strong className="text-zinc-300 font-bold">${req.price}</strong> ({req.paymentId})</span>
                      <span className={`text-[10px] font-mono font-black uppercase px-2 py-0.5 rounded border ${
                        req.status === 'pending'
                          ? 'bg-amber-500/10 border-amber-500/20 text-amber-500 animate-pulse'
                          : req.status === 'active'
                          ? 'bg-indigo-505/10 border-indigo-505/20 text-indigo-400'
                          : req.status === 'completed'
                          ? 'bg-zinc-805 border-zinc-750 text-zinc-455'
                          : 'bg-zinc-955 border-zinc-900 text-zinc-550'
                      }`}>
                        {req.status}
                      </span>

                      {/* DELETE PASS SESSION REQUEST TRIGGER */}
                      {onDeleteRequest && (
                        <button
                          onClick={() => {
                            if (confirm(`Warning: Are you absolutely certain you wish to completely delete and purge conversation request session ${req.id}? This will also clear all corresponding payment receipt logs.`)) {
                              onDeleteRequest(req.id);
                            }
                          }}
                          className="text-zinc-650 hover:text-red-400 p-1.5 rounded-lg hover:bg-red-950/20 hover:border-red-900/30 border border-transparent transition-all outline-none"
                          title="Purge / Delete request session entirely"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Submission Specifics Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs leading-normal">
                    
                    {/* Topic Context Box */}
                    <div className="md:col-span-2 space-y-1.5 p-4 bg-zinc-950 rounded-xl border border-zinc-850">
                      <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider font-extrabold block">Primary Topic focus</span>
                      <p className="text-zinc-200 leading-relaxed italic font-medium break-words">
                        "{req.topic}"
                      </p>
                    </div>

                    {/* Contact or Pre-notes */}
                    <div className="space-y-4">
                      {/* Contact metadata info and agreement */}
                      <div className="space-y-2 p-4 bg-zinc-950 border border-zinc-850 rounded-xl font-sans">
                        <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider font-extrabold block">Client File Info</span>
                        <p className="text-zinc-300">
                          <strong className="text-zinc-500 font-mono uppercase">PHONE:</strong>{' '}
                          {req.isAnonymous ? (
                            <span className="text-zinc-500 select-all italic font-mono text-[10px] bg-zinc-90 w-full px-1.5 py-0.5 rounded">
                              [HIDDEN FOR PRIVACY]
                            </span>
                          ) : (
                            req.userPhone
                          )}
                        </p>
                        <p className="text-zinc-300">
                          <strong className="text-zinc-500 font-mono uppercase">EMAIL:</strong>{' '}
                          {req.isAnonymous ? (
                            <span className="text-zinc-500 select-all italic font-mono text-[10px] bg-zinc-90 w-full px-1.5 py-0.5 rounded">
                              [HIDDEN FOR PRIVACY]
                            </span>
                          ) : (
                            req.userEmail
                          )}
                        </p>
                        <p className="text-zinc-450 text-[10px] flex items-center gap-1">
                          <span className="text-emerald-500 font-extrabold">✓</span> Agreed to Boundaries
                        </p>
                      </div>
                    </div>

                  </div>

                  {/* Pre Notes detail if supplied */}
                  {req.preNotes && (
                    <div className="p-4 bg-zinc-955 rounded-xl border border-zinc-850">
                      <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider font-extrabold block">"Anything Bitty should know" notes:</span>
                      <p className="text-zinc-350 text-xs mt-1 leading-relaxed break-words">
                        {req.preNotes}
                      </p>
                    </div>
                  )}

                  {/* Google Drive supplementary attachments */}
                  {req.attachedDriveFiles && req.attachedDriveFiles.length > 0 && (
                    <div className="p-4 bg-zinc-955 rounded-xl border border-zinc-850 space-y-2">
                      <span className="text-[10px] font-mono text-zinc-550 uppercase tracking-wider font-extrabold block">Attached Google Drive Files ({req.attachedDriveFiles.length}):</span>
                      <div className="flex flex-wrap gap-2">
                        {req.attachedDriveFiles.map((file, idx) => (
                          <a
                            key={file.id || idx}
                            href={file.url || '#'}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="bg-zinc-955 hover:bg-zinc-900 border border-zinc-850 hover:border-amber-500/40 text-xs text-zinc-300 px-3 py-2 rounded-xl flex items-center gap-2 transition-all font-mono"
                          >
                            <svg className="w-3.5 h-3.5 text-amber-500 fill-amber-500/10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                              <ellipse cx="12" cy="5" rx="9" ry="3" />
                              <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
                              <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" />
                            </svg>
                            <span className="font-semibold truncate max-w-[200px]">{file.name}</span>
                            <span className="text-[9px] text-zinc-550">({file.mimeType.split('/').pop()?.toUpperCase()})</span>
                          </a>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* ADMINISTRATIVE UTILITIES: STAGE TRANSITIONS AND NOTES EDITOR */}
                  <div className="pt-4 border-t border-zinc-850 space-y-4">
                    
                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-mono text-zinc-400 uppercase tracking-wider font-extrabold">Bitty’s Active Session & Operational Notes:</label>
                      <textarea 
                        rows={2}
                        value={textNoteVal}
                        onChange={(e) => setLocalNotes({ ...localNotes, [req.id]: e.target.value })}
                        placeholder="Add private therapy reflections, SMS templates, connection status, or notes..."
                        className="w-full bg-zinc-950 border border-zinc-850 text-zinc-200 text-xs rounded-xl p-3 focus:outline-none focus:border-amber-500/40"
                      />
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-4">
                      {/* Transition Action Buttons */}
                      <div className="flex items-center gap-2 flex-wrap">
                        
                        {/* 1. Pending -> Approved / Declined */}
                        {req.status === 'pending' && (
                          <>
                            <button
                              onClick={() => handleSaveNotesAndStatus(req.id, 'approved', req.adminNotes)}
                              className="bg-emerald-500 hover:bg-emerald-400 text-zinc-950 text-[10px] font-black uppercase tracking-wider py-2 px-4 rounded-lg cursor-pointer transition-all"
                            >
                              Approve Topic
                            </button>
                            <button
                              onClick={() => handleSaveNotesAndStatus(req.id, 'declined', req.adminNotes)}
                              className="bg-zinc-850 hover:bg-red-950/40 hover:text-red-400 text-zinc-300 border border-zinc-800 text-[10px] font-black uppercase tracking-wider py-2 px-4 rounded-lg cursor-pointer transition-all"
                            >
                              Decline Topic
                            </button>
                          </>
                        )}

                        {/* 2. Approved -> Active */}
                        {req.status === 'approved' && (
                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => handleSaveNotesAndStatus(req.id, 'active', req.adminNotes)}
                              className="bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] font-black uppercase tracking-wide py-2 px-4 rounded-lg cursor-pointer transition-all"
                            >
                              Mark Active (Ready to Talk)
                            </button>
                          </div>
                        )}

                        {/* 3. Active -> Completed */}
                        {req.status === 'active' && (
                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => handleSaveNotesAndStatus(req.id, 'completed', req.adminNotes)}
                              className="bg-zinc-800 hover:bg-zinc-700 text-zinc-100 text-[10px] font-black uppercase tracking-wide py-2 px-4 rounded-lg cursor-pointer transition-all"
                            >
                              Mark Completed
                            </button>
                          </div>
                        )}

                        {/* Allowed to refund any paid request if canceled */}
                        {(req.status === 'pending' || req.status === 'approved' || req.status === 'active') && (
                          <button
                            onClick={() => handleSaveNotesAndStatus(req.id, 'refunded', req.adminNotes)}
                            className="bg-zinc-950 hover:bg-orange-950/20 hover:text-orange-400 text-zinc-500 text-[9px] font-mono uppercase py-2 px-3 border border-zinc-850 rounded-lg cursor-pointer transition-all"
                          >
                            Refund Transaction
                          </button>
                        )}

                      </div>

                      <button
                        onClick={() => handleSaveNotesAndStatus(req.id, req.status, req.adminNotes)}
                        className="bg-zinc-800 hover:bg-zinc-750 text-zinc-300 text-[10px] font-bold uppercase tracking-wider py-2 px-4 rounded-lg cursor-pointer transition-all"
                      >
                        Keep Logged Notes
                      </button>
                    </div>

                  </div>

                </div>
              );
            })
          ) : (
            <div className="text-center py-12 bg-zinc-900 border border-zinc-850 rounded-2xl text-zinc-550 font-mono text-xs">
              <FileText className="w-8 h-8 text-zinc-700 mx-auto mb-2" />
              <span>No requests matched your query.</span>
            </div>
          )}
        </div>
      </div>

      {rawImageSrc && (
        <ImageCropperModal
          imageSrc={rawImageSrc}
          aspectRatio={croppingAspectRatio}
          onCrop={async (croppedDataUrl) => {
            setRawImageSrc(null);
            const slotIdx = croppingSlotIndex;
            setCroppingSlotIndex(null);
            
            try {
              setIsUploadingToFirebase(true);
              setFirebaseUploadError(null);
              
              let nameHint = 'cropped_photo.jpg';
              if (slotIdx === -1) {
                nameHint = 'bitty_profile.jpg';
              } else if (slotIdx === -2) {
                nameHint = 'library_pool.jpg';
              } else if (slotIdx !== null && slotIdx >= 0) {
                const photo = galleryPhotos[slotIdx];
                nameHint = `${photo.id}.jpg`;
              }
              
              let compressedDataUrl = croppedDataUrl;
              try {
                // Compress admin crop to optimal width 1200px at high-performance rendering (quality 0.75)
                compressedDataUrl = await compressImage(croppedDataUrl, { maxWidth: 1200, maxHeight: 1200, quality: 0.75 });
              } catch (compErr) {
                console.warn("Client-side compression failed inside Admin crop, uploading uncompressed:", compErr);
              }

              // Upload the data URL securely to Google / Firebase Storage bucket
              const storageUrl = await uploadBase64ToFirebaseStorage(compressedDataUrl, nameHint);
              
              if (slotIdx === -1) {
                setBittyAvatar(storageUrl);
                setAvatarError('');
                // Automatically save main profile avatar immediately!
                onUpdateBittyProfile(storageUrl, bittyBio);
                setFirebaseSuccessMessage("Profile Avatar uploaded and saved to DB successfully!");
                setTimeout(() => setFirebaseSuccessMessage(null), 3000);
              } else if (slotIdx === -2) {
                // Add to library list
                const newItem = {
                  id: 'lib_' + Date.now(),
                  name: `Library Snapshot ${uploadedPhotos.length + 1}`,
                  url: storageUrl,
                  uploadedAt: new Date().toLocaleDateString('en-US', {
                    month: 'short',
                    day: 'numeric',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  })
                };
                const updatedLib = [newItem, ...uploadedPhotos];
                setUploadedPhotos(updatedLib);
                
                // Immediately save settings to server as well
                onUpdateSettings({
                  ...globalSettings,
                  uploadedPhotos: updatedLib,
                  galleryPhotos
                });
                
                setFirebaseSuccessMessage("Photo loaded into Firebase Library Pool!");
                setTimeout(() => setFirebaseSuccessMessage(null), 3000);
              } else if (slotIdx !== null && slotIdx >= 0) {
                const next = [...galleryPhotos];
                next[slotIdx].url = storageUrl;
                setGalleryPhotos(next);
                // Automatically save photoboard slot changes immediately!
                onUpdateSettings({
                  ...globalSettings,
                  galleryPhotos: next,
                  uploadedPhotos
                });
                setFirebaseSuccessMessage(`Slot Assigned and saved directly to database!`);
                setTimeout(() => setFirebaseSuccessMessage(null), 3000);
              }
            } catch (err: any) {
              setFirebaseUploadError("Firebase storage upload fail: " + err.message);
            } finally {
              setIsUploadingToFirebase(false);
            }
          }}
          onClose={() => {
            setRawImageSrc(null);
            setCroppingSlotIndex(null);
          }}
        />
      )}

    </div>
  );
}
