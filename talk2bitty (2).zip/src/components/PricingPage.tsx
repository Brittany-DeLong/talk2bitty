import React, { useState } from 'react';
import { MessageSquareOff, HelpCircle, Clock, Zap, CheckCircle2, Mail, Bell, Sparkles, Check, AlertCircle } from 'lucide-react';
import { PassType, GlobalSettings } from '../types';

interface PricingPageProps {
  globalSettings: GlobalSettings;
  onInitiatePurchase: (passType: PassType, price: number) => void;
}

export default function PricingPage({ globalSettings, onInitiatePurchase }: PricingPageProps) {
  const currentStatus = globalSettings.availabilityStatus || (globalSettings.isAvailable ? 'open' : 'closed');
  const isAvailable = currentStatus === 'open';

  // Waitlist form states
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [joinedSuccess, setJoinedSuccess] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');

  const handleJoinWaitlist = async (e: React.FormEvent) => {
    e.preventDefault();
    const emailStr = email.trim();
    if (!emailStr || !emailStr.includes('@')) {
      setError('Please provide a valid email address.');
      return;
    }

    setLoading(true);
    setError('');
    setJoinedSuccess(false);

    try {
      const response = await fetch('/api/waitlist', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email: emailStr }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Unable to join waitlist.');
      }

      setJoinedSuccess(true);
      setSuccessMsg(data.message || 'Successfully joined the waitlist!');
      setEmail('');
    } catch (err: any) {
      setError(err.message || 'Something went wrong. Please check again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-12 py-4">
      
      {/* Short Text Intro */}
      <div className="text-center space-y-4 max-w-2xl mx-auto">
        <h2 className="text-3xl font-extrabold text-zinc-100 uppercase tracking-tight">One-on-One Chat Slots</h2>
        <p className="text-zinc-400 text-sm md:text-base leading-relaxed">
          I don’t offer corporate packages, clinical subscription models, or motivational fluff. You are just booking direct, unfiltered 1-on-1 text-based chat slots when you want a real, down-to-earth conversation. Let’s sit down and talk.
        </p>
      </div>

      {/* Global Status Banner & Custom Forms */}
      {currentStatus === 'open' ? (
        <div className="bg-emerald-950/20 border-2 border-emerald-900/40 p-4 rounded-xl flex items-center gap-3 justify-center sm:justify-start shadow-sm">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
          <span className="text-xs font-mono font-bold text-emerald-400 uppercase tracking-wider">
            Bitty is currently AVAILABLE for direct chats
          </span>
        </div>
      ) : (
        <div id="pricing-unavailable-container" className="space-y-6">
          
          {/* Main banner */}
          <div className="bg-zinc-950 border-2 border-zinc-850 p-6 rounded-2xl flex flex-col md:flex-row items-stretch md:items-center gap-6 shadow-xl">
            
            {/* Status icon side */}
            <div className="flex items-center gap-4 flex-1">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${
                currentStatus === 'waitlist' 
                  ? 'bg-amber-950/45 text-amber-500 border border-amber-905/30' 
                  : 'bg-zinc-900 text-zinc-400 border border-zinc-800'
              }`}>
                {currentStatus === 'waitlist' ? (
                  <Bell className="w-6 h-6 animate-swing" />
                ) : (
                  <MessageSquareOff className="w-6 h-6" />
                )}
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${currentStatus === 'waitlist' ? 'bg-amber-500' : 'bg-red-500'}`}></span>
                  <h4 className={`text-xs font-black font-mono uppercase tracking-widest ${
                    currentStatus === 'waitlist' ? 'text-amber-400' : 'text-zinc-400'
                  }`}>
                    {currentStatus === 'waitlist' ? 'Availability Status: Waitlist Active' : 'Availability Status: Paused'}
                  </h4>
                </div>
                <p className="text-zinc-300 text-xs sm:text-sm leading-relaxed max-w-xl font-medium">
                  {currentStatus === 'waitlist' 
                    ? (globalSettings.waitlistMessage || 'Bitty is currently full and taking waitlist entries. Leave your email below to be notified as soon as slots open!')
                    : (globalSettings.unavailableMessage || 'Bitty is offline for family, exam schedule, or cockatoo management. Sign up below to get a heads-up the second she is back!')
                  }
                </p>
              </div>
            </div>

            {/* Email form inline */}
            <div className="border-t md:border-t-0 md:border-l border-zinc-900 pt-5 md:pt-0 md:pl-6 w-full md:max-w-sm shrink-0">
              <form onSubmit={handleJoinWaitlist} className="space-y-2.5">
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-mono tracking-wider font-black text-zinc-550 block">
                    Get Notified Instantly
                  </label>
                  <p className="text-[10px] text-zinc-500 leading-normal">
                    Enter your email. I will alert you the moment custom live slots open up.
                  </p>
                </div>

                <div className="flex gap-2">
                  <input
                    type="email"
                    required
                    id="pricing-waitlist-email"
                    name="waitlistEmail"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="flex-1 bg-zinc-900 border border-zinc-800 text-zinc-150 text-xs rounded-xl px-3 py-2.5 focus:outline-none focus:border-amber-500/40"
                    disabled={loading || joinedSuccess}
                  />
                  <button
                    type="submit"
                    disabled={loading || joinedSuccess}
                    className={`px-4 bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-black uppercase font-mono tracking-wider rounded-xl transition-all cursor-pointer flex items-center justify-center ${
                      (loading || joinedSuccess) ? 'opacity-50 cursor-not-allowed' : ''
                    }`}
                  >
                    {loading ? '...' : joinedSuccess ? 'Joined' : 'Notify'}
                  </button>
                </div>

                {error && (
                  <p className="text-red-400 text-[10px] font-mono leading-normal flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {error}
                  </p>
                )}

                {joinedSuccess && (
                  <p className="text-emerald-400 text-[10px] font-mono leading-normal flex items-start gap-1">
                    <Check className="w-3 h-3 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{successMsg}</span>
                  </p>
                )}
              </form>
            </div>

          </div>

        </div>
      )}

      {/* Grid of Pass Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        
        {/* Pass 1: 15 Min Text Pass */}
        <div className="bg-zinc-900 border border-zinc-800 p-8 rounded-2xl flex flex-col justify-between relative overflow-hidden group">
          <div className="space-y-6">
            <div className="flex justify-between items-start">
              <span className="text-xs font-mono text-amber-400 uppercase font-black bg-zinc-800 px-2 rounded tracking-wider">15 Minutes</span>
              <Clock className="w-5 h-5 text-zinc-500 group-hover:text-amber-400 transition-colors" />
            </div>
            
            <div className="space-y-2">
              <h3 className="text-2xl font-extrabold text-zinc-100 uppercase tracking-tight">Quick Check-In Chat</h3>
              <p className="text-zinc-400 text-xs leading-relaxed">
                Best for direct questions, a quick sanity check, or getting my unfiltered feedback on a single choice or issue.
              </p>
            </div>

            <div className="pt-2">
              <span className="text-4xl font-black text-zinc-100 tracking-tight">$15</span>
              <span className="text-zinc-500 text-xs ml-1 font-mono">/ single chat session</span>
            </div>

            <div className="h-px bg-zinc-800"></div>

            <ul className="space-y-2.5 text-xs text-zinc-350">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0" />
                <span>Focused text dialogue with Bitty</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0" />
                <span>Submit your situation beforehand</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0" />
                <span>No textbook answers or filters</span>
              </li>
            </ul>
          </div>

          <div className="pt-8">
            <button
              onClick={() => onInitiatePurchase('text-15', 15)}
              disabled={!isAvailable}
              className={`w-full py-3 px-4 rounded-xl text-xs font-black uppercase tracking-wider transition-all ${
                isAvailable
                  ? 'bg-amber-500 hover:bg-amber-400 text-zinc-950 hover:shadow-lg hover:shadow-amber-500/10 cursor-pointer'
                  : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
              }`}
            >
              {isAvailable ? 'Book 15-Minute Chat' : currentStatus === 'waitlist' ? 'Running on Waitlist' : 'Temporarily Unavailable'}
            </button>
          </div>
        </div>

        {/* Pass 2: 30 Min Text Pass (Most Popular) */}
        <div className="bg-zinc-900 border-2 border-amber-500/60 p-8 rounded-2xl flex flex-col justify-between relative overflow-hidden group">
          <div className="absolute top-0 right-0 bg-amber-500/20 text-amber-300 text-[10px] font-mono font-black py-1 px-4 rounded-bl-xl uppercase tracking-wider">
            Most Popular
          </div>
          
          <div className="space-y-6">
            <div className="flex justify-between items-start">
              <span className="text-xs font-mono text-amber-400 uppercase font-black bg-zinc-800 px-2 rounded tracking-wider">30 Minutes</span>
              <Zap className="w-5 h-5 text-amber-500" />
            </div>
            
            <div className="space-y-2">
              <h3 className="text-2xl font-extrabold text-zinc-100 uppercase tracking-tight">Real-Talk Deep Dive</h3>
              <p className="text-zinc-400 text-xs leading-relaxed">
                Great for unloading heavy stuff: toxic relationships, work drama, co-parenting gridlock, or life shifts.
              </p>
            </div>

            <div className="pt-2">
              <span className="text-4xl font-black text-zinc-100 tracking-tight">$25</span>
              <span className="text-zinc-500 text-xs ml-1 font-mono">/ single chat session</span>
            </div>

            <div className="h-px bg-zinc-800"></div>

            <ul className="space-y-2.5 text-xs text-zinc-350">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0" />
                <span>Deep direct-text discussion of your story</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0" />
                <span>Raw, honest reflections with zero fluff</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0" />
                <span>Real-world perspective born of heavy experience</span>
              </li>
            </ul>
          </div>

          <div className="pt-8">
            <button
              onClick={() => onInitiatePurchase('text-30', 25)}
              disabled={!isAvailable}
              className={`w-full py-3 px-4 rounded-xl text-xs font-black uppercase tracking-wider transition-all ${
                isAvailable
                  ? 'bg-amber-500 hover:bg-amber-400 text-zinc-950 hover:shadow-lg hover:shadow-amber-500/10 cursor-pointer'
                  : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
              }`}
            >
              {isAvailable ? 'Book 30-Minute Chat' : currentStatus === 'waitlist' ? 'Running on Waitlist' : 'Temporarily Unavailable'}
            </button>
          </div>
        </div>

        {/* Pass 3: 60 Min Text Pass (Coming Soon) */}
        <div className="bg-zinc-950 border border-zinc-850 p-8 rounded-2xl flex flex-col justify-between relative overflow-hidden opacity-60">
          <div className="space-y-6">
            <div className="flex justify-between items-start">
              <span className="text-xs font-mono text-zinc-500 uppercase font-bold bg-zinc-900 px-2 rounded tracking-wider">60 Minutes</span>
              <HelpCircle className="w-5 h-5 text-zinc-650" />
            </div>
            
            <div className="space-y-2">
              <h3 className="text-2xl font-extrabold text-zinc-500 uppercase tracking-tight">Full Sit-Down Chat</h3>
              <p className="text-zinc-650 text-xs leading-relaxed">
                Coming soon. A complete one-hour deep reflection, reserved for highly complex situation maps, grief, or heavy loss.
              </p>
            </div>

            <div className="pt-2">
              <span className="text-4xl font-bold text-zinc-650 tracking-tight">Coming Soon</span>
            </div>

            <div className="h-px bg-zinc-900"></div>

            <ul className="space-y-2.5 text-xs text-zinc-600">
              <li className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-full border border-zinc-705 shrink-0"></div>
                <span>Extended intensive 1-on-1 text review</span>
              </li>
              <li className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-full border border-zinc-705 shrink-0"></div>
                <span>Includes a direct follow-up check-in</span>
              </li>
            </ul>
          </div>

          <div className="pt-8 w-full">
            <button
              disabled
              className="w-full py-3 px-4 rounded-xl text-xs font-bold bg-zinc-900 text-zinc-600 border border-zinc-850 cursor-not-allowed uppercase"
            >
              Unavailable for V1
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
