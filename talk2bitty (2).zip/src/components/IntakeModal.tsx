import React, { useState } from 'react';
import { X, Send, CreditCard, Shield, Lock, AlertTriangle, Check, Upload, Paperclip, Trash2 } from 'lucide-react';
import { PassType, UserProfile } from '../types';
import { stripeCheckoutService } from '../services/stripeCheckout';
import DriveBrowser from './DriveBrowser';
import { DriveFile, uploadBase64ToFirebaseStorage } from '../services/googleAuth';
import { compressImage } from '../services/imageCompressor';

interface IntakeModalProps {
  passType: PassType;
  price: number;
  userId: string;
  currentUser: UserProfile;
  stripePublishableKey: string | null;
  onClose: () => void;
  onSubmitRequest: (formData: {
    userName: string;
    userEmail: string;
    userPhone: string;
    topic: string;
    preNotes: string;
    agreedToBoundaries: boolean;
    paymentId: string;
    isAnonymous: boolean;
    attachedDriveFiles?: Array<{ id: string; name: string; mimeType: string; url?: string }>;
  }) => void;
  enableDrivePortal?: boolean;
}

export default function IntakeModal({ passType, price, userId, currentUser, stripePublishableKey, onClose, onSubmitRequest, enableDrivePortal = false }: IntakeModalProps) {
  const [step, setStep] = useState<'intake' | 'stripe'>('intake');
  
  // Intake State
  const [userName, setUserName] = useState(currentUser?.name || '');
  const [userEmail, setUserEmail] = useState(currentUser?.email || '');
  const [userPhone, setUserPhone] = useState(currentUser?.phone || '');
  const [topic, setTopic] = useState('');
  const [preNotes, setPreNotes] = useState('');
  const [agreed, setAgreed] = useState(false);
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [attachedFiles, setAttachedFiles] = useState<DriveFile[]>([]);

  // Local File Upload States
  const [localUploadedFiles, setLocalUploadedFiles] = useState<Array<{ id: string, name: string, mimeType: string, url: string }>>([]);
  const [isUploadingLocalFile, setIsUploadingLocalFile] = useState(false);
  const [localUploadErr, setLocalUploadErr] = useState('');
  const [isDragging, setIsDragging] = useState(false);

  const uploadAndProcessFile = async (file: File) => {
    if (file.size > 5 * 1024 * 1024) {
      setLocalUploadErr("File too large (Max 5MB).");
      return;
    }

    setIsUploadingLocalFile(true);
    setLocalUploadErr('');

    try {
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve, reject) => {
        reader.onloadend = () => resolve(reader.result as string);
        reader.onerror = () => reject(new Error("Failed to read device file string."));
      });
      reader.readAsDataURL(file);
      let base64Url = await base64Promise;

      const isImage = file.type?.startsWith('image/');
      let mimeType = file.type || 'application/octet-stream';
      let finalName = file.name || 'uploaded_intake_file';

      if (isImage) {
        try {
          // Compress the image before uploading (max dimensions 1200x1200, 75% quality)
          base64Url = await compressImage(base64Url, { maxWidth: 1200, maxHeight: 1200, quality: 0.75 });
          if (file.type === 'image/png') {
            mimeType = 'image/jpeg'; // png gets converted to jpeg for dramatic bandwidth savings
            finalName = finalName.replace(/\.png$/i, '.jpg');
          }
        } catch (compressErr) {
          console.warn("Client-side image compression failed, using original file instead:", compressErr);
        }
      }

      const storageUrl = await uploadBase64ToFirebaseStorage(base64Url, finalName);

      setLocalUploadedFiles(prev => [
        ...prev,
        {
          id: `local_${Date.now()}_` + Math.random().toString(36).substring(2, 7),
          name: finalName,
          mimeType: mimeType,
          url: storageUrl
        }
      ]);
    } catch (err: any) {
      console.error(err);
      setLocalUploadErr(err.message || "Failed to upload file from device.");
    } finally {
      setIsUploadingLocalFile(false);
    }
  };

  const handleLocalFileSelection = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      await uploadAndProcessFile(file);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const file = e.dataTransfer.files?.[0];
    if (file) {
      await uploadAndProcessFile(file);
    }
  };

  const handleRemoveLocalFile = (idToRem: string) => {
    setLocalUploadedFiles(prev => prev.filter(f => f.id !== idToRem));
  };

  // Stripe State
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvc, setCardCvc] = useState('');
  const [cardZip, setCardZip] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [paymentError, setPaymentError] = useState('');

  const handleNextToPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName.trim() || !userEmail.trim() || !topic.trim()) {
      setErrorMsg('Please populate all required fields.');
      return;
    }
    if (!agreed) {
      setErrorMsg('You must check and agree to our boundary disclaimer first.');
      return;
    }
    setErrorMsg('');

    // If Stripe is active, redirect directly to secure Stripe Checkout!
    if (stripePublishableKey) {
      setIsProcessing(true);
      setErrorMsg('');
      try {
        const response = await fetch('/api/create-checkout-session', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId,
            userName,
            userEmail,
            userPhone,
            topic,
            preNotes,
            agreedToBoundaries: agreed,
            isAnonymous,
            passType,
            price
          })
        });
        const data = await response.json();
        if (data.url) {
          // Redirect the browser window to Stripe Checkout securely
          window.location.href = data.url;
        } else {
          throw new Error(data.error || "Could not retrieve Stripe checkout session url.");
        }
      } catch (err: any) {
        console.warn("Stripe Checkout Session setup failed, falling back to simulated sandbox checkout:", err);
        setErrorMsg(`Stripe Redirect failed (${err.message || "Network Error"}). Falling back to simulation mode.`);
        setStep('stripe');
      } finally {
        setIsProcessing(false);
      }
    } else {
      // Go to simulated card fields sandbox checkout step
      setStep('stripe');
    }
  };

  const handleSimulatePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setPaymentError('');
    
    try {
      const response = await stripeCheckoutService.processCheckout(
        { cardNumber, cardExpiry, cardCvc, cardZip },
        price,
        passType
      );
      
      setPaymentSuccess(true);
      
      // Complete transaction and create request
      setTimeout(() => {
        onSubmitRequest({
          userName,
          userEmail,
          userPhone,
          topic,
          preNotes,
          agreedToBoundaries: agreed,
          isAnonymous,
          paymentId: response.paymentId,
          attachedDriveFiles: [
            ...attachedFiles.map(f => ({
              id: f.id,
              name: f.name,
              mimeType: f.mimeType,
              url: f.webViewLink || ''
            })),
            ...localUploadedFiles
          ]
        });
      }, 1500);
      
    } catch (err: any) {
      setPaymentError(err.message || 'An unexpected error occurred during checkout.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      
      {/* Container Box */}
      <div 
        id="intake-stripe-modal"
        className="bg-zinc-900 border border-zinc-800 rounded-2xl w-full max-w-4xl overflow-hidden shadow-2xl relative flex flex-col md:flex-row max-h-[92vh]"
      >
        
        {/* Absolute Close */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-zinc-500 hover:text-zinc-300 pointer-events-auto cursor-pointer z-20"
        >
          <X className="w-5 h-5" />
        </button>

        {step === 'intake' ? (
          /* ================= STEP 1: INTAKE INFORMATION ================= */
          <div className="w-full p-6 md:p-8 space-y-6 overflow-y-auto max-h-[90vh]">
            <div className="space-y-1">
              <span className="text-xs font-mono text-amber-400 uppercase tracking-widest font-black">Step 1 of 2</span>
              <h3 className="text-2xl font-black text-zinc-100 uppercase tracking-tight">Tell me what's going on</h3>
              <p className="text-zinc-450 text-xs text-zinc-400">
                Give me a quick breakdown of what's happening. This helps me get up to speed before we start talking, so we don't waste any of your time.
              </p>
            </div>

            {/* Bitty reassurance & philosophy box */}
            <div className="bg-zinc-950 border border-zinc-850 p-4.5 rounded-xl space-y-2 leading-relaxed text-zinc-300">
              <span className="text-[10px] uppercase font-mono font-black text-amber-500 tracking-wider">A Personal Note from Bitty</span>
              <p className="text-xs italic font-serif">
                "I'm not doing the therapy thing or the therapy talk. I'm just there to listen. I know there's a lot of people out there who just don't have anybody to confide in or talk about things with. You can just vent, or talk about something important to you, or ask me for advice. Or just bullshit with me. If that's what makes you happy, I don't care."
              </p>
            </div>

            {errorMsg && (
              <div className="bg-red-950/40 border border-red-900 text-red-400 p-3 rounded-lg text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

             <form onSubmit={handleNextToPayment} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5Col">
                  <label className="block text-zinc-400 font-mono text-[11px] uppercase tracking-wider">Your Name <strong className="text-red-500">*</strong></label>
                  <input 
                    type="text" 
                    required 
                    id="intake-user-name"
                    name="userName"
                    placeholder="e.g. Jane Doe"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 text-zinc-100 text-xs rounded-xl px-3.5 py-3 focus:outline-none focus:border-amber-500/50"
                  />
                </div>

                <div>
                  <label className="block text-zinc-400 font-mono text-[11px] uppercase tracking-wider">Your Email <strong className="text-red-500">*</strong></label>
                  <input 
                    type="email" 
                    required 
                    id="intake-user-email"
                    name="userEmail"
                    placeholder="e.g. jane@example.com"
                    value={userEmail}
                    onChange={(e) => setUserEmail(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 text-zinc-100 text-xs rounded-xl px-3.5 py-3 focus:outline-none focus:border-amber-500/50"
                  />
                </div>

                <div>
                  <label className="block text-zinc-400 font-mono text-[11px] uppercase tracking-wider">Phone number <span className="text-zinc-650 font-normal">(Optional)</span></label>
                  <input 
                    type="tel" 
                    id="intake-user-phone"
                    name="userPhone"
                    placeholder="e.g. 555-0198"
                    value={userPhone}
                    onChange={(e) => setUserPhone(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 text-zinc-100 text-xs rounded-xl px-3.5 py-3 focus:outline-none focus:border-amber-500/50"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-zinc-400 font-mono text-[11px] uppercase tracking-wider">What would you like to talk about today? <strong className="text-red-500">*</strong></label>
                <textarea 
                  required 
                  rows={4}
                  id="intake-user-topic"
                  name="topicDescription"
                  placeholder="e.g. My spouse and I have constant miscommunications about schedules, turning every weekend into a battleground..."
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 text-zinc-100 text-xs rounded-xl p-3.5 focus:outline-none focus:border-amber-500/50 resize-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-zinc-400 font-mono text-[11px] uppercase tracking-wider">Anything important I should know before responding? (Optional)</label>
                <textarea 
                  rows={2}
                  placeholder="e.g. We have joint custody, and my ex-partner suffers from very defensive habits when confronted."
                  value={preNotes}
                  onChange={(e) => setPreNotes(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 text-zinc-100 text-xs rounded-xl p-3.5 focus:outline-none focus:border-amber-500/50 resize-none"
                />
              </div>

              {/* DIRECT DEVICE FILE UPLOADER */}
              <div className="space-y-3.5 border-t border-zinc-850 pt-4 mt-4 text-left">
                <label className="block text-zinc-350 font-mono text-[11px] uppercase tracking-wider flex items-center gap-1.5 select-none">
                  <Paperclip className="w-3.5 h-3.5 text-amber-500" />
                  <span>Attach Photos or Documents from device (Optional)</span>
                </label>
                <p className="text-[10px] text-zinc-500 leading-relaxed max-w-2xl font-mono">
                  Directly upload case files, screen captures, or notes from your device to Bitty's secure sandbox (Max 5MB).
                </p>

                <div className="flex flex-col gap-3">
                  {/* DRAG AND DROP ZONE */}
                  <div 
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onDrop={handleDrop}
                    className={`border border-dashed rounded-xl p-5 text-center transition-all duration-200 select-none cursor-pointer flex flex-col items-center justify-center gap-2.5 min-h-[110px] ${
                      isDragging 
                        ? 'border-amber-400 bg-amber-500/5 text-amber-400 scale-[0.99] shadow-inner' 
                        : 'border-zinc-800 hover:border-zinc-700 bg-zinc-950/40 text-zinc-400 hover:text-zinc-300'
                    }`}
                  >
                    <label className="w-full h-full flex flex-col items-center justify-center cursor-pointer gap-2 py-1">
                      <Upload className={`w-6 h-6 transition-transform duration-200 ${isDragging ? 'text-amber-400 scale-110' : 'text-zinc-500'}`} />
                      <div className="font-mono text-xs">
                        {isUploadingLocalFile ? (
                          <span className="flex items-center gap-2 text-amber-500 font-bold animate-pulse">
                            <span className="w-3.5 h-3.5 border-2 border-amber-500 border-t-transparent rounded-full animate-spin"></span>
                            Uploading case asset...
                          </span>
                        ) : isDragging ? (
                          <span className="text-amber-400 font-bold">Release to drop file here</span>
                        ) : (
                          <span>
                            Drag & drop or <span className="text-amber-500 hover:text-amber-400 underline decoration-dashed underline-offset-4 font-bold">choose file</span> from device
                          </span>
                        )}
                      </div>
                      <p className="text-[9.5px] text-zinc-550 font-mono">
                        PNG, JPG, PDF, TXT (Max 5MB)
                      </p>
                      <input 
                        type="file" 
                        id="intake-local-file-picker"
                        name="intakeLocalFile"
                        accept="image/*,application/pdf,text/plain"
                        onChange={handleLocalFileSelection}
                        disabled={isUploadingLocalFile}
                        className="hidden" 
                      />
                    </label>
                  </div>

                  {localUploadErr && (
                    <p className="text-[10.5px] font-mono text-red-400 font-bold bg-red-500/5 px-2.5 py-1.5 rounded-lg border border-red-500/10">
                      {localUploadErr}
                    </p>
                  )}

                  {localUploadedFiles.length > 0 && (
                    <div className="flex flex-wrap gap-2 pt-1 font-mono animate-fade-in">
                      {localUploadedFiles.map((file) => {
                        const isImage = file.mimeType.startsWith('image/');
                        return (
                          <div 
                            key={file.id}
                            className="bg-zinc-900 border border-zinc-850 text-[11px] text-zinc-300 pr-2.5 pl-2 py-1.5 rounded-xl flex items-center gap-2.5 group hover:border-zinc-800 transition-all select-none"
                          >
                            {isImage && (
                              <div className="w-8 h-8 rounded border border-zinc-800 overflow-hidden bg-zinc-950 shrink-0">
                                <img 
                                  src={file.url} 
                                  alt={file.name} 
                                  referrerPolicy="no-referrer"
                                  className="w-full h-full object-cover"
                                />
                              </div>
                            )}
                            <div className="flex flex-col min-w-0">
                              <span className="truncate max-w-[180px] font-medium text-zinc-350">{file.name}</span>
                              <span className="text-[8px] text-zinc-500 uppercase">({file.mimeType.split('/').pop()})</span>
                            </div>
                            <button
                              type="button"
                              onClick={() => handleRemoveLocalFile(file.id)}
                              className="text-zinc-500 hover:text-red-400 p-0.5 rounded transition-all cursor-pointer shrink-0"
                              title="Remove attachment"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>

              {/* GOOGLE DRIVE ATTACHMENTS FOR CONVERSATION INTAKE */}
              {enableDrivePortal && (
                <div className="space-y-2 border-t border-zinc-850 pt-4 mt-4">
                  <DriveBrowser 
                    isSelectionMode={true} 
                    selectedFiles={attachedFiles} 
                    onSelectFiles={setAttachedFiles} 
                  />
                </div>
              )}

              {/* ANONYMOUS OPTION TOGTLE */}
              <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-xl flex items-start gap-3">
                <input 
                  type="checkbox" 
                  id="anonymous-passage-chk"
                  name="anonymousPassage"
                  checked={isAnonymous}
                  onChange={(e) => setIsAnonymous(e.target.checked)}
                  className="w-4 h-4 text-amber-500 border-zinc-700 bg-zinc-900 rounded focus:ring-0 cursor-pointer accent-amber-500 mt-1"
                />
                <label htmlFor="anonymous-passage-chk" className="text-xs text-zinc-300 leading-normal select-none cursor-pointer">
                  <span className="font-bold text-amber-400 uppercase tracking-wide text-[11px] block mb-0.5">Remain completely anonymous to Bitty</span>
                  <span className="text-zinc-500 text-[10px] leading-relaxed block">
                    If selected, Bitty won’t see your display name, e-mail, or phone number in her operator panel. Your identity stays completely confidential to protect your private circle, letting you vent or bullshit freely.
                  </span>
                </label>
              </div>

              {/* BOUNDARY DISCLAIMER CHECKBOX */}
              <div className="bg-zinc-950 border border-zinc-850 p-4 rounded-xl flex items-start gap-3">
                <input 
                  type="checkbox" 
                  id="boundary-agreed-chk"
                  checked={agreed}
                  onChange={(e) => setAgreed(e.target.checked)}
                  className="w-4 h-4 text-amber-500 border-zinc-700 bg-zinc-900 rounded focus:ring-0 cursor-pointer accent-amber-500 mt-0.5"
                />
                <label htmlFor="boundary-agreed-chk" className="text-[11px] md:text-xs text-zinc-400 leading-normal select-none cursor-pointer">
                  I understand that Talk2Bitty is private peer conversation—not clinical therapy, medical advice, legal counsel, or emergency crisis support. I'm ready to connect for a real, honest human dialogue.
                </label>
              </div>

              <div className="pt-4 border-t border-zinc-850 flex justify-end gap-3">
                <button 
                  type="button"
                  onClick={onClose}
                  className="bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs py-3 px-6 rounded-xl cursor-pointer font-bold uppercase"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs py-3 px-6 rounded-xl font-black uppercase tracking-wider shadow-lg shadow-amber-500/10 cursor-pointer flex items-center gap-1.5"
                >
                  <span>Proceed to Payment</span>
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </form>
          </div>
        ) : (
          /* ================= STEP 2: SIMULATED STRIPE CHECKOUT ================= */
          <div className="w-full flex flex-col md:flex-row divide-y md:divide-y-0 md:divide-x divide-zinc-800">
            
            {/* Left Col: Order Summary */}
            <div className="w-full md:w-5/12 bg-zinc-950 p-6 md:p-8 flex flex-col justify-between">
              <div className="space-y-6">
                {/* Stripe Simulated Brand */}
                <div className="flex items-center gap-2.5">
                  <div className="w-6 h-6 bg-indigo-600 rounded flex items-center justify-center text-white font-extrabold text-[11px] font-sans">S</div>
                  <span className="text-zinc-400 text-[10px] uppercase font-mono tracking-widest font-black">Stripe Sandbox Checkout</span>
                </div>

                <div className="space-y-2">
                  <span className="text-xs text-zinc-500 uppercase font-mono">Talk2Bitty Order</span>
                  <h4 className="text-2xl font-black text-zinc-200 uppercase tracking-tight font-sans">
                    {passType === 'text-15' ? 'Quick Check-In Chat' : 'Real-Talk Deep Dive'}
                  </h4>
                  <p className="text-xs text-zinc-500 font-mono">
                    {passType === 'text-15' ? '15 Minute 1-on-1 Chat Slot' : '30 Minute 1-on-1 Chat Slot'}
                  </p>
                </div>

                <div className="pt-4 flex items-baseline">
                  <span className="text-5xl font-black text-zinc-100 tracking-tight">${price}</span>
                  <span className="text-zinc-500 font-mono text-xs ml-1 uppercase">USD</span>
                </div>
              </div>

              <div className="pt-8 space-y-3 border-t border-zinc-900 text-[10px] text-zinc-500 leading-normal">
                <div className="flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5 text-zinc-600" />
                  <span>Your details are completely private</span>
                </div>
                <p>
                  You will only be billed once Bitty reviews your details and officially approves your chat request. Decided against it? Refunds are instant.
                </p>
              </div>
            </div>

            {/* Right Col: Pay Form */}
            <div className="w-full md:w-7/12 p-6 md:p-8 space-y-6 overflow-y-auto max-h-[88vh]">
              <div className="flex justify-between items-center pb-2 border-b border-zinc-800">
                <div className="space-y-0.5">
                  <span className="text-xs font-mono text-amber-500 uppercase tracking-widest font-black">Step 2 of 2</span>
                  <h4 className="text-sm font-bold text-zinc-200 uppercase tracking-wide">Secure Credit Card Details</h4>
                </div>
                <div className="flex items-center gap-1 text-[10px] text-emerald-400 font-mono uppercase bg-emerald-500/10 px-2 py-0.5 border border-emerald-900/30 rounded">
                  <Lock className="w-3 h-3" />
                  <span>Test mode</span>
                </div>
              </div>

              {paymentSuccess ? (
                /* Success overlay */
                <div id="payment-success-overlay" className="py-12 flex flex-col items-center justify-center text-center space-y-4 animate-fadeIn">
                  <div className="w-16 h-16 bg-emerald-500 text-zinc-950 rounded-full flex items-center justify-center font-bold shadow-lg shadow-emerald-500/10 animate-bounce">
                    <Check className="w-8 h-8 stroke-[3]" />
                  </div>
                  <div className="space-y-1">
                    <h5 className="text-lg font-bold text-emerald-400 uppercase tracking-tight">Booking Approved!</h5>
                    <p className="text-zinc-300 text-xs max-w-sm mx-auto font-medium">
                      Transaction verified. Setting up your chat dialogue...
                    </p>
                    <p className="text-zinc-500 text-[11px] max-w-xs mx-auto animate-pulse">
                      Redirecting to your member station to hook up WhatsApp...
                    </p>
                  </div>
                </div>
              ) : (
                /* Card payment input fields */
                <form onSubmit={handleSimulatePayment} className="space-y-5">
                  
                  {paymentError && (
                    <div className="bg-red-950/40 border border-red-900 text-red-400 p-3.5 rounded-xl text-xs flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 shrink-0 text-red-500" />
                      <span className="font-mono text-[11px] leading-relaxed uppercase font-black">{paymentError}</span>
                    </div>
                  )}

                  <div className="bg-zinc-950 p-3.5 border border-zinc-850 rounded-xl text-zinc-400 text-xs space-y-1 text-center">
                    <p className="font-bold text-zinc-200">💳 Simulated Card Number</p>
                    <p>Enter card as <code className="font-mono text-amber-400">4242 4242 4242 4242</code> with any MM/YY, CVC, and ZIP to test successfully.</p>
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-zinc-400 font-mono text-[11px] uppercase tracking-wider">Card Number</label>
                    <div className="relative">
                      <input 
                        type="text" 
                        required 
                        id="payment-card-number"
                        name="cardNumber"
                        maxLength={19}
                        placeholder="4242 4242 4242 4242"
                        value={cardNumber}
                        onChange={(e) => {
                          // Format with spaces
                          const v = e.target.value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
                          const matches = v.match(/\d{4,16}/g);
                          const match = matches && matches[0] || '';
                          const parts = [];
                          for (let i=0, len=match.length; i<len; i+=4) {
                            parts.push(match.substring(i, i+4));
                          }
                          if (parts.length > 0) {
                            setCardNumber(parts.join(' '));
                          } else {
                            setCardNumber(v);
                          }
                        }}
                        className="w-full bg-zinc-950 border border-zinc-800 text-zinc-100 text-xs rounded-xl pl-10 pr-3.5 py-3 focus:outline-none focus:border-amber-500/50 font-mono"
                      />
                      <CreditCard className="w-4 h-4 text-zinc-650 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="col-span-2 space-y-1.5">
                      <label className="block text-zinc-400 font-mono text-[11px] uppercase tracking-wider">Expiration Date</label>
                      <input 
                        type="text" 
                        required 
                        id="payment-card-expiry"
                        name="cardExpiry"
                        maxLength={5}
                        placeholder="MM/YY"
                        value={cardExpiry}
                        onChange={(e) => {
                          const v = e.target.value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
                          if (v.length >= 2) {
                            setCardExpiry(v.substring(0, 2) + '/' + v.substring(2, 4));
                          } else {
                            setCardExpiry(v);
                          }
                        }}
                        className="w-full bg-zinc-950 border border-zinc-800 text-zinc-100 text-xs rounded-xl px-3.5 py-3 focus:outline-none focus:border-amber-500/50 font-mono"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-zinc-400 font-mono text-[11px] uppercase tracking-wider">CVC</label>
                      <input 
                        type="text" 
                        required 
                        id="payment-card-cvc"
                        name="cardCvc"
                        maxLength={3}
                        placeholder="123"
                        value={cardCvc}
                        onChange={(e) => setCardCvc(e.target.value.replace(/[^0-9]/g, ''))}
                        className="w-full bg-zinc-950 border border-zinc-800 text-zinc-100 text-xs rounded-xl px-3.5 py-3 focus:outline-none focus:border-amber-500/50 font-mono"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-zinc-400 font-mono text-[11px] uppercase tracking-wider">ZIP / Postal Code</label>
                    <input 
                      type="text" 
                      required 
                      id="payment-card-zip"
                      name="cardZip"
                      placeholder="90210"
                      value={cardZip}
                      onChange={(e) => setCardZip(e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-800 text-zinc-100 text-xs rounded-xl px-3.5 py-3 focus:outline-none focus:border-amber-500/50 font-mono"
                    />
                  </div>

                  <div className="pt-4 border-t border-zinc-850 flex justify-between gap-3 items-center">
                    <button 
                      type="button"
                      onClick={() => setStep('intake')}
                      className="text-zinc-400 hover:text-zinc-200 text-xs font-bold uppercase underline underline-offset-4 cursor-pointer"
                    >
                      ← Back to Form
                    </button>
                    <button 
                      type="submit"
                      disabled={isProcessing}
                      className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs py-3.5 px-6 rounded-xl font-bold uppercase tracking-wider shadow-lg shadow-indigo-600/15 cursor-pointer flex items-center justify-center gap-1.5 min-w-[140px]"
                    >
                      {isProcessing ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                          <span>Paying...</span>
                        </>
                      ) : (
                        <span>Pay ${price}.00</span>
                      )}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
