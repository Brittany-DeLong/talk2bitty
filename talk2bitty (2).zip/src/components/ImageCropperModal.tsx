import React, { useState, useCallback } from 'react';
import Cropper from 'react-easy-crop';
import 'react-easy-crop/react-easy-crop.css';
import { X, ZoomIn, ZoomOut, RotateCw, Check, AlertTriangle, Grid } from 'lucide-react';

interface ImageCropperModalProps {
  imageSrc: string; // Base64 or URL
  onCrop: (croppedDataUrl: string) => void;
  onClose: () => void;
  aspectRatio?: number; // width / height, defaults to 1 (square)
}

interface Area {
  x: number;
  y: number;
  width: number;
  height: number;
}

// Utility to load image on canvas
const createImage = (url: string): Promise<HTMLImageElement> =>
  new Promise((resolve, reject) => {
    const image = new Image();
    image.addEventListener('load', () => resolve(image));
    image.addEventListener('error', (error) => {
      console.error("Failed to load image in ImageCropperModal:", error);
      reject(error);
    });
    // Only set crossOrigin if the source is a remote URL to prevent failures on data URLs
    if (url && (url.startsWith('http://') || url.startsWith('https://'))) {
      image.setAttribute('crossOrigin', 'anonymous'); // Avoid CORS issues
    }
    image.src = url;
  });

// Calculate rotated image dimensions
function rotateSize(width: number, height: number, rotation: number) {
  const rotRad = (rotation * Math.PI) / 180;
  return {
    width:
      Math.abs(Math.cos(rotRad) * width) + Math.abs(Math.sin(rotRad) * height),
    height:
      Math.abs(Math.sin(rotRad) * width) + Math.abs(Math.cos(rotRad) * height),
  };
}

// High-fidelity canvas cropper using pixel values from react-easy-crop
async function getCroppedImg(
  imageSrc: string,
  pixelCrop: Area,
  rotation = 0
): Promise<string> {
  const image = await createImage(imageSrc);
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');

  if (!ctx) {
    throw new Error('No 2D context');
  }

  const rotRad = (rotation * Math.PI) / 180;

  // Calculate rotated boundaries
  const { width: bBoxWidth, height: bBoxHeight } = rotateSize(
    image.width,
    image.height,
    rotation
  );

  // Set canvas size matching the rotated box structure
  canvas.width = bBoxWidth;
  canvas.height = bBoxHeight;

  // Center context on canvas, rotate, and translate back
  ctx.translate(bBoxWidth / 2, bBoxHeight / 2);
  ctx.rotate(rotRad);
  ctx.translate(-image.width / 2, -image.height / 2);

  // Draw full rotated source image
  ctx.drawImage(image, 0, 0);

  // Crop the selected region
  const data = ctx.getImageData(
    pixelCrop.x,
    pixelCrop.y,
    pixelCrop.width,
    pixelCrop.height
  );

  // Resize canvas to crop dimensions
  canvas.width = pixelCrop.width;
  canvas.height = pixelCrop.height;

  // Paste raw image back on canvas
  ctx.putImageData(data, 0, 0);

  // Return base64 JPEG format with high quality resolution
  return canvas.toDataURL('image/jpeg', 0.9);
}

export default function ImageCropperModal({
  imageSrc,
  onCrop,
  onClose,
  aspectRatio = 1,
}: ImageCropperModalProps) {
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [croppedAreaPixels, setCroppedAreaPixels] = useState<Area | null>(null);
  const [maskType, setMaskType] = useState<'rect' | 'round'>('round');
  const [showGrid, setShowGrid] = useState(true);
  const [isCropping, setIsCropping] = useState(false);
  const [cropError, setCropError] = useState<string | null>(null);

  const onCropComplete = useCallback((_croppedArea: Area, croppedAreaPixels: Area) => {
    setCroppedAreaPixels(croppedAreaPixels);
  }, []);

  const handleApplyCrop = async () => {
    if (!croppedAreaPixels) {
      setCropError("No crop coordinates generated yet. Please adjust the selection.");
      return;
    }

    try {
      setIsCropping(true);
      setCropError(null);
      const croppedImage = await getCroppedImg(imageSrc, croppedAreaPixels, rotation);
      onCrop(croppedImage);
    } catch (err: any) {
      console.error("Cropping failed:", err);
      setCropError("Failed to crop your photo. Check that the image is valid and try again.");
    } finally {
      setIsCropping(false);
    }
  };

  return (
    <div id="image-crop-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/85 backdrop-blur-sm animate-fadeIn">
      <div id="image-crop-modal-container" className="bg-zinc-900 border border-zinc-800 rounded-3xl w-full max-w-md overflow-hidden shadow-2xl flex flex-col">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-zinc-850 p-4.5">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse"></div>
            <h4 className="text-zinc-100 font-black uppercase text-xs sm:text-sm tracking-widest font-mono">
              Align & Crop Photo
            </h4>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="text-zinc-400 hover:text-zinc-100 p-1.5 rounded-lg hover:bg-zinc-805 transition-colors cursor-pointer"
          >
            <X className="w-4.5 h-4.5" />
          </button>
        </div>

        {/* Informational Guidance Alert banner */}
        <div className="bg-amber-500/5 text-amber-400/90 text-[10.5px] px-4.5 py-2.5 border-b border-zinc-850/50 flex items-start gap-2 leading-relaxed">
          <AlertTriangle className="w-3.5 h-3.5 shrink-0 stroke-[2] mt-0.5 text-amber-500" />
          <span>
            Pinch/drag to center. Scale so that your face sits cleanly inside the template outline without cropping your head or losing details!
          </span>
        </div>

        {/* Interactive react-easy-crop viewport containment */}
        <div className="relative h-[280px] w-full bg-zinc-950/90 border-b border-zinc-850">
          <Cropper
            image={imageSrc}
            crop={crop}
            zoom={zoom}
            rotation={rotation}
            aspect={aspectRatio}
            cropShape={maskType}
            showGrid={showGrid}
            onCropChange={setCrop}
            onZoomChange={setZoom}
            onRotationChange={setRotation}
            onCropComplete={onCropComplete}
          />
        </div>

        {/* Control toolbar overlay and toggles */}
        <div className="p-5 space-y-4 bg-zinc-900/40">
          
          {/* Format Settings & Grid Toggles */}
          <div className="flex items-center justify-between gap-3 text-[10px] font-mono font-black uppercase text-zinc-500 select-none">
            <div className="flex gap-1.5">
              <button
                type="button"
                onClick={() => setMaskType('round')}
                className={`px-3 py-1.5 border rounded-lg transition-all cursor-pointer ${
                  maskType === 'round'
                    ? 'bg-amber-500 border-amber-500 text-zinc-950 font-black shadow'
                    : 'bg-zinc-950 border-zinc-850 text-zinc-400 hover:text-white'
                }`}
              >
                Circle Aspect
              </button>
              <button
                type="button"
                onClick={() => setMaskType('rect')}
                className={`px-3 py-1.5 border rounded-lg transition-all cursor-pointer ${
                  maskType === 'rect'
                    ? 'bg-amber-500 border-amber-500 text-zinc-950 font-black shadow'
                    : 'bg-zinc-950 border-zinc-850 text-zinc-400 hover:text-white'
                }`}
              >
                Square (Polaroid)
              </button>
            </div>

            <button
              type="button"
              onClick={() => setShowGrid(!showGrid)}
              className={`p-1.5 border rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1 block uppercase ${
                showGrid 
                  ? 'bg-zinc-850 border-zinc-700 text-amber-400' 
                  : 'bg-zinc-950 border-zinc-850 text-zinc-500'
              }`}
              title="Toggle Grid Lines"
            >
              <Grid className="w-3.5 h-3.5" />
              <span>Grid</span>
            </button>
          </div>

          {/* Zoom Level Control Slider */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-[11px] font-mono font-bold text-zinc-400">
              <span className="flex items-center gap-1">
                <ZoomOut className="w-3.5 h-3.5 text-zinc-500" /> 
                Scale Zoom
              </span>
              <span className="text-amber-500 font-extrabold">{Math.round(zoom * 100)}%</span>
            </div>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setZoom((z) => Math.max(1, z - 0.2))}
                className="w-7 h-7 flex items-center justify-center text-zinc-400 hover:text-white bg-zinc-950 border border-zinc-850 rounded-lg text-xs font-bold cursor-pointer"
              >
                -
              </button>
              <input
                type="range"
                id="cropper-zoom-range"
                name="cropperZoom"
                min={1}
                max={4}
                step={0.05}
                value={zoom}
                onChange={(e) => setZoom(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-zinc-950 rounded-lg appearance-none cursor-pointer accent-amber-500"
              />
              <button
                type="button"
                onClick={() => setZoom((z) => Math.min(4, z + 0.2))}
                className="w-7 h-7 flex items-center justify-center text-zinc-400 hover:text-white bg-zinc-950 border border-zinc-850 rounded-lg text-xs font-bold cursor-pointer"
              >
                +
              </button>
            </div>
          </div>

          {/* Rotation Control & Action Buttons Row */}
          <div className="flex justify-between items-center pt-2 gap-2 border-t border-zinc-850/60">
            <div className="flex gap-1.5">
              <button
                type="button"
                onClick={() => setRotation((r) => (r + 90) % 360)}
                title="Rotate 90° Clockwise"
                className="bg-zinc-950 hover:bg-zinc-850 border border-zinc-850 text-zinc-400 hover:text-amber-400 p-2 rounded-xl transition-all cursor-pointer flex items-center justify-center"
              >
                <RotateCw className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => {
                  setCrop({ x: 0, y: 0 });
                  setZoom(1);
                  setRotation(0);
                }}
                className="bg-zinc-950 hover:bg-zinc-850 border border-zinc-850 text-zinc-400 hover:text-zinc-200 text-[10px] font-mono font-bold uppercase px-3 rounded-xl transition-all cursor-pointer flex items-center justify-center"
              >
                Reset
              </button>
            </div>

            {cropError && (
              <p className="text-red-400 text-[10px] font-mono leading-tight max-w-[150px] overflow-hidden truncate">
                {cropError}
              </p>
            )}

            <button
              onClick={handleApplyCrop}
              disabled={isCropping}
              type="button"
              className="bg-amber-500 hover:bg-amber-400 disabled:bg-zinc-800 text-zinc-950 disabled:text-zinc-500 font-mono font-black text-xs py-2.5 px-5 rounded-xl uppercase tracking-wider cursor-pointer transition-all shadow-md shadow-amber-500/5 flex items-center gap-1.5 ml-auto"
            >
              <Check className="w-4 h-4 stroke-[3]" />
              <span>{isCropping ? 'Cropping...' : 'Apply & Save'}</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
}
