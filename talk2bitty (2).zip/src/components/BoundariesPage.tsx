import React from 'react';
import { Quote, Sparkles, MessageSquare, Lock, Heart, Ban, Clock, Handshake } from 'lucide-react';
import LegalPolicies from './LegalPolicies';

export default function BoundariesPage() {
  return (
    <div id="boundaries-container" className="max-w-4xl mx-auto space-y-12 py-4 select-text text-left">
      
      {/* 1. THE HOOK (Top of the page - bold and human) */}
      <div className="relative overflow-hidden bg-gradient-to-br from-amber-500/10 via-purple-500/5 to-zinc-950 border border-zinc-850 p-8 md:p-12 rounded-2xl space-y-6">
        <div className="absolute top-4 right-6 text-amber-500/[0.04] pointer-events-none select-none">
          <Quote className="w-32 h-32 stroke-[3]" />
        </div>
        
        <div className="space-y-4 max-w-3xl relative z-10">
          <span className="text-[10px] font-mono text-amber-400 uppercase tracking-widest font-black px-3 py-1 bg-amber-500/10 rounded-full border border-amber-500/20 inline-block">
            Where I stand
          </span>
          <h2 className="text-2.5xl md:text-4xl font-black text-zinc-100 uppercase tracking-tight font-sans leading-tight">
            "I'm not a yes-person. If I think you're right, I'll tell you. If I think you're wrong, I'll tell you that too."
          </h2>
          <p className="text-zinc-300 text-sm md:text-base leading-relaxed">
            If you want someone to nod along blindly, hold your hand, and flatter you while your life or relationships are in a tailspin, we probably won't fit. I’m here because I actually care about you getting through it. And real support means telling you the raw, unpolished truth—even when it's uncomfortable to hear.
          </p>
        </div>
      </div>

      {/* 2. WHAT THIS IS (What Bitty actually offers) */}
      <div className="space-y-6">
        <div>
          <span className="text-[10px] font-mono text-purple-400 uppercase tracking-widest font-bold block mb-1">
            Let's keep it simple
          </span>
          <h3 className="text-xl md:text-2xl font-black text-zinc-150 uppercase tracking-tight"> What Talk2Bitty IS</h3>
        </div>

        <p className="text-zinc-350 text-sm md:text-base leading-relaxed">
          I’m a mom of three, a student of Human Development, and a person who has lived through some of life's heaviest chapters—divorce, betrayal, severe grief, and losing one of the most important people in my life to suicide. I know exactly how loud the silence gets, and how lonely it feels when nobody is truly listening. 
        </p>

        <p className="text-zinc-350 text-sm md:text-base leading-relaxed">
          That’s why I started this space. It’s a plain, direct sounding board where you get my complete attention, my honest feedback, and real, unfiltered dialogue. 
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3">
          <div className="bg-zinc-900/50 border border-zinc-900 p-5 rounded-xl space-y-2">
            <h4 className="text-zinc-200 text-xs font-mono font-bold uppercase tracking-wider flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-purple-400" />
              Real Written Chats
            </h4>
            <p className="text-zinc-400 text-xs leading-relaxed">
              We chat over private text message threads. We can unpack parenting messes, relationship choices, family dynamics, or plain old life decisions. No pre-written textbook templates or automated AI scripts. Just you and me.
            </p>
          </div>

          <div className="bg-zinc-900/50 border border-zinc-900 p-5 rounded-xl space-y-2">
            <h4 className="text-zinc-200 text-xs font-mono font-bold uppercase tracking-wider flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              My Undivided Attention
            </h4>
            <p className="text-zinc-400 text-xs leading-relaxed">
              When I'm in your chat slot, I sit down with quiet focus, review your situation, and write you a deep, thoughtful reply. I handle requests around study breaks and motherly duties, usually responding within 24 to 48 hours.
            </p>
          </div>
        </div>
      </div>

      {/* 3. THE HOUSE RULES (Mutual Agreements) */}
      <div className="bg-zinc-900/60 border border-zinc-850 p-6 md:p-8 rounded-2xl space-y-6">
        <div className="space-y-1">
          <h3 className="text-lg font-bold text-zinc-150 uppercase tracking-tight font-sans flex items-center gap-2">
            <Handshake className="w-5 h-5 text-amber-500" />
            <span>Our House Rules</span>
          </h3>
          <p className="text-zinc-500 text-xs font-mono">Just a few simple agreements that protect our space.</p>
        </div>

        <ul className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-5 text-zinc-300 text-xs md:text-sm">
          <li className="flex items-start gap-3">
            <span className="w-5 h-5 rounded bg-zinc-850 text-zinc-400 flex items-center justify-center font-mono font-bold text-xs shrink-0 mt-0.5 select-none">1</span>
            <div className="space-y-0.5">
              <strong className="text-zinc-200 block uppercase text-[11px] font-mono tracking-wider flex items-center gap-1.5">
                <Lock className="w-3 h-3 text-zinc-505" /> Complete Privacy
              </strong>
              <p className="text-zinc-400 leading-relaxed text-xs">Everything you share stays strictly confidential between you and me. I don’t share screenshots, gossiping stories, or personal details with anyone, ever.</p>
            </div>
          </li>
          
          <li className="flex items-start gap-3">
            <span className="w-5 h-5 rounded bg-zinc-850 text-zinc-400 flex items-center justify-center font-mono font-bold text-xs shrink-0 mt-0.5 select-none">2</span>
            <div className="space-y-0.5">
              <strong className="text-zinc-200 block uppercase text-[11px] font-mono tracking-wider flex items-center gap-1.5">
                <Ban className="w-3 h-3 text-zinc-505" /> Zero Disrespect
              </strong>
              <p className="text-zinc-400 leading-relaxed text-xs">Any attempt to push romantic vibes, send sexually explicit content, throw aggressive tantrums, or ignore my personal boundaries triggers an instant, permanent block with no refund.</p>
            </div>
          </li>

          <li className="flex items-start gap-3">
            <span className="w-5 h-5 rounded bg-zinc-850 text-zinc-400 flex items-center justify-center font-mono font-bold text-xs shrink-0 mt-0.5 select-none">3</span>
            <div className="space-y-0.5">
              <strong className="text-zinc-200 block uppercase text-[11px] font-mono tracking-wider flex items-center gap-1.5">
                <MessageSquare className="w-3 h-3 text-zinc-505" /> Written Format Only
              </strong>
              <p className="text-zinc-400 leading-relaxed text-xs">We chat strictly via private written message threads inside our secure gateway (or via WhatsApp). No direct phone callbacks, video meetings, or audio calls. This protects my family and lets us both think before we write.</p>
            </div>
          </li>

          <li className="flex items-start gap-3">
            <span className="w-5 h-5 rounded bg-zinc-850 text-zinc-400 flex items-center justify-center font-mono font-bold text-xs shrink-0 mt-0.5 select-none">4</span>
            <div className="space-y-0.5">
              <strong className="text-zinc-200 block uppercase text-[11px] font-mono tracking-wider flex items-center gap-1.5">
                <Clock className="w-3 h-3 text-zinc-505" /> No Rush, No Instant Callback
              </strong>
              <p className="text-zinc-400 leading-relaxed text-xs">I am a student and a mom first. I read and respond within 24 to 48 hours. I don't guarantee instant correspondence or middle-of-the-night messaging.</p>
            </div>
          </li>
        </ul>
      </div>

      {/* 4. LEGAL DISCLAIMERS & CRISIS PROTOCOLS - Simple & consolidated */}
      <div className="border-t border-zinc-900 pt-8">
        <LegalPolicies showTitle={true} />
      </div>
    </div>
  );
}
