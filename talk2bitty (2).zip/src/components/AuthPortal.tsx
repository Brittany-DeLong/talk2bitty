import React, { useState } from 'react';
import { Shield, Mail, Lock, User, Phone, AlignLeft, ArrowRight, UserCheck, Flame, Cpu, HelpCircle } from 'lucide-react';
import { UserProfile } from '../types';
import LegalPolicies from './LegalPolicies';
import Talk2BittyLogo from './Talk2BittyLogo';
import { googleSignIn } from '../services/googleAuth';

interface AuthPortalProps {
  onLoginSuccess: (user: UserProfile) => void;
}

export default function AuthPortal({ onLoginSuccess }: AuthPortalProps) {
  const [isRegistering, setIsRegistering] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [usernameEdited, setUsernameEdited] = useState(false);
  const [phone, setPhone] = useState('');
  const [bio, setBio] = useState('');

  // Disclaimer agreement states
  const [agreedToDisclaimers, setAgreedToDisclaimers] = useState(false);
  const [showPolicies, setShowPolicies] = useState(false);

  const handleNameChange = (val: string) => {
    setName(val);
    if (!usernameEdited) {
      setUsername(val.toLowerCase().trim().replace(/[^a-z0-9_]/g, '_'));
    }
  };

  // Submit Handler
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (isRegistering && !agreedToDisclaimers) {
      setError('You must acknowledge and accept the essential service boundaries and disclaimers to register.');
      return;
    }

    if (isRegistering && !username.trim()) {
      setError('A secure, unique username is required.');
      return;
    }

    setLoading(true);

    const url = isRegistering ? '/api/auth/register' : '/api/auth/login';
    const body = isRegistering 
      ? { name, username: username.toLowerCase().trim(), email, phone, password, bio }
      : { email, password };

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(body),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Authentication process failed.');
      }

      if (data.user) {
        onLoginSuccess(data.user);
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred during authentication.');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setError(null);
    setLoading(true);
    if (isRegistering && !agreedToDisclaimers) {
      setError('You must acknowledge and accept the essential service boundaries and disclaimers to register.');
      setLoading(false);
      return;
    }

    try {
      const result = await googleSignIn();
      if (!result) return; // User closed popup or cancelled

      const response = await fetch('/api/auth/google', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: result.user.displayName,
          email: result.user.email,
          avatarUrl: result.user.photoURL,
          id: result.user.uid,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to authenticate secure session.');
      }

      if (data.user) {
        onLoginSuccess(data.user);
      }
    } catch (err: any) {
      const isClosedByUser = err?.code === 'auth/popup-closed-by-user' || 
                             err?.message?.includes('popup-closed-by-user');
      if (!isClosedByUser) {
        console.error('Google Sign-In Session Error:', err);
        setError(err.message || 'Google Sign-In process failed.');
      } else {
        console.log('Google Sign-In cancelled/closed by user.');
      }
    } finally {
      setLoading(false);
    }
  };

  // Quick Account Login Actions
  const handleQuickLogin = async (targetEmail: string, pass: string) => {
    setError(null);
    setLoading(true);
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: targetEmail, password: pass })
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Quick login failed.');
      }
      if (data.user) {
        onLoginSuccess(data.user);
      }
    } catch (err: any) {
      setError(err.message || 'Quick login connection failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="auth-portal-pane" className="max-w-md mx-auto my-8 bg-zinc-900/80 border border-zinc-850 rounded-2xl overflow-hidden shadow-2xl relative animate-fadeIn">
      
      {/* Decorative Top Accent */}
      <div className="h-1 bg-gradient-to-r from-amber-600 via-amber-500 to-amber-600"></div>

      {/* Header Accent */}
      <div className="p-6 pb-4 border-b border-zinc-850/80 text-center space-y-4 select-none">
        <Talk2BittyLogo size="lg" className="justify-center" />
        <div>
          <h2 className="text-sm font-black text-zinc-300 uppercase font-mono tracking-widest">
            {isRegistering ? 'Create Member Profile' : 'Secure Member Login'}
          </h2>
          <p className="text-[10px] text-zinc-500 font-mono uppercase tracking-wider">
            {isRegistering ? 'Join Bitty’s Active Conversation Circle' : 'Unlock private conversation access'}
          </p>
        </div>
      </div>

      <div className="p-6 space-y-6">
        
        {/* Error Dialog Banner */}
        {error && (
          <div className="space-y-3">
            <div className="bg-red-500/5 border border-red-500/20 text-red-400 p-3.5 rounded-xl text-xs flex items-center gap-2 select-none">
              <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse shrink-0"></span>
              <p className="font-mono text-[11px] font-bold tracking-tight">{error}</p>
            </div>

            {/* In-Context Troubleshooting Guide for Google SSO Failures or General Auth Obstacles */}
            <div className="bg-amber-950/20 border border-amber-500/20 rounded-xl p-3.5 text-[11px] leading-relaxed font-sans text-zinc-350 space-y-2">
              <div className="flex items-center gap-1.5 text-amber-500 font-bold font-mono uppercase tracking-wider text-[10px]">
                <HelpCircle className="w-3.5 h-3.5 shrink-0 animate-pulse text-amber-400" />
                <span>Google Sign-In Troubleshooter</span>
              </div>
              <p className="text-[10px] text-zinc-400">
                Because this preview is running inside a sandboxed iframe, your browser might block secure login pop-up signals. Try these quick fixes:
              </p>
              <ul className="list-decimal list-inside space-y-1.5 text-zinc-300 font-mono text-[10px]">
                <li>
                  <span className="font-bold text-amber-500/90">Open Standalone Tab:</span> Click the <span className="text-zinc-100">"Open in new tab / window"</span> icon at the top-right of your preview iframe.
                </li>
                <li>
                  <span className="font-bold text-amber-500/90">Allow Popups & Cookies:</span> Check if Brave Shields, Safari, or Chrome Incognito are blocking third-party cookies or authentication pop-ups.
                </li>
                <li>
                  <span className="font-bold text-amber-500/90">Authorized Domains:</span> Ensure <code className="bg-zinc-950 px-1 py-0.5 rounded text-amber-400 select-all">ais-dev-hodt6mjivimgsxwxxwwyc7-681283006784.us-east1.run.app</code> is added in your <span className="text-zinc-100 italic">Firebase Console &gt; Authentication &gt; Settings &gt; Authorized Domains</span>.
                </li>
              </ul>
            </div>
          </div>
        )}

        {/* Input Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          
          {isRegistering && (
            <>
              {/* Display Name */}
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest font-mono">
                  Display Name
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-zinc-500">
                    <User className="w-4 h-4" />
                  </span>
                  <input
                    type="text"
                    required
                    id="auth-register-name"
                    name="name"
                    value={name}
                    onChange={(e) => handleNameChange(e.target.value)}
                    placeholder="Jane Doe"
                    className="w-full bg-zinc-950 border border-zinc-850 focus:border-amber-500/40 rounded-xl py-2.5 pl-10 pr-4 text-xs font-sans text-zinc-350 placeholder-zinc-700 outline-none transition-colors"
                  />
                </div>
              </div>

              {/* Username */}
              <div className="space-y-1 animate-fadeIn">
                <div className="flex justify-between items-center">
                  <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest font-mono">
                    Username
                  </label>
                  <span className="text-[9px] text-zinc-500 font-mono">Unique handle: lowercase, numbers, underscores</span>
                </div>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-amber-550 font-bold font-mono text-xs select-none">
                    @
                  </span>
                  <input
                    type="text"
                    required
                    id="auth-register-username"
                    name="username"
                    value={username}
                    onChange={(e) => {
                      setUsernameEdited(true);
                      setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '_'));
                    }}
                    placeholder="jane_doe"
                    className="w-full bg-zinc-950 border border-zinc-850 focus:border-amber-500/40 rounded-xl py-2.5 pl-10 pr-4 text-xs font-mono text-zinc-350 placeholder-zinc-700 outline-none transition-colors"
                  />
                </div>
              </div>

              {/* Phone (Optional) */}
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest font-mono">
                  Phone Number (Optional)
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-zinc-500">
                    <Phone className="w-4 h-4" />
                  </span>
                  <input
                    type="text"
                    id="auth-register-phone"
                    name="phone"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="e.g. 555-0198"
                    className="w-full bg-zinc-950 border border-zinc-850 focus:border-amber-500/40 rounded-xl py-2.5 pl-10 pr-4 text-xs font-sans text-zinc-350 placeholder-zinc-700 outline-none transition-colors"
                  />
                </div>
              </div>

              {/* Short Bio (Optional) */}
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest font-mono">
                  Short Bio (Optional)
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-start pt-3.5 pl-3 text-zinc-500">
                    <AlignLeft className="w-4 h-4" />
                  </span>
                  <textarea
                    rows={2}
                    id="auth-register-bio"
                    name="bio"
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    placeholder="What brings you to Talk2Bitty?"
                    className="w-full bg-zinc-950 border border-zinc-850 focus:border-amber-500/40 rounded-xl py-2.5 pl-10 pr-4 text-xs font-sans text-zinc-350 placeholder-zinc-700 outline-none transition-colors resize-none"
                  />
                </div>
              </div>

              {/* BOUNDARIES & DISCLAIMERS COMPLIANCE */}
              <div className="bg-zinc-950 border border-zinc-850 p-4.5 rounded-xl space-y-3.5">
                <div className="flex items-start gap-3">
                  <input 
                    type="checkbox" 
                    id="auth-disclaimer-chk"
                    required
                    checked={agreedToDisclaimers}
                    onChange={(e) => setAgreedToDisclaimers(e.target.checked)}
                    className="w-4 h-4 text-amber-500 border-zinc-750 bg-zinc-900 rounded focus:ring-0 cursor-pointer accent-amber-500 mt-0.5"
                  />
                  <label htmlFor="auth-disclaimer-chk" className="text-xs text-zinc-300 leading-normal select-none cursor-pointer">
                    <span className="font-extrabold text-amber-400 uppercase tracking-wider text-[10px] block mb-0.5">
                      Acknowledge Safety Boundaries
                    </span>
                    <span className="text-zinc-400 text-[11px] leading-relaxed block">
                      I understand that Talk2Bitty is <strong className="text-zinc-200">NOT</strong> medical, legal, or therapeutic advice. It is built strictly for supportive listening and peer feedback.
                    </span>
                  </label>
                </div>

                <div className="border-t border-zinc-900/60 pt-3 flex justify-between items-center">
                  <button
                    type="button"
                    onClick={() => setShowPolicies(!showPolicies)}
                    className="text-amber-500 hover:text-amber-400 font-mono text-[10px] font-black uppercase hover:underline cursor-pointer block"
                  >
                    {showPolicies ? 'Hide Disclaimers ▲' : 'View Full Disclaimers ▼'}
                  </button>
                  <span className="text-[9px] text-zinc-500 font-mono font-medium">Agreement Required</span>
                </div>

                {showPolicies && (
                  <div className="border-t border-zinc-900 pt-3 animate-fadeIn max-h-56 overflow-y-auto scrollbar-thin space-y-1">
                    <LegalPolicies showTitle={false} />
                  </div>
                )}
              </div>
            </>
          )}

          {/* Email Address */}
          <div className="space-y-1">
            <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest font-mono">
              Email Address
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-zinc-500">
                <Mail className="w-4 h-4" />
              </span>
              <input
                type="email"
                required
                id="auth-credential-email"
                name="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full bg-zinc-950 border border-zinc-850 focus:border-amber-500/40 rounded-xl py-2.5 pl-10 pr-4 text-xs font-sans text-zinc-350 placeholder-zinc-700 outline-none transition-colors"
              />
            </div>
          </div>

          {/* Password */}
          <div className="space-y-1">
            <div className="flex justify-between items-center text-[10px] font-mono">
              <label className="block font-bold text-zinc-400 uppercase tracking-widest">
                Password
              </label>
            </div>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-zinc-500">
                <Lock className="w-4 h-4" />
              </span>
              <input
                type="password"
                required
                id="auth-credential-password"
                name="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-zinc-950 border border-zinc-850 focus:border-amber-500/40 rounded-xl py-2.5 pl-10 pr-4 text-xs font-sans text-zinc-350 placeholder-zinc-700 outline-none transition-colors"
              />
            </div>
          </div>

          {/* Action Trigger Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-amber-500 hover:bg-amber-400 disabled:bg-zinc-800 text-zinc-950 disabled:text-zinc-500 font-extrabold uppercase font-mono tracking-wider text-xs py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-amber-500/10 mt-6"
          >
            <span>{loading ? 'Processing...' : isRegistering ? 'Register & Enter' : 'Acknowledge Secure Entry'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Google SSO Authenticator Segment */}
        <div className="relative flex py-1 items-center">
          <div className="flex-grow border-t border-zinc-850/60"></div>
          <span className="flex-shrink mx-3 text-[9px] text-zinc-550 font-mono uppercase tracking-widest select-none">Or Secure Authentication Via</span>
          <div className="flex-grow border-t border-zinc-850/60"></div>
        </div>

        <button
          type="button"
          disabled={loading}
          onClick={handleGoogleSignIn}
          className="w-full bg-zinc-950 hover:bg-zinc-900 border border-zinc-850 disabled:bg-zinc-950 text-zinc-350 disabled:text-zinc-650 font-extrabold font-mono uppercase tracking-wider text-xs py-3 px-4 rounded-xl flex items-center justify-center gap-3.5 transition-all cursor-pointer shadow-sm active:scale-98"
        >
          <svg className="w-4 h-4 shrink-0 select-none" viewBox="0 0 24 24">
            <path
              fill="#EA4335"
              d="M5.266 9.765A7.077 7.077 0 0112 4.909c1.69 0 3.218.6 4.418 1.582l3.51-3.51C17.764 1.055 15.027 0 12 0 7.37 0 3.395 2.66 1.486 6.54l3.78 3.225z"
            />
            <path
              fill="#4285F4"
              d="M23.49 12.273c0-.818-.073-1.605-.21-2.364H12v4.51h6.47c-.29 1.48-1.12 2.73-2.37 3.58v2.98h3.83c2.24-2.06 3.56-5.09 3.56-8.706z"
            />
            <path
              fill="#FBBC05"
              d="M5.266 14.235A7.014 7.014 0 014.91 12c0-.792.13-1.556.356-2.235l-3.78-3.225C.544 8.127 0 9.998 0 12c0 2.002.544 3.873 1.486 5.46l3.78-3.225z"
            />
            <path
              fill="#34A853"
              d="M12 24c3.24 0 5.97-1.07 7.96-2.92l-3.83-2.98c-1.07.72-2.43 1.15-4.13 1.15-3.224 0-5.955-2.182-6.914-5.118l-3.78 3.225C3.395 21.34 7.37 24 12 24z"
            />
          </svg>
          <span>Continue with Google</span>
        </button>

        {/* Toggle Mode Link */}
        <div className="text-center font-mono text-[11px] text-zinc-500 select-none">
          {isRegistering ? (
            <p>
              Already have a secure member account?{' '}
              <button
                type="button"
                onClick={() => { setIsRegistering(false); setError(null); }}
                className="text-amber-400 hover:underline hover:text-amber-300 font-bold ml-1 cursor-pointer"
              >
                Sign In
              </button>
            </p>
          ) : (
            <p>
              New listening partner?{' '}
              <button
                type="button"
                onClick={() => { setIsRegistering(true); setError(null); }}
                className="text-amber-400 hover:underline hover:text-amber-300 font-bold ml-1 cursor-pointer"
              >
                Register Here
              </button>
            </p>
          )}
        </div>

      </div>
    </div>
  );
}
