# Talk2Bitty 💬

Talk2Bitty is a secure, raw, and sincere 1-on-1 text dialogue and peer perspective platform. Connect privately with Bitty, browse chronological community boards, and find real human connection with honest, supportive boundaries.

---

## 🛠️ Core Technology Stack

*   **Frontend**: React 19, Tailwind CSS v4, Lucide Icons, and Framer Motion (`motion/react`) for fluid component transitions.
*   **Backend**: Full-stack Node.js environment powered by Express, supporting local server databases and custom endpoints.
*   **Persistence & Media**: Firebase Core Integration for Google Sign-In, user session checks, and secure asset uploads to Firebase Storage.
*   **Asset Processing**: Multi-layer image compression (downscaling to maximum limits dynamically and canvas-safe fallbacks) ensuring ultra-lean, performant network footprints.

---

## ✨ Notable Features

### 1. Advanced Intake Model & Drag-and-Drop Support
The post creation and Intake Modal allows users to seamlessly drop attachments or drag images directly into the creator zone.
*   Supports standard media files like **PNG, JPEG, PDFs, and plain text files** up to **5MB**.
*   Built-in visual indicators and instant preview tags with loading feedback micro-states during live processing.

### 2. Intelligent Canvas-Safe Image Compressor
To ensure that client uploads stay light and server bandwidth remains optimized:
*   Standardizes heavy files to compressed Base64 data URLs in a non-blocking queue.
*   Combats common `canvas.toDataURL` and CORS sandboxing issues by selectively applying `crossOrigin='anonymous'` purely for external assets.
*   Integrates safety timeouts (cancels hanging processes automatically and falls back gracefully to the original file stream if rendering stalls).

### 3. Dynamic Homepage Polaroid Frame
Authored for admins to personalize homepage assets dynamically.
*   Direct upload triggers file inputs behind authentic tilted polaroid visuals.
*   Updates are streamed to database endpoints instantly without stale cache delays.

---

## 🚀 Running the Project

### Scripts Guide

Install baseline structures and trigger development:

```bash
# Install NPM modules if required
npm install

# Start the full-stack development workspace
npm run dev
```

Build and serve in production-equivalent environments:

```bash
# Build Vite bundles and compile backend Express servers via esbuild
npm run build

# Start the generated standalone application
npm start
```

---

## 💡 Developer Environment FAQs (Benign Logs & Warnings)

### Why am I seeing `WebSocket connection failed: wss://` in the console?

Inside this sandboxed development preview environment, you might encounter warnings such as:
*   `_aistudio-iframe.js:273 WebSocket connection to 'wss://.../?token=...' failed`
*   `_aistudio-iframe.js:339 [vite] failed to connect to websocket`

#### 🔴 Why this happens:
These errors are **benign, harmless, and entirely expected**. Hot Module Replacement (HMR) is manually disabled by the workspace control plane (`DISABLE_HMR=true`) on startup. We do this intentionally to prevent the live web application iframe from constantly rebuilding, flickering, or breaking while code is written incrementally.

#### 🟢 What to do:
You can **safely ignore these console errors**. It has zero impact on compilation, user interactivity, API integrations, database operations, or app features. All styling and functionality updates are securely applied on every compilation, allowing development to flow smoothly!
