/**
 * Auth middleware — validates Supabase session tokens.
 * Sets req.user if valid, otherwise redirects to /login.
 * Does NOT handle role checks (see routes/admin.js for that).
 */
const { getUserFromSession } = require('../services/auth');

function requireAuth(req, res, next) {
  const token = req.cookies?.sb_access_token || req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.redirect('/login');

  getUserFromSession(token).then((user) => {
    if (!user) {
      res.clearCookie('sb_access_token');
      return res.redirect('/login');
    }
    req.user = user;
    next();
  });
}

module.exports = { requireAuth };