/**
 * Database entry point — owns the only Pool instance in the app.
 * All SQL goes through named functions in db/<entity>.js.
 */
const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL?.includes('localhost')
    ? false
    : { rejectUnauthorized: false },
});

pool.on('error', (err) => {
  console.error('[pg pool] idle client error (non-fatal):', err?.message);
});

module.exports = { pool };