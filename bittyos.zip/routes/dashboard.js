/**
 * Dashboard routes — auth required.
 * Serves: dashboard, profile, wall, text-talk pages.
 * Does NOT own admin routes (see routes/admin.js).
 */
const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const { renderPage } = require('../lib/render');

router.get('/dashboard', requireAuth, (req, res) => {
  renderPage(res, 'dashboard', { pageTitle: 'Dashboard', user: req.user });
});

router.get('/profile', requireAuth, (req, res) => {
  renderPage(res, 'profile', { pageTitle: 'Profile', user: req.user });
});

router.get('/wall', requireAuth, (req, res) => {
  renderPage(res, 'wall', { pageTitle: 'The Wall', user: req.user });
});

router.get('/text-talk', requireAuth, (req, res) => {
  renderPage(res, 'text-talk/index', { pageTitle: 'Text Talk', user: req.user });
});

router.get('/text-talk/request', requireAuth, (req, res) => {
  renderPage(res, 'text-talk/request', { pageTitle: 'Request a Session', user: req.user });
});

router.get('/text-talk/success', requireAuth, (req, res) => {
  renderPage(res, 'text-talk/success', { pageTitle: 'Session Confirmed', user: req.user });
});

router.get('/text-talk/cancel', requireAuth, (req, res) => {
  renderPage(res, 'text-talk/cancel', { pageTitle: 'Session Cancelled', user: req.user });
});

router.get('/requests/:id', requireAuth, (req, res) => {
  renderPage(res, 'requests/show', { pageTitle: 'Request Details', user: req.user, requestId: req.params.id });
});

module.exports = router;
