/**
 * API routes — webhooks, checkout, SMS.
 * Handles: Stripe webhooks, checkout sessions, Twilio SMS.
 * Does NOT own page rendering or auth flows.
 */
const express = require('express');
const router = express.Router();

// Stripe webhook — raw body needed for signature verification
router.post('/api/stripe-webhook', express.raw({ type: 'application/json' }), (req, res) => {
  // TODO: Verify Stripe webhook signature and handle events
  console.log('[stripe-webhook] Received webhook event');
  res.json({ received: true });
});

// Create Stripe checkout session
router.post('/api/create-checkout-session', express.json(), (req, res) => {
  // TODO: Create Stripe checkout session for the selected plan
  const { plan } = req.body;
  console.log('[checkout] Session requested for plan:', plan);
  res.json({ error: 'Stripe not yet configured' });
});

// Twilio incoming SMS handler
router.post('/api/twilio-incoming-sms', express.urlencoded({ extended: true }), (req, res) => {
  // TODO: Handle incoming SMS from Twilio
  console.log('[twilio] Incoming SMS from:', req.body?.From);
  res.type('text/xml').send('<Response></Response>');
});

// Send SMS endpoint (internal use)
router.post('/api/send-sms', express.json(), (req, res) => {
  // TODO: Send SMS via Twilio
  const { to, message } = req.body;
  console.log('[sms] Send request to:', to);
  res.json({ error: 'Twilio not yet configured' });
});

module.exports = router;
