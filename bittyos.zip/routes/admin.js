/**
 * Admin routes — requires auth (admin check placeholder).
 * Serves: admin dashboard, requests, conversations, wall, settings.
 * Does NOT own user-facing routes (see routes/dashboard.js).
 */
const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const { renderPage } = require('../lib/render');

router.get('/admin', requireAuth, (req, res) => {
  renderPage(res, 'admin/index', { pageTitle: 'Admin', user: req.user });
});

router.get('/admin/requests', requireAuth, (req, res) => {
  renderPage(res, 'admin/requests', { pageTitle: 'Admin — Requests', user: req.user });
});

router.get('/admin/requests/:id', requireAuth, (req, res) => {
  renderPage(res, 'admin/request-detail', { pageTitle: 'Admin — Request', user: req.user, requestId: req.params.id });
});

router.get('/admin/conversations', requireAuth, (req, res) => {
  renderPage(res, 'admin/conversations', { pageTitle: 'Admin — Conversations', user: req.user });
});

router.get('/admin/wall', requireAuth, (req, res) => {
  renderPage(res, 'admin/wall', { pageTitle: 'Admin — Wall', user: req.user });
});

router.get('/admin/settings', requireAuth, (req, res) => {
  renderPage(res, 'admin/settings', { pageTitle: 'Admin — Settings', user: req.user });
});

module.exports = router;
