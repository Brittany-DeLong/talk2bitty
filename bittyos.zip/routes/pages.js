/**
 * Public page routes — no auth required.
 * Serves: homepage, about, boundaries, pricing.
 */
const express = require('express');
const router = express.Router();
const { renderPage } = require('../lib/render');

router.get('/', (_req, res) => {
  renderPage(res, 'pages/home', { user: null });
});

router.get('/about', (_req, res) => {
  renderPage(res, 'pages/about', { pageTitle: 'About Bitty', user: null });
});

router.get('/boundaries', (_req, res) => {
  renderPage(res, 'pages/boundaries', { pageTitle: 'Boundaries', user: null });
});

router.get('/pricing', (_req, res) => {
  renderPage(res, 'pages/pricing', { pageTitle: 'Pricing', user: null });
});

module.exports = router;
