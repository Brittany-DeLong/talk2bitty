/**
 * Auth routes — login, signup, logout.
 * All auth logic (Supabase tokens) lives here.
 */
const express = require('express');
const router = express.Router();
const { signIn, signUp, signOut } = require('../services/auth');
const { renderPage } = require('../lib/render');

const COOKIE_OPTS = {
  httpOnly: true,
  secure: process.env.NODE_ENV === 'production',
  sameSite: 'lax',
  maxAge: 60 * 60 * 24 * 7, // 1 week
};

router.get('/login', (_req, res) => {
  renderPage(res, 'login', { pageTitle: 'Log in', error: null, user: null });
});

router.get('/signup', (_req, res) => {
  renderPage(res, 'signup', { pageTitle: 'Sign up', error: null, user: null });
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return renderPage(res, 'login', { pageTitle: 'Log in', error: 'Email and password are required.', user: null });
  }

  const { user, error } = await signIn(email, password);
  if (error) return renderPage(res, 'login', { pageTitle: 'Log in', error, user: null });

  res.cookie('sb_access_token', user.session?.access_token || '', COOKIE_OPTS);
  res.redirect('/dashboard');
});

router.post('/signup', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return renderPage(res, 'signup', { pageTitle: 'Sign up', error: 'Email and password are required.', user: null });
  }

  const { user, error } = await signUp(email, password);
  if (error) return renderPage(res, 'signup', { pageTitle: 'Sign up', error, user: null });

  res.cookie('sb_access_token', user.session?.access_token || '', COOKIE_OPTS);
  res.redirect('/profile');
});

router.post('/logout', async (req, res) => {
  res.clearCookie('sb_access_token');
  await signOut();
  res.redirect('/');
});

module.exports = router;
