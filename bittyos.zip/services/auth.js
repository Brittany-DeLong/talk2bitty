/**
 * Auth service — signs users up and in.
 * Does NOT own routing or middleware logic.
 */
const { supabase } = require('./supabase');
const { pool } = require('../db/index');

async function signUp(email, password) {
  const { data, error } = await supabase.auth.signUp({ email, password });
  if (error) return { user: null, error: error.message };

  // Upsert local user record using supabase_user_id (UUID from Supabase)
  await pool.query(
    `INSERT INTO users (email, supabase_user_id) VALUES ($1, $2)
     ON CONFLICT ON CONSTRAINT users_supabase_user_id_idx DO NOTHING`,
    [email, data.user.id]
  );

  return { user: data.user, error: null };
}

async function signIn(email, password) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) return { user: null, error: error.message };
  return { user: data.user, error: null };
}

async function getUserFromSession(accessToken) {
  const { data, error } = await supabase.auth.getUser(accessToken);
  if (error || !data.user) return null;
  return data.user;
}

async function signOut() {
  await supabase.auth.signOut();
}

module.exports = { signUp, signIn, getUserFromSession, signOut };