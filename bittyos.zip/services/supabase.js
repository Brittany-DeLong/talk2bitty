/**
 * Supabase client — calls Supabase Auth REST API via native fetch.
 * Does NOT own database access.
 */
const SB_URL = process.env.SUPABASE_URL;
const SB_ANON_KEY = process.env.SUPABASE_ANON_KEY;

const supabase = {
  auth: {
    signUp: (opts) => supabaseFetch('/auth/v1/signup', opts),
    signInWithPassword: (opts) => supabaseFetch('/auth/v1/token?grant_type=password', opts, 'POST'),
    getUser: (accessToken) => supabaseFetch('/auth/v1/user', {}, 'GET', accessToken),
    signOut: () => supabaseFetch('/auth/v1/logout', {}, 'POST'),
  },
};

async function supabaseFetch(path, body, method = 'POST', token) {
  const url = `${SB_URL}${path}`;
  const headers = {
    'Content-Type': 'application/json',
    'apikey': SB_ANON_KEY,
    ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
  };
  const res = await fetch(url, {
    method,
    headers,
    ...(method !== 'GET' ? { body: JSON.stringify(body) } : {}),
  });
  const data = await res.json();
  return { data, error: res.ok ? null : { message: data.msg || data.error || 'Request failed' } };
}

module.exports = { supabase };