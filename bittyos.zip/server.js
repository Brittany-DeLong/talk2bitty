/**
 * Entry point — wires middleware, routes, and server startup.
 * Pool lives in db/index.js. Route logic lives in routes/.
 */
const express = require('express');
const path = require('path');

// Bootstrap db (creates pool, sets up error handler)
require('./db/index');

const pagesRouter = require('./routes/pages');
const authRouter = require('./routes/auth');
const dashboardRouter = require('./routes/dashboard');
const adminRouter = require('./routes/admin');
const apiRouter = require('./routes/api');

const app = express();
const port = process.env.PORT || 3000;

if (!process.env.DATABASE_URL) {
  console.error('ERROR: DATABASE_URL environment variable is required');
  process.exit(1);
}

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Cookie parser for auth tokens
const cookieParser = require('cookie-parser');
app.use(cookieParser());

// EJS view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Health check (Render requirement — no DB call to allow Neon auto-suspend)
app.get('/health', (_req, res) => res.json({ status: 'healthy' }));

// Serve static files (index: false so / doesn't auto-serve public/index.html)
app.use(express.static(path.join(__dirname, 'public'), { index: false }));

// API routes (webhooks need raw body — mount before other middleware)
app.use('/', apiRouter);

// Public pages
app.use('/', pagesRouter);

// Auth routes (login POST, signup POST, logout POST)
app.use('/', authRouter);

// Protected routes (dashboard, profile, wall, text-talk)
app.use('/', dashboardRouter);

// Admin routes
app.use('/', adminRouter);

// Error handler — must be AFTER all routes
app.use((err, _req, res, _next) => {
  console.error('[error]', err && err.message || String(err));
  res.status(500).send('Internal Server Error: ' + (err && err.message || String(err)));
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
