# BittyOS

## What this app does
Talk2Bitty is a text-based chat product where users buy time passes to talk to Bitty — a real, slightly blunt AI with opinions. No therapy claims, no unlimited access.

## Stack
Express.js + EJS + Tailwind CSS (CDN) + PostgreSQL (Neon) + Supabase Auth

## Directory map
- `migrations/` — SQL schema changes, applied on deploy
- `db/` — Database access (queries only, no Pool construction here)
- `services/` — External integrations (Supabase auth, Stripe)
- `middleware/` — Auth middleware (requireAuth)
- `routes/` — Express route handlers: pages, auth, dashboard, admin, api
- `lib/` — Shared helpers: render (layout wrapper), landing-context
- `views/` — EJS templates: layout.ejs + partials (nav, footer) + page views
- `views/pages/` — Public pages: home, about, boundaries, pricing
- `views/text-talk/` — Text Talk flow: index, request, success, cancel
- `views/requests/` — Request detail view
- `views/admin/` — Admin views: dashboard, requests, conversations, wall, settings
- `public/` — Static assets (CSS, images)

## Database
- `_migrations` — tracks applied migration files
- `users` — id, email, created_at, subscription fields (Supabase handles auth)

## External integrations
- Supabase Auth — email/password login + signup
- Stripe — payment links for Text Talk Passes (webhook + checkout stubs)
- Twilio — SMS integration stubs for text-based conversations

## Recent changes
- 2026-06-02: Dark mobile-first layout with Tailwind CSS, shared layout system, mobile hamburger menu, safety disclaimer footer, all route groups (public, auth, dashboard, admin, API stubs), .env.example
